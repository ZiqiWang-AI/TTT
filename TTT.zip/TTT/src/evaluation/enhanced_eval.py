"""
Enhanced evaluation utilities integrating Qwen2.5-Math's better processing.
This provides faster inference with vLLM and better mathematical answer comparison.
"""

import os
import math
import re
import torch
import numpy as np
import json
import multiprocessing
from pathlib import Path
from typing import Dict, Any, Optional, List, Union
from tqdm import tqdm
from torch.utils.data import DataLoader
from functools import partial
import time
from pebble import ProcessPool
from concurrent.futures import TimeoutError
import sympy as sp
from sympy.parsing.latex import parse_latex
from sympy.parsing.sympy_parser import parse_expr
import regex
from math import isclose

# Optional vLLM import
try:
    from vllm import LLM, SamplingParams
    VLLM_AVAILABLE = True
except ImportError:
    VLLM_AVAILABLE = False
    print("vLLM not available, falling back to HuggingFace transformers")

from ..data.load_dataset import LoadDataset, collate_fn


def parse_digits(num):
    """Parse numerical values from strings, handling percentages and commas."""
    num = regex.sub(",", "", str(num))
    try:
        return float(num)
    except:
        if num.endswith("%"):
            num = num[:-1]
            if num.endswith("\\"):
                num = num[:-1]
            try:
                return float(num) / 100
            except:
                pass
    return None

def bank_transactions_equal(prediction: str, reference: str) -> bool:
    """
    Bank Transactions evaluation: compare JSON outputs.
    
    Expected format: {"bug_type": "...", "bug_location": "...", "explanation": "..."}
    We compare bug_type and bug_location for correctness.
    
    Args:
        prediction: Model's prediction (should be JSON)
        reference: Ground truth (JSON string or dict)
    
    Returns:
        True if both bug_type and bug_location match
    """
    if prediction is None or reference is None:
        return False
    
    try:
        # Parse prediction JSON
        import json
        import re
        
        # Clean and extract JSON from prediction
        pred_json = extract_json_from_text(str(prediction))
        if pred_json is None:
            return False
        
        # Parse reference JSON
        if isinstance(reference, str):
            ref_json = json.loads(reference)
        elif isinstance(reference, dict):
            ref_json = reference
        else:
            return False
        
        # Compare bug_type and bug_location
        pred_bug_type = pred_json.get('bug_type', '').strip().upper()
        ref_bug_type = ref_json.get('bug_type', '').strip().upper()
        
        pred_bug_location = pred_json.get('bug_location', '').strip().upper()
        ref_bug_location = ref_json.get('bug_location', '').strip().upper()
        
        # Both fields must match exactly
        type_match = pred_bug_type == ref_bug_type
        location_match = pred_bug_location == ref_bug_location
        
        return type_match and location_match
        
    except Exception as e:
        # If JSON parsing fails, try fuzzy matching
        return bank_transactions_fuzzy_match(str(prediction), reference)

def extract_json_from_text(text: str) -> dict:
    """Extract JSON object from text, handling various formatting issues."""
    import json
    import re
    
    if not text:
        return None
    
    # Remove common formatting issues
    text = text.strip()
    
    # Look for JSON patterns
    json_patterns = [
        r'\{[^{}]*"bug_type"[^{}]*\}',  # Simple JSON pattern
        r'\{.*?"bug_type".*?\}',       # More flexible JSON pattern
        r'\{[^{}]*bug_type[^{}]*\}',   # JSON without quotes around keys
    ]
    
    for pattern in json_patterns:
        matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
        for match in matches:
            try:
                # Try to parse as JSON
                return json.loads(match)
            except json.JSONDecodeError:
                # Try fixing common JSON issues
                fixed_match = fix_json_format(match)
                try:
                    return json.loads(fixed_match)
                except json.JSONDecodeError:
                    continue
    
    # If no JSON found, try to extract key-value pairs manually
    return extract_key_value_pairs(text)

def fix_json_format(json_str: str) -> str:
    """Fix common JSON formatting issues."""
    import re
    
    # Add quotes around unquoted keys
    json_str = re.sub(r'(\w+):\s*', r'"\1": ', json_str)
    
    # Fix single quotes to double quotes
    json_str = json_str.replace("'", '"')
    
    # Remove trailing commas
    json_str = re.sub(r',\s*}', '}', json_str)
    json_str = re.sub(r',\s*]', ']', json_str)
    
    return json_str

def extract_key_value_pairs(text: str) -> dict:
    """Extract bug_type and bug_location from text manually."""
    import re
    
    result = {}
    
    # Patterns to find bug_type and bug_location
    patterns = {
        'bug_type': [
            r'bug_type["\'\s]*[:=]\s*["\']?([^"\'}\s,\n]+)["\']?',
            r'type["\'\s]*[:=]\s*["\']?([^"\'}\s,\n]+)["\']?',
            r'bug["\'\s]*[:=]\s*["\']?([^"\'}\s,\n]+)["\']?',
        ],
        'bug_location': [
            r'bug_location["\'\s]*[:=]\s*["\']?([^"\'}\s,\n]+)["\']?',
            r'location["\'\s]*[:=]\s*["\']?([^"\'}\s,\n]+)["\']?',
            r'tx["\'\s]*[:=]\s*["\']?([^"\'}\s,\n]+)["\']?',
        ]
    }
    
    for key, pattern_list in patterns.items():
        for pattern in pattern_list:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                result[key] = match.group(1).strip()
                break
    
    return result

def olmo_bugs_equal(prediction: str, reference: str) -> bool:
    """
    Compare OLMo Bugs prediction with reference answer.
    
    Both prediction and reference should contain JSON with bug_location and bug_fix.
    Returns True if bug_location matches exactly and bug_fix matches (case-insensitive).
    
    Args:
        prediction: Model's prediction text
        reference: Expected JSON string with bug_location and bug_fix
        
    Returns:
        Boolean indicating if the prediction matches the reference
    """
    try:
        # Extract JSON from prediction text
        pred_json = extract_olmo_bugs_json(prediction)
        if not pred_json:
            return False
        
        # Parse reference JSON
        if isinstance(reference, str):
            try:
                ref_json = json.loads(reference)
            except json.JSONDecodeError:
                return False
        else:
            ref_json = reference
        
        # Compare bug_location (exact match)
        pred_location = pred_json.get('bug_location', '').strip()
        ref_location = ref_json.get('bug_location', '').strip()
        location_match = pred_location == ref_location
        
        # Compare bug_fix (case-insensitive string match)
        pred_fix = pred_json.get('bug_fix', '').strip().lower()
        ref_fix = ref_json.get('bug_fix', '').strip().lower()
        fix_match = pred_fix == ref_fix
        
        return location_match and fix_match
        
    except Exception as e:
        print(f"Error in olmo_bugs_equal: {e}")
        return False

def extract_olmo_bugs_json(text: str) -> dict:
    """
    Extract JSON object from OLMo Bugs prediction text.
    
    The JSON should contain bug_location and bug_fix fields.
    This function tries multiple extraction strategies.
    
    Args:
        text: Model's prediction text
        
    Returns:
        Extracted JSON dict or empty dict if extraction fails
    """
    if not text:
        return {}
    
    try:
        # Strategy 1: Try to parse the entire text as JSON
        text_cleaned = text.strip()
        if text_cleaned.startswith('{') and text_cleaned.endswith('}'):
            try:
                return json.loads(text_cleaned)
            except json.JSONDecodeError:
                pass
        
        # Strategy 2: Look for JSON blocks in the text with more robust patterns
        import re
        
        # Find JSON-like patterns with curly braces - updated for better matching
        json_patterns = [
            # Match multi-line JSON with whitespace
            r'\{[^{}]*?"bug_location"[^{}]*?"bug_fix"[^{}]*?\}',
            r'\{[^{}]*?"bug_fix"[^{}]*?"bug_location"[^{}]*?\}',
            # Match multi-line JSON spanning multiple lines
            r'\{\s*"bug_location"\s*:\s*"[^"]+"\s*,\s*"bug_fix"\s*:\s*"[^"]+"\s*\}',
            r'\{\s*"bug_fix"\s*:\s*"[^"]+"\s*,\s*"bug_location"\s*:\s*"[^"]+"\s*\}',
            # Broader patterns
            r'\{.*?"bug_location".*?"bug_fix".*?\}',
            r'\{.*?"bug_fix".*?"bug_location".*?\}',
            # Match patterns that might have extra whitespace or formatting
            r'\{\s*["\']bug_location["\'].*?["\']bug_fix["\'].*?\}',
            r'\{\s*["\']bug_fix["\'].*?["\']bug_location["\'].*?\}'
        ]
        
        for pattern in json_patterns:
            matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
            for match in matches:
                try:
                    # Clean the match before parsing
                    cleaned_match = match.strip()
                    parsed = json.loads(cleaned_match)
                    if 'bug_location' in parsed and 'bug_fix' in parsed:
                        return parsed
                except json.JSONDecodeError:
                    continue
        
        # Strategy 3: Extract fields using regex if JSON parsing fails
        bug_location = None
        bug_fix = None
        
        # Look for bug_location field
        location_patterns = [
            r'"bug_location"\s*:\s*"([^"]+)"',
            r"'bug_location'\s*:\s*'([^']+)'",
            r'bug_location\s*:\s*"([^"]+)"',
            r'bug_location\s*:\s*([^\s,}]+)',
        ]
        
        for pattern in location_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                bug_location = match.group(1).strip()
                break
        
        # Look for bug_fix field
        fix_patterns = [
            r'"bug_fix"\s*:\s*"([^"]+)"',
            r"'bug_fix'\s*:\s*'([^']+)'",
            r'bug_fix\s*:\s*"([^"]+)"',
            r'bug_fix\s*:\s*([^\s,}]+)',
        ]
        
        for pattern in fix_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                bug_fix = match.group(1).strip()
                break
        
        if bug_location and bug_fix:
            return {
                'bug_location': bug_location,
                'bug_fix': bug_fix
            }
        
        # Strategy 4: Look for structured text patterns
        lines = text.split('\n')
        extracted_fields = {}
        
        for line in lines:
            line = line.strip()
            if 'bug_location' in line.lower():
                # Try to extract value after colon
                if ':' in line:
                    value = line.split(':', 1)[1].strip()
                    value = value.strip('"\'.,')
                    if value:
                        extracted_fields['bug_location'] = value
            elif 'bug_fix' in line.lower():
                if ':' in line:
                    value = line.split(':', 1)[1].strip()
                    value = value.strip('"\'.,')
                    if value:
                        extracted_fields['bug_fix'] = value
        
        if 'bug_location' in extracted_fields and 'bug_fix' in extracted_fields:
            return extracted_fields
        
        return {}
        
    except Exception as e:
        print(f"Error extracting OLMo Bugs JSON: {e}")
        return {}

def bank_transactions_fuzzy_match(prediction: str, reference) -> bool:
    """Fuzzy matching for bank transactions when JSON parsing fails."""
    import re
    
    # Convert reference to dict if needed
    if isinstance(reference, str):
        import json
        try:
            ref_dict = json.loads(reference)
        except:
            return False
    else:
        ref_dict = reference
    
    ref_bug_type = ref_dict.get('bug_type', '').strip().upper()
    ref_bug_location = ref_dict.get('bug_location', '').strip().upper()
    
    # Look for bug type in prediction text
    pred_text = prediction.upper()
    
    # Check if bug type appears in prediction
    type_found = ref_bug_type in pred_text if ref_bug_type else False
    
    # Check if bug location appears in prediction  
    location_found = ref_bug_location in pred_text if ref_bug_location else False
    
    # For fuzzy matching, we're more lenient but still require both
    return type_found and location_found


def is_digit(num):
    """Check if a string represents a number."""
    return parse_digits(num) is not None


def numeric_equal(prediction: float, reference: float):
    """Check numerical equality with tolerance."""
    return isclose(prediction, reference, rel_tol=1e-4, abs_tol=1e-4)


def clean_expr_str(expr_str):
    """Clean mathematical expression strings for better parsing."""
    expr_str = (
        expr_str.replace(" . ", ".")
        .replace(". ", ".")
        .replace("**", "^")
        .replace("\\pm", "")
        .replace("*", "\\times ")
        .replace("\\\\", "\\")
        .replace("\\ne ", "\\neq ")
        .replace("!=", "\\neq")
        .replace(">=", "\\ge")
        .replace("<=", "\\le")
        .replace("≠", "\\neq")
        .replace("dfrac", "frac")
        .replace("tfrac", "frac")
        .replace("\\$", "")
        .replace("$", "")
        .replace("\\%", "")
        .replace("%", "")
        .replace("\\!", "")
        .replace("^\circ", "\\times \\pi / 180")
        .replace("//", "/")
        .replace('"', "")
    )
    
    # Apply regex fixes
    expr_str = re.sub(r"\\+", r"\\", expr_str)
    expr_str = re.sub(r"\^\s?\((.*?)\)", r"^{\1}", expr_str)
    expr_str = re.sub(r"\\frac\s?(\d)\s?(\d+)", r"\\frac{\1}{\2}", expr_str)
    expr_str = re.sub(r"\\sqrt\s?(\d)", r"\\sqrt{\1}", expr_str)
    expr_str = expr_str.replace("\\left", "").replace("\\right.", "").replace("\\right", "")
    
    return expr_str


def extract_answer_from_prediction(pred_str: str) -> str:
    """Extract the final answer from model prediction using multiple heuristics."""
    if not pred_str:
        return ""
    
    # First try to find boxed answer with proper brace matching
    boxed_start = pred_str.find('\\boxed{')
    if boxed_start != -1:
        # Find the matching closing brace
        start_idx = boxed_start + len('\\boxed{')
        brace_count = 1
        end_idx = start_idx
        
        while end_idx < len(pred_str) and brace_count > 0:
            if pred_str[end_idx] == '{':
                brace_count += 1
            elif pred_str[end_idx] == '}':
                brace_count -= 1
            end_idx += 1
        
        if brace_count == 0:
            return pred_str[start_idx:end_idx-1]
    
    # Try to find answer after "Answer:" or "Solution:"
    answer_patterns = [
        r'(?:Answer|answer):\s*([^\n]+)',
        r'(?:Solution|solution):\s*([^\n]+)',
        r'(?:The answer is|the answer is)\s*([^\n.]+)',
        r'(?:Therefore|therefore),?\s*([^\n.]+)',
    ]
    
    for pattern in answer_patterns:
        match = re.search(pattern, pred_str)
        if match:
            return match.group(1).strip()
    
    # Fall back to last number or expression
    numbers = re.findall(r'-?\d+\.?\d*', pred_str)
    if numbers:
        return numbers[-1]
    
    return pred_str.strip()


def symbolic_equal(a, b, timeout=5):
    """Check if two mathematical expressions are symbolically equal."""
    try:
        # Clean expressions
        a_clean = clean_expr_str(str(a))
        b_clean = clean_expr_str(str(b))
        
        # Try direct string comparison first
        if a_clean.replace(" ", "") == b_clean.replace(" ", ""):
            return True
        
        # Try to parse as LaTeX/sympy expressions
        try:
            expr_a = parse_latex(a_clean) if '\\' in a_clean else parse_expr(a_clean)
            expr_b = parse_latex(b_clean) if '\\' in b_clean else parse_expr(b_clean)
            
            # Check if expressions are equal
            return expr_a.equals(expr_b)
        except:
            # Fallback to numerical comparison if possible
            if is_digit(a_clean) and is_digit(b_clean):
                return numeric_equal(parse_digits(a_clean), parse_digits(b_clean))
            
            return False
    except Exception as e:
        print(f"Error in symbolic_equal: {e}")
        return False


def math_equal_process(param):
    """Process function for multiprocessing math equality check."""
    try:
        idx, pred, reference = param
        result = math_equal_enhanced(pred, reference)
        # Ensure result is always boolean
        return bool(result) if result is not None else False
    except Exception as e:
        # Return False for any exceptions
        print(f"Error in math_equal_process: {e}")
        return False

def bank_transactions_equal_process(param):
    """Process function for multiprocessing bank transactions equality check."""
    try:
        idx, pred, reference = param
        result = bank_transactions_equal(pred, reference)
        # Ensure result is always boolean
        return bool(result) if result is not None else False
    except Exception as e:
        # Return False for any exceptions
        print(f"Error in bank_transactions_equal_process: {e}")
        return False


def olmo_bugs_equal_process(param):
    """Multiprocessing wrapper for olmo_bugs_equal comparison."""
    prediction, reference = param
    return olmo_bugs_equal(prediction, reference)

def compute_olmo_bugs_metrics(prediction: str, reference: str) -> Dict[str, bool]:
    """
    Compute separate metrics for OLMo Bugs evaluation.
    
    Args:
        prediction: Model's prediction text
        reference: Expected JSON string with bug_location and bug_fix
        
    Returns:
        Dict with location_correct, fix_correct, and overall_correct flags
    """
    # Extract JSON from prediction text
    pred_json = extract_olmo_bugs_json(prediction)
    
    # Parse reference JSON
    ref_json = json.loads(reference)
    
    if not pred_json:
        return {
            'location_correct': False,
            'fix_correct': False,
            'overall_correct': False,
            'extracted_json': pred_json
        }
    
    # Compare bug_location (exact match)
    pred_location = str(pred_json.get('bug_location', '')).strip()
    ref_location = ref_json.get('bug_location', '').strip()
    location_correct = pred_location == ref_location
    if not location_correct:
        # also check a few variations
        ref_location_variation = ref_location.replace(":L", ":")
        if pred_location == ref_location_variation:
            location_correct = True
    
    # Compare bug_fix (case-insensitive string match)
    pred_fix = pred_json.get('bug_fix', '').strip().lower()
    ref_fix = ref_json.get('bug_fix', '').strip().lower()
    fix_correct = pred_fix == ref_fix
    
    overall_correct = location_correct and fix_correct
    
    return {
        'location_correct': location_correct,
        'fix_correct': fix_correct,
        'overall_correct': overall_correct,
        'extracted_json': pred_json,
        'pred_location': pred_location,
        'ref_location': ref_location,
        'pred_fix': pred_fix,
        'ref_fix': ref_fix
    }

def math_equal_enhanced(prediction: str, reference: str, include_percentage: bool = True) -> bool:
    """Enhanced mathematical equality check combining multiple approaches."""
    if prediction is None or reference is None:
        return False
    
    # Direct string comparison
    if str(prediction).strip().lower() == str(reference).strip().lower():
        return True
    
    # Extract answers from both
    pred_answer = extract_answer_from_prediction(str(prediction))
    ref_answer = str(reference).strip()
    
    # Numerical comparison
    if is_digit(pred_answer) and is_digit(ref_answer):
        pred_num = parse_digits(pred_answer)
        ref_num = parse_digits(ref_answer)
        
        if include_percentage:
            # Check different percentage representations
            candidates = [ref_num, ref_num / 100, ref_num * 100]
            return any(numeric_equal(pred_num, candidate) for candidate in candidates)
        else:
            return numeric_equal(pred_num, ref_num)
    
    # Symbolic comparison
    return symbolic_equal(pred_answer, ref_answer)


# Add comprehensive cleanup function after evaluate_with_vllm function
def cleanup_vllm_memory():
    """
    Comprehensive CUDA memory cleanup after vLLM evaluation.
    This ensures memory is properly freed before returning to training.
    """
    import gc
    import torch
    
    # Force garbage collection
    gc.collect()
    
    # Clear CUDA cache multiple times for thorough cleanup
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()  # Ensure all operations complete
        torch.cuda.empty_cache()  # Clear again after sync
        
        # Reset memory allocator if available
        try:
            torch.cuda.reset_peak_memory_stats()
        except:
            pass
    
    print("🧹 vLLM memory cleanup completed")


def evaluate_with_vllm(
    model_path: str,
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    num_workers: int = 4,
    gpu_memory_utilization: float = 0.8,
    max_length: int = 4096,
    dtype: str = "auto",  # New parameter for dtype consistency
    max_num_seqs: int = None,  # Allow override of max_num_seqs
    max_num_batched_tokens: int = None,  # Allow override of max_num_batched_tokens
    tensor_parallel_size: Optional[int] = None,  # New: allow multi-GPU tensor parallelism
) -> Dict[str, Any]:
    """
    Evaluate using vLLM for fast inference with optional two-phase generation.
    
    Args:
        model_path: Path to saved model directory
        eval_dataset: Dataset to evaluate on
        eval_config: Evaluation configuration
        results_file: Optional file to save results
        silent: Whether to suppress output
        num_samples: Number of samples to evaluate
        num_workers: Number of workers for parallel evaluation
        gpu_memory_utilization: GPU memory utilization for vLLM
        max_length: Maximum sequence length for tokenization
        dtype: Data type for model parameters (e.g., "float16", "bfloat16", "auto")
    """
    if not VLLM_AVAILABLE:
        raise ValueError("vLLM is not available. Install with: pip install vllm")
    
    # Set memory optimization environment variables
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
    os.environ["CUDA_LAUNCH_BLOCKING"] = "0"  # Allow async CUDA operations
    os.environ["VLLM_ENFORCE_EAGER"] = "true"  # Force eager execution to save memory
    
    print(f"🚀 Starting vLLM evaluation with model: {model_path}")
    print(f"   Using dtype: {dtype}")
    
    # Calculate budget allocation for two-phase generation
    assert eval_config.get('reasoning_budget') is not None, "Reasoning budget is not set"
    assert eval_config.get('answer_budget') is not None and eval_config.get('answer_budget') > 0, "Answer budget is not set"
    reasoning_budget = eval_config.get('reasoning_budget')
    answer_budget = eval_config.get('answer_budget')
    print(f"   Reasoning budget: {reasoning_budget} tokens")
    print(f"   Answer budget: {answer_budget} tokens")

    # Initialize vLLM model variable for proper cleanup
    vllm_model = None
    # Setup vLLM
    # Calculate available memory and adjust utilization
    if torch.cuda.is_available():
        # Force garbage collection and clear cache before calculating memory
        import gc
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.synchronize()
        
        free_memory = torch.cuda.get_device_properties(0).total_memory - torch.cuda.memory_allocated(0)
        total_memory = torch.cuda.get_device_properties(0).total_memory
        free_ratio = free_memory / total_memory
        
        # Be much more conservative to avoid OOM during vLLM warm-up
        # Adaptive memory allocation based on available memory - much more conservative
        if free_ratio < 0.15:  # Less than 15% free memory - emergency mode
            gpu_memory_utilization = 0.05  # Only 5% of total memory
            final_max_seqs = 16
            final_max_batched_tokens = 128
            print("🚨 Emergency: Very low memory detected - using minimal settings")
        elif free_ratio < 0.25:  # Less than 25% free memory - ultra-conservative
            gpu_memory_utilization = 0.10  # Only 10% of total memory
            final_max_seqs = 24
            final_max_batched_tokens = 192
            print("⚠️ Very low memory detected - using ultra-conservative settings")
        elif free_ratio < 0.40:  # Less than 40% free memory - conservative
            gpu_memory_utilization = 0.15  # Only 15% of total memory
            final_max_seqs = 32
            final_max_batched_tokens = 256
            print("⚠️ Low memory detected - using conservative settings")
        elif free_ratio < 0.60:  # Less than 60% free memory - moderate
            gpu_memory_utilization = 0.25  # Only 25% of total memory
            final_max_seqs = 48
            final_max_batched_tokens = 384
            print("ℹ️ Moderate memory available - using balanced settings")
        else:  # 60%+ free memory - standard but still conservative
            gpu_memory_utilization = min(0.35, free_ratio * 0.5)  # Max 35% or 50% of free
            final_max_seqs = 64
            final_max_batched_tokens = 512
            print("✅ Good memory availability - using standard settings")
        
        # Additional safety margin - reduce by another 20%
        gpu_memory_utilization = gpu_memory_utilization * 0.8
        
        print(f"GPU Memory: {free_memory/1024**3:.1f}/{total_memory/1024**3:.1f} GiB free ({free_ratio:.1%})")
        print(f"Setting vLLM memory utilization to {gpu_memory_utilization:.2f} ({gpu_memory_utilization * total_memory / 1024**3:.1f} GiB)")
    else:
        # Default values if CUDA not available
        gpu_memory_utilization = 0.8
        final_max_seqs = 64
        final_max_batched_tokens = 512
    
    # Convert dtype string to format vLLM expects
    vllm_dtype = dtype
    if dtype == "float16":
        vllm_dtype = "half"
    elif dtype == "bfloat16":
        vllm_dtype = "bfloat16"
    elif dtype == "auto":
        vllm_dtype = "auto"
    
    print(f"🚀 Using optimized vLLM settings for speed: max_num_seqs={final_max_seqs}, max_num_batched_tokens={final_max_batched_tokens}")
    
    # Additional memory optimization options
    enforce_eager = True  # Always use eager execution for better memory control
    print("⚠️ Using enforce_eager=True for memory optimization")
    
    # SPEED OPTIMIZATION: Disable unnecessary logging and enable performance features
    os.environ["VLLM_CONFIGURE_LOGGING"] = "0"
    os.environ["VLLM_LOGGING_LEVEL"] = "ERROR"
    
    # Add small buffer to max_model_len to account for prompt formatting overhead
    buffer_tokens = 20  # Safety margin for special tokens and formatting
    # Derive model-supported max context length if possible to avoid positional overflows
    from transformers import AutoConfig
    hf_cfg = AutoConfig.from_pretrained(model_path, trust_remote_code=True)
    derived_max_len = None
    if hasattr(hf_cfg, 'max_position_embeddings') and hf_cfg.max_position_embeddings:
        derived_max_len = int(hf_cfg.max_position_embeddings)
    else:
        tkn = getattr(eval_dataset, 'tokenizer', None)
        if tkn is not None and hasattr(tkn, 'model_max_length') and isinstance(tkn.model_max_length, int) and tkn.model_max_length > 0:
            derived_max_len = int(tkn.model_max_length)
    if derived_max_len is None:
        derived_max_len = max_length

    # Decide if we should enable YaRN scaling per Qwen guidance
    enable_yarn = bool(eval_config.get('enable_yarn', False)) or (max_length + buffer_tokens > derived_max_len)
    rope_scaling = None
    if enable_yarn:
        original_max = int(eval_config.get('yarn_orig_max_pos', 32768))
        user_factor = eval_config.get('yarn_factor', None)
        required_factor = math.ceil((max_length + buffer_tokens) / original_max)
        factor = float(user_factor) if user_factor is not None else float(required_factor)
        if factor > 4.0:
            print(f"⚠️ Requested context requires YaRN factor {factor:.1f} (>4). Capping to 4.0 (validated ~131072 tokens).")
            factor = 4.0
        vllm_max_length = min(max_length + buffer_tokens, int(original_max * factor))
        rope_scaling = {
            'rope_type': 'yarn',
            'factor': factor,
            'original_max_position_embeddings': original_max,
        }
        print(f"🧶 Enabling YaRN rope_scaling={rope_scaling}, max_model_len={vllm_max_length}")
    else:
        vllm_max_length = min(max_length + buffer_tokens, derived_max_len)
        if vllm_max_length < (max_length + buffer_tokens):
            print(f"⚠️ Capping vLLM max_model_len to {vllm_max_length} due to model's positional limit ({derived_max_len}).")
        else:
            print(f"🔧 Setting vLLM max_model_len to {vllm_max_length} (configured: {max_length} + buffer: {buffer_tokens})")
    
    # Default to all visible GPUs if not specified
    tp_size = tensor_parallel_size or (torch.cuda.device_count() if torch.cuda.is_available() else 1)
    print(f"🧩 vLLM tensor_parallel_size = {tp_size}")

    # Build kwargs for LLM, adding rope_scaling only if it's a valid dict to satisfy pydantic
    llm_kwargs = {
        'model': model_path,
        'tensor_parallel_size': tp_size,
        'trust_remote_code': True,
        'gpu_memory_utilization': gpu_memory_utilization,
        'max_model_len': vllm_max_length,
        'max_num_seqs': final_max_seqs,
        'max_num_batched_tokens': final_max_batched_tokens,
        'swap_space': 1,
        'disable_log_stats': True,
        'dtype': vllm_dtype,
        'enforce_eager': enforce_eager,
        'enable_prefix_caching': True,
    }
    if isinstance(rope_scaling, dict) and len(rope_scaling) > 0:
        llm_kwargs['rope_scaling'] = rope_scaling

    vllm_model = LLM(**llm_kwargs)
    
    print(f"✅ vLLM model loaded successfully with dtype: {vllm_dtype}")

    # Prepare prompts
    original_prompts = []
    all_problems = []
    
    progress_bar = tqdm(eval_dataset, desc="Preparing prompts") if not silent else eval_dataset
    
    for i, example in enumerate(progress_bar):
        if num_samples and i >= num_samples:
            break
            
        # Handle different input formats from the dataset
        if hasattr(example, 'get') and 'input_text' in example:
            prompt = example['input_text']
        elif 'input_ids' in example:
            # Dataset provides tokenized input, decode it
            prompt = eval_dataset.tokenizer.decode(
                example['input_ids'], 
                skip_special_tokens=True
            )
        else:
            # Fallback: try to construct prompt from available fields
            question = example.get('question', '')
            context = example.get('context', '')
            prompt = f"{context}\n{question}" if context else question

        if reasoning_budget > 0:
            prompt = f"{prompt} /think"
        
        original_prompts.append(prompt)
        all_problems.append(eval_dataset.problems[i] if i < len(eval_dataset.problems) else {})
    
    final_prompts, reasoning_texts, answer_texts = original_prompts, [], []
    if reasoning_budget > 0:
        # Phase 1: Thinking/Reasoning
        print(f"🧠 Phase 1: Generating thinking/reasoning with {reasoning_budget} tokens...")
        
        reasoning_sampling_params = SamplingParams(
            temperature=0.6,
            top_p=0.95,
            top_k=20,
            min_p=0,
            max_tokens=reasoning_budget,
            seed=42,
        )
        
        reasoning_outputs = vllm_model.generate(original_prompts, reasoning_sampling_params)
        reasoning_texts = [output.outputs[0].text for output in reasoning_outputs]
        
        # Create prompts for final answer phase
        final_prompts = []
        for i, (original_prompt, reasoning) in enumerate(zip(original_prompts, reasoning_texts)):
            # Check if reasoning seems complete or needs continuation
            # reasoning_complete = any(marker in reasoning.lower() for marker in [
            #     "</think>", "so the answer is", "final answer", "the result is", 
            #     "in conclusion", "answer:", "the answer is"
            # ])
            
            # if not reasoning_complete:
                # reasoning += "</think>"
            final_prompt = f"{original_prompt}{reasoning}\n\nBased on the reasoning above, the final answer is: /no_think"
            
            final_prompts.append(final_prompt)
    
    # Extract time limit prompting configuration
    use_time_limit = eval_config.get('use_time_limit_prompt', False)
    time_limit_prompt = eval_config.get('time_limit_prompt', "\n\nOkay, time is up. Let me stop thinking and formulate a final answer:")
    final_answer_tokens = eval_config.get('final_answer_tokens', 64)
    
    # SPEED OPTIMIZATION: Faster sampling parameters (greedy)
    sampling_params = SamplingParams(
        temperature=0,
        max_tokens=answer_budget,
        seed=42,
    )
    # Use plain text generation for maximum compatibility
    outputs = vllm_model.generate(final_prompts, sampling_params)

    answer_texts, actual_prompts = [], []
    for i, output in enumerate(outputs):
        answer_texts.append(output.outputs[0].text)
        try:
            actual_prompts.append(eval_dataset.tokenizer.decode(output.prompt_token_ids))
        except Exception:
            actual_prompts.append(final_prompts[i])
    
    # Apply time limit prompting if enabled
    if use_time_limit:
        print(f"🧠 Finally: Generating final answer with {final_answer_tokens} tokens...")
        extended_answer_texts = []
        for i, (answer_text, original_prompt) in enumerate(zip(answer_texts, final_prompts)):
            # Check if answer contains clear final answer indicators
            has_final_answer = any(indicator in answer_text.lower() for indicator in [
                'the answer is', 'final answer', '\\boxed{', 'therefore', 'thus,', 'so the answer'
            ])
            
            if not has_final_answer:
                # Extend with time limit prompt and generate final answer
                extended_prompt = original_prompt + answer_text + time_limit_prompt
                
                # Create final answer sampling params with smaller budget
                final_sampling_params = SamplingParams(
                    temperature=0,
                    max_tokens=final_answer_tokens,
                    seed=42,
                )
                
                # Generate final answer continuation using plain text API
                final_outputs = vllm_model.generate([extended_prompt], final_sampling_params)
                final_answer_part = final_outputs[0].outputs[0].text
                extended_answer = answer_text + time_limit_prompt + final_answer_part
                extended_answer_texts.append(extended_answer)
            else:
                extended_answer_texts.append(answer_text)
        
        answer_texts = extended_answer_texts
    
    # Evaluate predictions
    results = _evaluate_predictions(
        reasoning_texts, answer_texts, all_problems, num_workers, results_file, silent, actual_prompts
    )
    
    return results


def _evaluate_predictions(
    reasoning_texts: List[str],
    answer_texts: List[str],
    problems: List[Dict],
    num_workers: int,
    results_file: Path = None,
    silent: bool = False,
    prompts: List[str] = None,
) -> Dict[str, Any]:
    """Evaluate predictions against ground truth."""
    if prompts is None:
        prompts = [""] * len(answer_texts)  # Fallback for backward compatibility
    
    # Detect dataset type
    is_bank_transactions = False
    is_olmo_bugs = False
    if problems and len(problems) > 0:
        first_problem = problems[0]
        dataset_name = first_problem.get('dataset', '')
        is_bank_transactions = (
            dataset_name == 'bank_transactions_easy' or
            first_problem.get('is_bank_transactions', False)
        )
        is_olmo_bugs = dataset_name.startswith('olmo_bugs_')
    
    # Prepare evaluation parameters
    eval_params = []
    for i, (pred, problem) in enumerate(zip(answer_texts, problems)):
        answer = problem.get('answer', '')
        eval_params.append((i, pred, answer))
    
    # Parallel evaluation
    scores = []
    detailed_metrics = []  # For OLMo bugs detailed metrics
    
    if len(eval_params) > 10 and not is_olmo_bugs:  # Skip multiprocessing for OLMo bugs (needs detailed metrics)
        if not silent:
            print("Using multiprocessing for evaluation...")
        
        # Choose evaluation function based on dataset type
        eval_func = bank_transactions_equal_process if is_bank_transactions else math_equal_process
        if is_bank_transactions and not silent:
            print("Using Bank Transactions evaluation (JSON comparison)...")
            
        with ProcessPool(max_workers=num_workers) as pool:
            future = pool.map(eval_func, eval_params, timeout=3)
            iterator = future.result()
            
            timeout_cnt = 0
            with tqdm(total=len(eval_params), desc="Evaluating") as pbar:
                while True:
                    try:
                        result = next(iterator)
                        scores.append(result)
                    except StopIteration:
                        break
                    except TimeoutError:
                        scores.append(False)
                        timeout_cnt += 1
                    except Exception as error:
                        print(f"Error in evaluation: {error}")
                        scores.append(False)
                    pbar.update(1)
                    
            if timeout_cnt > 0:
                print(f"Warning: {timeout_cnt} evaluations timed out")
    else:
        if not silent:
            print("Using sequential evaluation...")
        
        # Choose evaluation function based on dataset type
        if is_olmo_bugs:
            if not silent:
                print("Using OLMo Bugs evaluation (JSON comparison with detailed metrics)...")
            # For OLMo bugs, we need detailed metrics, so process each individually
            for _, pred, answer in tqdm(eval_params, desc="Evaluating OLMo Bugs"):
                # Combine reasoning and prediction for full model response
                full_response = pred
                if reasoning_texts and len(reasoning_texts) > len(scores):
                    reasoning = reasoning_texts[len(scores)]
                    if reasoning and reasoning.strip():
                        full_response = reasoning + '\n\n' + pred
                
                metrics = compute_olmo_bugs_metrics(full_response, answer)
                scores.append(metrics['overall_correct'])
                detailed_metrics.append(metrics)
        elif is_bank_transactions:
            if not silent:
                print("Using Bank Transactions evaluation (JSON comparison)...")
            scores = [bank_transactions_equal(pred, answer) for _, pred, answer in tqdm(eval_params)]
        else:
            scores = [math_equal_enhanced(pred, answer) for _, pred, answer in tqdm(eval_params)]
    
    # Compile results
    is_correct_list = []
    length_list = []
    examples = []
    level_metrics = {}
    
    # Track OLMo bugs specific metrics
    olmo_bugs_aggregated = {'location_correct': [], 'fix_correct': [], 'overall_correct': []}
    
    for i, (answer, problem, score) in enumerate(zip(answer_texts, problems, scores)):
        # Ensure score is always boolean
        bool_score = bool(score) if score is not None else False
        is_correct_list.append(bool_score)
        length_list.append(len(answer.split()))
        
        # Track per-level metrics
        level = problem.get('level', 'unknown')
        if level not in level_metrics:
            level_metrics[level] = {'correct': 0, 'total': 0}
        level_metrics[level]['total'] += 1
        if bool_score:
            level_metrics[level]['correct'] += 1
        
        # Store examples
        if len(examples) < 100:
            example = {
                'input_prompt': prompts[i] if i < len(prompts) else "",
                'question': problem.get('question', ''),
                'solution': problem.get('solution', ''),
                'answer': problem.get('answer', ''),
                'prediction': extract_answer_from_prediction(answer),
                'reasoning': reasoning_texts[i] if i < len(reasoning_texts) else "",
                'post-reasoning': answer,
                'correct': bool_score,
                'level': level
            }
            
            # Add OLMo bugs specific fields if available
            if is_olmo_bugs and i < len(detailed_metrics):
                metrics = detailed_metrics[i]
                example.update({
                    'location_correct': metrics.get('location_correct', False),
                    'fix_correct': metrics.get('fix_correct', False),
                    'overall_correct': metrics.get('overall_correct', False),
                    'extracted_json': metrics.get('extracted_json', {}),
                    'pred_location': metrics.get('pred_location', ''),
                    'ref_location': metrics.get('ref_location', ''),
                    'pred_fix': metrics.get('pred_fix', ''),
                    'ref_fix': metrics.get('ref_fix', '')
                })
                example['prediction'] = metrics.get('extracted_json', {})
                # Track aggregate metrics
                olmo_bugs_aggregated['location_correct'].append(metrics.get('location_correct', False))
                olmo_bugs_aggregated['fix_correct'].append(metrics.get('fix_correct', False))
                olmo_bugs_aggregated['overall_correct'].append(metrics.get('overall_correct', False))
            
            examples.append(example)
    
    # Compile metrics 
    accuracy_mean = np.mean(is_correct_list) if is_correct_list else 0.0
    accuracy_std = np.std(is_correct_list) if is_correct_list else 0.0
    
    metrics = {
        'answer_accuracy_mean': accuracy_mean,
        'answer_accuracy_std': accuracy_std,
        'total_examples': len(is_correct_list),
        'prediction_length_mean': np.mean(length_list) if length_list else 0.0,
    }
    
    # Add OLMo bugs specific metrics
    if is_olmo_bugs and olmo_bugs_aggregated['overall_correct']:
        metrics.update({
            'location_accuracy_mean': np.mean(olmo_bugs_aggregated['location_correct']),
            'location_accuracy_std': np.std(olmo_bugs_aggregated['location_correct']),
            'fix_accuracy_mean': np.mean(olmo_bugs_aggregated['fix_correct']),
            'fix_accuracy_std': np.std(olmo_bugs_aggregated['fix_correct']),
            'overall_accuracy_mean': np.mean(olmo_bugs_aggregated['overall_correct']),
            'overall_accuracy_std': np.std(olmo_bugs_aggregated['overall_correct']),
            'total_location_correct': sum(olmo_bugs_aggregated['location_correct']),
            'total_fix_correct': sum(olmo_bugs_aggregated['fix_correct']),
            'total_overall_correct': sum(olmo_bugs_aggregated['overall_correct']),
        })
    
    # Add per-level metrics
    for level, level_data in level_metrics.items():
        level_accuracy = level_data['correct'] / level_data['total'] if level_data['total'] > 0 else 0.0
        metrics[f'accuracy_level_{level}'] = level_accuracy
        metrics[f'total_level_{level}'] = level_data['total']
    
    # Print results
    if not silent:
        print(f"\n📊 vLLM Evaluation Results:")
        print(f"  Overall Accuracy: {accuracy_mean:.3f} ± {accuracy_std:.3f}")
        print(f"  Total Examples: {len(is_correct_list)}")
        
        if level_metrics:
            print("\n  Per-Level Results:")
            for level in sorted(level_metrics.keys()):
                level_data = level_metrics[level]
                level_accuracy = level_data['correct'] / level_data['total']
                print(f"    Level {level}: {level_data['correct']}/{level_data['total']} = {level_accuracy:.3f}")
    
    # Save results
    if results_file:
        with open(results_file, 'w') as f:
            json.dump({
                'metrics': metrics,
                'examples': examples,
                'level_breakdown': level_metrics
            }, f, indent=2)
    
    return {
        'metrics': metrics,
        'examples': examples,
        'level_breakdown': level_metrics
    } 


# Helper function to save model for vLLM evaluation
def save_model_for_vllm_eval(model, output_dir: str = None) -> str:
    """
    Save the trained model using TTTLanguageModel's checkpoint mechanism.
    This creates a proper model directory that vLLM can load.
    
    Args:
        model: The trained TTTLanguageModel
        output_dir: Directory to save the model (uses model's output_dir if not provided)
    
    Returns:
        Path to the saved model directory
    """
    if output_dir is None:
        output_dir = getattr(model, 'output_dir', None)
        if output_dir is None:
            raise ValueError("No output_dir specified and model doesn't have output_dir attribute")
    
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    print(f"💾 Saving model for vLLM evaluation to: {output_path}")
    
    # Use the model's existing save_checkpoint method
    model.save_checkpoint(
        checkpoint_path=output_path,
        step=0,  # Dummy step
        epoch=0,  # Dummy epoch  
        loss=0.0  # Dummy loss
    )
    
    # Also save the model in HuggingFace format for vLLM
    model_to_save = model.model.module if hasattr(model.model, 'module') else model.model
    
    if hasattr(model_to_save, 'save_pretrained'):
        model_to_save.save_pretrained(output_path)
    else:
        print("⚠️  Model doesn't have save_pretrained method, using checkpoint only")
    
    # Save tokenizer
    if hasattr(model, 'tokenizer') and model.tokenizer is not None:
        if hasattr(model.tokenizer, 'save_pretrained'):
            model.tokenizer.save_pretrained(output_path)
        else:
            print("⚠️  Tokenizer doesn't have save_pretrained method")
    
    print(f"✅ Model saved successfully for vLLM evaluation")
    return str(output_path) 