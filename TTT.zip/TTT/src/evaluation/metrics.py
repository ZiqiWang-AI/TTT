from typing import List, Dict, Union, Optional
import numpy as np
from sklearn.metrics import accuracy_score
import re
from collections import defaultdict

def compute_metrics(
    predictions: List[List[str]],  # List of lists for multiple samples per question
    answers: List[str],
    budget: Optional[int] = None
) -> Dict[str, float]:
    """
    Compute evaluation metrics for a specific generation budget.
    
    Args:
        predictions: List of lists of model-generated solutions (multiple samples per question)
        answers: List of reference solutions
        budget: Optional token budget used for these predictions
    
    Returns:
        Dictionary containing various metrics
    """
    # Extract final answers for all samples
    pred_answers = predictions
    ref_answers = answers
    
    # Compute metrics across all samples
    all_accuracies = []
    for sample_idx in range(len(predictions[0])):  # For each sample
        # sample_pred_answers = [preds[sample_idx] for preds in pred_answers]
        # accuracy = accuracy_score(ref_answers, sample_pred_answers)
        # just check if answer is in the prediction
        accuracy = sum([answer in preds[sample_idx] for answer, preds in zip(ref_answers, pred_answers)]) / len(pred_answers)
        all_accuracies.append(accuracy)
    
    # Compute majority voting accuracy
    majority_predictions = []
    for pred_list in pred_answers:
        # Get most common answer
        answer_counts = defaultdict(int)
        for ans in pred_list:
            answer_counts[ans] += 1
        majority_pred = max(answer_counts.items(), key=lambda x: x[1])[0]
        majority_predictions.append(majority_pred)
    
    majority_accuracy = accuracy_score(ref_answers, majority_predictions)
    
    metrics = {
        'answer_accuracy_mean': np.mean(all_accuracies),
        'answer_accuracy_std': np.std(all_accuracies),
        'answer_accuracy_majority': majority_accuracy,
    }
    
    if budget is not None:
        metrics = {f'{k}_budget{budget}': v for k, v in metrics.items()}
    
    return metrics

def evaluate_generations(
    model_outputs: List[str],
    solutions: List[str],
    answers: List[str],
    questions: List[str]
) -> Dict:
    """
    Evaluate model generations against references.
    
    Args:
        model_outputs: Either a list of predictions or a dict mapping budgets to lists of predictions
        references: List of reference solutions
        questions: List of questions
    
    Returns:
        Dictionary containing evaluation results and examples
    """
    metrics = {}
    examples = []
    
    # Single predictions mode (backward compatibility)
    metrics = compute_metrics(model_outputs, answers)
    
    for i in range(min(100, len(model_outputs))):
        examples.append({
            'question': questions[i],
            'solution': solutions[i],
            'answer': answers[i],
            'predictions': [out.split('Solution: ')[-1].strip() for out in model_outputs[i]],
            'correct': answers[i] in model_outputs[i]
        })
    
    return {
        'metrics': metrics,
        'examples': examples
    } 