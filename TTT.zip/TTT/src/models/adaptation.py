from typing import Dict, Optional, List
import math
import torch
from torch import nn
from transformers import AutoModelForCausalLM, PreTrainedModel
from peft import (
    get_peft_model,
    LoraConfig,
    PrefixTuningConfig,
    TaskType,
    PeftModel
)

class BaseAdapter:
    """Base class for model adaptation methods."""
    
    def __init__(self, model: PreTrainedModel, config: Dict):
        self.original_model = model
        self.config = config
        self.adapted_model = None
    
    def prepare_model(self) -> PreTrainedModel:
        """Prepare the model for adaptation."""
        raise NotImplementedError
    
    def get_trainable_params(self) -> List[nn.Parameter]:
        """Get parameters that should be trained."""
        raise NotImplementedError
    
    def get_state_dict(self) -> Dict:
        """Get the state dict for saving checkpoints."""
        raise NotImplementedError
    
    def load_state_dict(self, state_dict: Dict):
        """Load state dict from checkpoint."""
        raise NotImplementedError
    
    def reset_parameters(self):
        """Reset adapter parameters to their initial values."""
        raise NotImplementedError
    
    def cleanup(self):
        """Cleanup after adaptation."""
        pass

class FullFineTuningAdapter(BaseAdapter):
    """Adapter for full model fine-tuning."""
    
    def prepare_model(self) -> PreTrainedModel:
        # For full fine-tuning, we just return the original model
        self.adapted_model = self.original_model
        return self.adapted_model
    
    def get_trainable_params(self) -> List[nn.Parameter]:
        return list(self.adapted_model.parameters())
    
    def get_state_dict(self) -> Dict:
        """For full fine-tuning, return the full model state dict."""
        return self.adapted_model.state_dict()
    
    def load_state_dict(self, state_dict: Dict):
        """Load the full model state dict."""
        self.adapted_model.load_state_dict(state_dict)
    
    def reset_parameters(self):
        """Reset parameters to their initial values (full fine-tuning doesn't support this)."""
        raise NotImplementedError("Full fine-tuning adapter doesn't support parameter reset")
    
    def cleanup(self):
        """Cleanup after adaptation."""
        pass

class LoRAAdapter(BaseAdapter):
    """Adapter for LoRA-based adaptation."""
    
    def _get_model_specific_target_modules(self, model_name: str, all_module_names: List[str]) -> List[str]:
        """
        Get model-specific target modules based on model architecture.
        
        Args:
            model_name: Name of the model
            all_module_names: List of all module names in the model
        
        Returns:
            List of valid target module names
        """
        model_name_lower = model_name.lower()
        
        # Get unique module types (last part of module name)
        unique_types = set()
        for name in all_module_names:
            if name:  # Skip empty names
                module_type = name.split('.')[-1]
                unique_types.add(module_type)
        
        # [PERF] 减少日志打印
        # print(f"🔧 Available module types: {sorted(list(unique_types))}")
        
        # Model-specific target module mappings
        if 'qwen' in model_name_lower:
            # Qwen models typically use these module names
            qwen_targets = [
                'q_proj', 'k_proj', 'v_proj', 'o_proj',  # Standard attention
                'gate_proj', 'up_proj', 'down_proj',     # MLP
                'c_attn', 'c_proj',                      # Alternative attention names
                'w1', 'w2', 'w3',                        # Alternative MLP names
            ]
            valid_targets = [t for t in qwen_targets if t in unique_types]
            
        elif 'llama' in model_name_lower:
            # Llama models typically use these module names
            llama_targets = [
                'q_proj', 'k_proj', 'v_proj', 'o_proj',  # Standard attention
                'gate_proj', 'up_proj', 'down_proj',     # MLP
                'self_attn.q_proj', 'self_attn.k_proj', 'self_attn.v_proj', 'self_attn.o_proj',  # Full paths
            ]
            valid_targets = [t for t in llama_targets if t in unique_types]
            
        elif 'mistral' in model_name_lower or 'mixtral' in model_name_lower:
            # Mistral/Mixtral models
            mistral_targets = [
                'q_proj', 'k_proj', 'v_proj', 'o_proj',
                'gate_proj', 'up_proj', 'down_proj',
            ]
            valid_targets = [t for t in mistral_targets if t in unique_types]
            
        else:
            # Generic fallback - try common attention module names
            common_targets = [
                'q_proj', 'k_proj', 'v_proj', 'o_proj',  # Most common
                'query', 'key', 'value', 'dense',        # Alternative names
                'c_attn', 'c_proj',                      # GPT-style
                'gate_proj', 'up_proj', 'down_proj',     # MLP
                'w1', 'w2', 'w3',                        # Alternative MLP
                'fc1', 'fc2',                            # Feed-forward
                'qkv_proj', 'out_proj',                  # Combined attention
            ]
            valid_targets = [t for t in common_targets if t in unique_types]
        
        # If still no valid targets found, use the original config or error
        if not valid_targets:
            # Try the original requested modules
            requested_targets = self.config.get('lora_target_modules', [])
            valid_targets = [t for t in requested_targets if t in unique_types]
            
            if not valid_targets:
                # Last resort: find any Linear layers in attention/mlp blocks
                attention_linear_modules = []
                for name in all_module_names:
                    if any(keyword in name.lower() for keyword in ['attn', 'attention', 'mlp', 'ffn', 'feed_forward']):
                        if name.split('.')[-1] in ['Linear', 'linear']:
                            module_type = name.split('.')[-1]
                            if module_type not in attention_linear_modules:
                                attention_linear_modules.append(module_type)
                
                if attention_linear_modules:
                    valid_targets = attention_linear_modules[:4]  # Take first 4
                    # [PERF] 减少日志
                    # print(f"⚠️  Using fallback Linear modules: {valid_targets}")
        
        return valid_targets
    
    def prepare_model(self) -> PreTrainedModel:
        # If a PEFT model slipped through, unwrap to base to avoid stacking adapters
        try:
            from peft import PeftModel
            if isinstance(self.original_model, PeftModel):
                print("🔄 Unwrapping existing PEFT model before applying new LoRA...")
                self.original_model = self.original_model.get_base_model()
        except Exception:
            pass

        # Remove any stale peft_config attribute left on the base model
        if hasattr(self.original_model, 'peft_config'):
            try:
                delattr(self.original_model, 'peft_config')
                print("🧹 Removed stale peft_config from base model")
            except Exception:
                # Best effort; continue
                pass

        # Get all module names from the model
        all_module_names = [name for name, _ in self.original_model.named_modules()]
        
        # Check if specific target modules are provided in config for frozen KV training
        if 'frozen_kv_target_modules' in self.config and self.config['frozen_kv_target_modules']:
            target_modules = self.config['frozen_kv_target_modules']
            # print(f"🔧 Using custom target modules for frozen KV: {target_modules}")  # [PERF] 减少日志
        else:
            # Get model-specific target modules
            target_modules = self._get_model_specific_target_modules(
                self.original_model.config.name_or_path if hasattr(self.original_model.config, 'name_or_path') else 'unknown',
                all_module_names
            )
        
        # [PERF] 减少冗余日志，只在首次打印
        # print(f"🔧 Model: {getattr(self.original_model.config, 'name_or_path', 'unknown')}")
        # print(f"🔧 Requested target modules: {self.config.get('lora_target_modules', [])}")
        # print(f"🔧 Selected target modules: {target_modules}")
        
        if not target_modules:
            # Final fallback: show available modules for debugging
            unique_types = set()
            for name in all_module_names:
                if name:  # Skip empty names
                    module_type = name.split('.')[-1]
                    unique_types.add(module_type)
            
            raise ValueError(
                f"No valid LoRA target modules found! "
                f"Requested: {self.config.get('lora_target_modules', [])} "
                f"Available module types: {sorted(list(unique_types))}"
            )
        
        # Create LoRA config with detected target modules
        peft_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            r=self.config['lora_r'],
            lora_alpha=self.config['lora_alpha'],
            lora_dropout=self.config['lora_dropout'],
            target_modules=target_modules,
            bias="none",  # Add bias setting for better compatibility
            fan_in_fan_out=False,  # Set explicitly for compatibility
        )
        
        # Apply LoRA to the model
        self.adapted_model = get_peft_model(self.original_model, peft_config)
        
        # Ensure LoRA parameters match base model dtype to reduce memory (e.g., bf16)
        try:
            base_dtype = next(self.original_model.parameters()).dtype
            for name, param in self.adapted_model.named_parameters():
                if 'lora_' in name and param.dtype != base_dtype:
                    param.data = param.data.to(base_dtype)
        except Exception:
            pass

        # CRITICAL FIX: Ensure the model is in training mode and LoRA parameters are trainable
        self.adapted_model.train()
        
        # CRITICAL FIX: Properly freeze base model parameters and enable LoRA parameters
        lora_param_count = 0
        base_param_count = 0
        
        for name, param in self.adapted_model.named_parameters():
            if 'lora_' in name:
                # LoRA parameters should be trainable
                param.requires_grad_(True)
                lora_param_count += 1
            else:
                # Base model parameters should be frozen for LoRA
                param.requires_grad_(False)
                base_param_count += 1
        
        print(f"🔧 Parameter Freezing:")
        print(f"   - LoRA parameters enabled: {lora_param_count}")
        print(f"   - Base parameters frozen: {base_param_count}")
        
        # Double-check that we haven't accidentally frozen LoRA parameters
        actually_trainable = sum(1 for p in self.adapted_model.parameters() if p.requires_grad)
        # [PERF] 简化日志
        # print(f"   - Actually trainable parameters: {actually_trainable}")
        
        if actually_trainable != lora_param_count:
            print(f"   ⚠️  WARNING: Mismatch between LoRA count and trainable count!")
            
            # Try to fix any remaining issues
            for name, param in self.adapted_model.named_parameters():
                if 'lora_' in name and not param.requires_grad:
                    print(f"   🔧 Fixing frozen LoRA parameter: {name}")
                    param.requires_grad_(True)
        
        # [PERF] 简化日志 - 只在有问题时打印详细信息
        # print(f"🔧 LoRA Configuration Applied:")
        # print(f"   - Target modules: {target_modules}")
        # print(f"   - LoRA rank (r): {self.config['lora_r']}")
        # print(f"   - LoRA alpha: {self.config['lora_alpha']}")
        # print(f"   - LoRA dropout: {self.config['lora_dropout']}")
        # print(f"   - Bias: none")
        # print(f"   - Fan in/out: False")
        
        # [PERF] 简化参数摘要日志
        # Verify LoRA parameters
        trainable_params = [p for p in self.adapted_model.parameters() if p.requires_grad]
        lora_params = [p for name, p in self.adapted_model.named_parameters() if 'lora_' in name]
        
        # print(f"🔧 Parameter Summary:")
        # print(f"   - Total trainable parameters: {len(trainable_params)}")
        # print(f"   - LoRA parameters: {len(lora_params)}")
        # print(f"   - LoRA parameters with gradients: {lora_param_count}")
        
        # if trainable_params:
        #     print(f"   - First trainable param shape: {trainable_params[0].shape}")
        #     print(f"   - First trainable param requires_grad: {trainable_params[0].requires_grad}")
        #     print(f"   - First trainable param device: {trainable_params[0].device}")
        
        # if lora_params:
        #     print(f"   - First LoRA param shape: {lora_params[0].shape}")
        #     print(f"   - First LoRA param requires_grad: {lora_params[0].requires_grad}")
        #     print(f"   - First LoRA param device: {lora_params[0].device}")
        if not lora_params:
            raise ValueError("❌ CRITICAL: No LoRA parameters found after adapter application!")
        
        # [PERF] 简化日志
        # Verify model is in training mode
        # print(f"   - Model training mode: {self.adapted_model.training}")
        
        # Additional verification: check if gradients flow properly
        # if lora_params:
        #     test_param = lora_params[0]
        #     if test_param.grad is not None:
        #         print(f"   - Test LoRA param has existing gradients: {test_param.grad is not None}")
        #     print(f"   - Test LoRA param dtype: {test_param.dtype}")
        
        # [PERF] 简化模型结构日志
        # Print model structure summary
        # print(f"🔧 Model Structure Summary:")
        # if hasattr(self.adapted_model, 'peft_config'):
        #     print(f"   - PEFT config: {self.adapted_model.peft_config}")
        # if hasattr(self.adapted_model, 'peft_type'):
        #     print(f"   - PEFT type: {self.adapted_model.peft_type}")
        
        # print("✅ LoRA adapter successfully applied!")
        
        return self.adapted_model
    
    def get_trainable_params(self) -> List[nn.Parameter]:
        """Get only the LoRA parameters that should be trained."""
        if self.adapted_model is None:
            raise ValueError("Model has not been prepared yet. Call prepare_model() first.")
        
        trainable_params = [p for p in self.adapted_model.parameters() if p.requires_grad]
        
        # Double-check that we have LoRA parameters
        lora_params = [p for name, p in self.adapted_model.named_parameters() if 'lora_' in name and p.requires_grad]
        
        if not lora_params:
            # Try to re-enable LoRA parameters
            print("⚠️  WARNING: No LoRA parameters found in get_trainable_params, attempting to re-enable...")
            for name, param in self.adapted_model.named_parameters():
                if 'lora_' in name:
                    param.requires_grad_(True)
            
            lora_params = [p for name, p in self.adapted_model.named_parameters() if 'lora_' in name and p.requires_grad]
        
        # [PERF] 减少日志打印
        # print(f"🔧 get_trainable_params: {len(trainable_params)} total, {len(lora_params)} LoRA")
        
        return trainable_params
    
    def get_state_dict(self) -> Dict:
        """For LoRA, return only the adapter state dict."""
        if isinstance(self.adapted_model, PeftModel):
            # Use PEFT's state dict interface to get adapter weights cleanly
            try:
                return self.adapted_model.state_dict()
            except Exception:
                pass
        # Fallback: return only LoRA weights as tensors (detach to avoid grads)
        lora_only = {}
        for name, param in self.adapted_model.named_parameters():
            if 'lora_' in name:
                lora_only[name] = param.detach().cpu()
        if lora_only:
            return lora_only
        # Final fallback: full model state dict
        return self.adapted_model.state_dict()
    
    def load_state_dict(self, state_dict: Dict):
        """Load LoRA adapter state dict."""
        # Load only the LoRA parameters
        current_state = self.adapted_model.state_dict()
        current_state.update(state_dict)
        self.adapted_model.load_state_dict(current_state, strict=False)
    
    def reset_parameters(self):
        """Reset LoRA parameters to their initial values."""
        if self.adapted_model is None:
            raise ValueError("Model has not been prepared yet. Call prepare_model() first.")
        
        # Reset all LoRA parameters to their initialization values
        for name, module in self.adapted_model.named_modules():
            if hasattr(module, 'lora_A') and hasattr(module, 'lora_B'):
                # Reset LoRA A and B matrices
                if hasattr(module.lora_A, 'default') and hasattr(module.lora_B, 'default'):
                    for adapter_name in module.lora_A.keys():
                        # Re-initialize LoRA A matrix (typically Xavier/Kaiming normal)
                        if hasattr(module.lora_A[adapter_name], 'reset_parameters'):
                            module.lora_A[adapter_name].reset_parameters()
                        else:
                            # Manual reset if reset_parameters not available
                            nn.init.kaiming_uniform_(module.lora_A[adapter_name].weight, a=math.sqrt(5))
                        
                        # Reset LoRA B matrix (typically zeros)
                        if hasattr(module.lora_B[adapter_name], 'reset_parameters'):
                            module.lora_B[adapter_name].reset_parameters()
                        else:
                            # Manual reset to zeros
                            nn.init.zeros_(module.lora_B[adapter_name].weight)
        
        print("🔄 LoRA parameters reset to initial values")
    
    def cleanup(self):
        """Properly cleanup LoRA adapter to avoid accumulation warnings."""
        if isinstance(self.adapted_model, PeftModel):
            try:
                # Unload the adapter without merging to avoid changing base weights
                # [PERF] 减少日志
                # print("🔄 Unloading LoRA adapter...")
                self.adapted_model.unload()
                # print("✅ LoRA adapter unloaded successfully")
            except Exception as e:
                # print(f"⚠️ Warning: Could not unload LoRA adapter: {e}")
                # Fallback: try to merge and unload
                try:
                    self.adapted_model.merge_and_unload()
                    # print("🔄 Fallback: Merged and unloaded LoRA adapter")
                except Exception as e2:
                    print(f"❌ Error: Could not cleanup LoRA adapter: {e2}")

def get_adapter(method: str, model: PreTrainedModel, config: Dict) -> BaseAdapter:
    """Factory function to get appropriate adapter."""
    adapters = {
        'full_ft': FullFineTuningAdapter,
        'lora': LoRAAdapter
    }
    
    if method not in adapters:
        raise ValueError(f"Unknown adaptation method: {method}. Available methods: {list(adapters.keys())}")
    
    return adapters[method](model, config) 