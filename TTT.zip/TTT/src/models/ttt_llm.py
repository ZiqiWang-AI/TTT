import os
import shutil
# Disable tokenizer parallelism to avoid forking warnings
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import random
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer, PreTrainedModel, get_cosine_schedule_with_warmup
from torch.utils.data import DataLoader, Subset
from torch.nn.parallel import DistributedDataParallel as DDP
from accelerate import Accelerator
from functools import partial
from typing import Dict, Optional, List, Union
import logging
from tqdm import tqdm
import gc
import json
import numpy as np
from .adaptation import get_adapter, BaseAdapter
from ..utils.logging_utils import WandBLogger
from ..data.load_dataset import LoadDataset, collate_fn
from ..utils.evaluation_utils import generate_and_evaluate, cleanup_memory
from pathlib import Path
from ..evaluation.enhanced_eval import math_equal_enhanced
from ..utils.rope_utils import maybe_apply_yarn_to_hf_model

logger = logging.getLogger(__name__)

# ========== [OFFLINE MODE] 本地模型路径配置 ==========
LOCAL_MODEL_BASE_PATH = "/fs/scratch/rb_bd_dlp_rng-dl01_cr_AIQ_employees/hkz1sgh/Self_distillation/model_verse"

# 模型名称到本地路径的映射
LOCAL_MODEL_MAPPING = {
    "Qwen/Qwen2.5-0.5B-Instruct": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen2.5-0.5B-Instruct"),
    "Qwen/Qwen2.5-1.5B-Instruct": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen2.5-1.5B-Instruct"),
    "Qwen/Qwen2.5-7B-Instruct": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen2.5-7B-Instruct"),
    "Qwen/Qwen2.5-14B": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen2.5-14B"),
    "Qwen/Qwen2.5-Math-1.5B": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen2.5-Math-1.5B"),
    "Qwen/Qwen2.5-Math-7B": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen2.5-Math-7B"),
    "Qwen/Qwen3-4B": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen3-4B"),
    "Qwen/Qwen3-8B": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen3-8B"),
    "Qwen/Qwen3-14B": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen3-14B"),
    "Qwen/Qwen3.5-9B": os.path.join(LOCAL_MODEL_BASE_PATH, "Qwen3.5-9B"),
}

def get_local_model_path(model_name: str) -> str:
    """获取模型的本地路径，如果有映射则返回本地路径，否则返回原始名称"""
    if model_name in LOCAL_MODEL_MAPPING:
        local_path = LOCAL_MODEL_MAPPING[model_name]
        if os.path.exists(local_path):
            return local_path
        else:
            logger.warning(f"[OFFLINE MODE] 本地模型路径不存在: {local_path}，尝试使用原始名称")
    # 检查是否直接是本地路径
    if os.path.exists(model_name):
        return model_name
    return model_name
# =================================================


def _get_cache_class():
    """Helper function to get Cache class for inheritance."""
    try:
        from transformers.cache_utils import Cache
        return Cache
    except ImportError:
        # Fallback base class if Cache not available
        return object

class ReadOnlyCache(_get_cache_class()):
    """
    A read-only wrapper for Cache objects that prevents in-place modifications.
    This is needed to prevent OOM errors when using frozen KV caches.
    Inherits from Cache to pass isinstance checks in modern transformers.
    """
    def __init__(self, cache):
        from transformers.cache_utils import Cache
        if not isinstance(cache, Cache):
            raise ValueError("ReadOnlyCache expects a Cache object")
        
        # Initialize Cache base class if it exists
        try:
            super().__init__()
        except:
            # Fallback if Cache doesn't have proper __init__
            pass
        
        # Keep references without cloning to avoid doubling memory
        # We enforce non-mutation by overriding update to never write back
        self._cache = cache
        
        # Handle different cache types
        if hasattr(cache, 'key_cache') and hasattr(cache, 'value_cache'):
            # Legacy cache with key_cache/value_cache attributes
            self.key_cache = cache.key_cache
            self.value_cache = cache.value_cache
        elif hasattr(cache, 'to_legacy_cache'):
            # Modern cache with to_legacy_cache method (DynamicCache)
            legacy_cache = cache.to_legacy_cache()
            # Convert legacy tuple format to lists for easier access
            self.key_cache = [layer[0] for layer in legacy_cache]  # Keys
            self.value_cache = [layer[1] for layer in legacy_cache]  # Values
        else:
            # Try to iterate directly and extract keys/values
            try:
                layers = list(cache)
                self.key_cache = [layer[0] for layer in layers]  # Keys
                self.value_cache = [layer[1] for layer in layers]  # Values
            except Exception as e:
                raise ValueError(f"Unsupported cache format: {type(cache)}, error: {e}")
    
    def update(self, key_states, value_states, layer_idx, cache_kwargs=None):
        """
        Override update method to concatenate with cached states but don't store the result.
        This prevents the memory growth that causes OOM errors while maintaining correct attention.
        """
        # Concatenate new states with cached states but don't store in cache
        cached_key = self.key_cache[layer_idx]
        cached_value = self.value_cache[layer_idx]
        
        # Ensure device consistency before concatenation
        import torch
        target_device = cached_key.device
        key_states = key_states.to(target_device)
        value_states = value_states.to(target_device)
        
        # Concatenate but don't store back to cache
        updated_key = torch.cat([cached_key, key_states], dim=-2)
        updated_value = torch.cat([cached_value, value_states], dim=-2)
        
        return updated_key, updated_value
    
    def get_seq_length(self, layer_idx=0):
        """Get sequence length from the cached tensors."""
        if layer_idx < len(self.key_cache):
            return self.key_cache[layer_idx].shape[-2]
        return 0
    
    def get_max_length(self):
        """Get maximum sequence length."""
        return max(k.shape[-2] for k in self.key_cache) if self.key_cache else 0
    
    def __len__(self):
        """Return number of layers."""
        return len(self.key_cache)


class TTTLanguageModel:
    def __init__(
        self,
        model_name: str,
        device: Union[str, int, Dict] = None,  # Deprecated, Accelerate handles device placement
        dtype: str = "bfloat16",
        use_gradient_checkpointing: bool = True,  # Enable for memory efficiency
        use_distributed: bool = False,  # Deprecated, Accelerate handles distributed training
        accelerator_kwargs: Optional[Dict] = None,
        # New context-parallel/sharding flags
        context_parallel: bool = False,
        hf_device_map: Optional[str] = None,
        hf_max_memory_gib: Optional[float] = None,
    ):
        """
        Initialize the test-time training language model with Accelerate integration.
        
        Args:
            model_name: HuggingFace model identifier
            device: [DEPRECATED] Device handled by Accelerate
            dtype: Data type for model parameters
            use_gradient_checkpointing: Whether to use gradient checkpointing to save memory
            use_distributed: [DEPRECATED] Accelerate handles distributed training automatically
            accelerator_kwargs: Additional kwargs for Accelerator initialization
        """
        self.model_name = model_name
        self.dtype = getattr(torch, dtype)
        
        # [OFFLINE MODE] 将模型名称转换为本地路径
        local_model_path = get_local_model_path(model_name)
        if local_model_path != model_name:
            logger.info(f"[OFFLINE MODE] 使用本地模型: {local_model_path}")
        
        # Initialize Accelerator - this handles all distributed setup and device placement
        accelerator_kwargs = accelerator_kwargs or {}
        self.accelerator = Accelerator(**accelerator_kwargs)
        
        # Access distributed training info through Accelerator
        self.device = self.accelerator.device
        self.is_main_process = self.accelerator.is_main_process
        self.num_processes = self.accelerator.num_processes
        self.process_index = self.accelerator.process_index
        
        # Legacy compatibility (deprecated)
        self.use_distributed = use_distributed
        self.world_size = self.num_processes
        self.rank = self.process_index
        self.local_rank = self.process_index
        
        # Load tokenizer
        # [OFFLINE MODE] 从本地路径加载 tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(local_model_path, local_files_only=True)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        
        # Load model with appropriate device mapping
        model_kwargs = {
            'torch_dtype': self.dtype,
            'pad_token_id': self.tokenizer.pad_token_id,
            'device_map': None  # Default: let Accelerate handle placement
        }

        # If context-parallel is requested, shard the model across all GPUs
        if context_parallel:
            try:
                if torch.cuda.is_available():
                    num_gpus = torch.cuda.device_count()
                    # Choose device_map strategy
                    device_map_strategy = hf_device_map if hf_device_map is not None else 'auto'
                    if device_map_strategy in ['balanced', 'balanced_low_0']:
                        # Fallback to 'auto' for from_pretrained; those strategies are not accepted here
                        if self.is_main_process:
                            print(f"ℹ️ device_map='{device_map_strategy}' requested; using device_map='auto' for from_pretrained")
                        device_map_strategy = 'auto'
                    model_kwargs['device_map'] = device_map_strategy
                    # Optionally cap per-GPU memory
                    if hf_max_memory_gib is not None and hf_max_memory_gib > 0:
                        max_mem = {i: f"{int(hf_max_memory_gib)}GiB" for i in range(num_gpus)}
                        model_kwargs['max_memory'] = max_mem
                    if self.is_main_process:
                        print(f"🧩 Enabling context-parallel sharding: device_map={model_kwargs['device_map']}, max_memory={model_kwargs.get('max_memory', None)}")
                else:
                    if self.is_main_process:
                        print("⚠️ context_parallel requested but CUDA not available; proceeding without sharding")
            except Exception as e:
                if self.is_main_process:
                    print(f"⚠️ Failed to configure context-parallel sharding: {e}. Falling back to default device placement.")
        
        self.base_model = AutoModelForCausalLM.from_pretrained(
            local_model_path,  # [OFFLINE MODE] 使用本地模型路径
            local_files_only=True,
            **model_kwargs
        )
        
        # Speed optimizations
        # Prefer FlashAttention-2 if available for faster long-context attention
        if hasattr(self.base_model, 'config') and hasattr(self.base_model.config, 'attn_implementation'):
            self.base_model.config.attn_implementation = 'flash_attention_2'
            if self.is_main_process:
                print("⚡ Using FlashAttention-2 for attention implementation")
        
        # Enable TF32 for faster matmuls on Ampere/Hopper
        torch.backends.cuda.matmul.allow_tf32 = True
        if hasattr(torch, 'set_float32_matmul_precision'):
            torch.set_float32_matmul_precision('high')

        # Enable gradient checkpointing for memory efficiency
        if use_gradient_checkpointing:
            self.base_model.gradient_checkpointing_enable()
        
        # Prepare model with Accelerate - avoid DDP wrapping when sharded via device_map
        if getattr(self.base_model, 'hf_device_map', None) is not None:
            # When using HF sharding, do not wrap with DDP; keep module as-is
            if self.is_main_process:
                print("🚫 Skipping DDP wrapping due to device_map sharding (context-parallel mode)")
        else:
            self.base_model = self.accelerator.prepare(self.base_model)
        
        # Save initial model parameters on CPU to avoid duplicating GPU memory
        model_for_params = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
        # Current adapter being used
        self.current_adapter: Optional[BaseAdapter] = None
        self.model: Optional[PreTrainedModel] = self.base_model
        # Active frozen KV cache for reuse during evaluation
        self._active_frozen_kv = None
        self._active_frozen_kv_len = 0
        
                # Count parameters
        self.num_params_total = sum(p.numel() for p in model_for_params.parameters())
        
        # Print initialization info only on main process
        if self.is_main_process:
            print(f"✅ Model initialized with Accelerate")
            print(f"   Device: {self.device}")
            print(f"   Number of processes: {self.num_processes}")
            print(f"   Process index: {self.process_index}")
            print(f"   Total parameters: {self.num_params_total:,}")
    
    def _ensure_no_active_peft(self):
        """Ensure there is no active PEFT adapter attached to the base model.
        - Cleans up current_adapter if present
        - Unwraps PeftModel to its base transformer
        """
        # Clean up current adapter if tracked
        if getattr(self, 'current_adapter', None) is not None:
            print("🧹 Cleaning up current adapter before attaching a new one...")
            self.current_adapter.cleanup()
            self.current_adapter = None

        # Unwrap PEFT if base model is still wrapped
        try:
            from peft import PeftModel
            base = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
            if isinstance(base, PeftModel):
                print("🔄 Unwrapping PEFT model to base model before attaching new adapter...")
                unwrapped = base.get_base_model()
                # Preserve wrappers consistency
                self.base_model = unwrapped
                self.model = unwrapped
        except Exception as e:
            print(f"⚠️ Warning during PEFT unwrapping: {e}")

    def _get_model_device(self) -> torch.device:
        """Get the device where the model is located."""
        return self.device
    
    def _get_embedding_device(self) -> torch.device:
        """Return the device of the embedding layer for sharded models.
        
        When the model is sharded with a HuggingFace device_map (context-parallel),
        inputs must be placed on the same device as the embedding weights. This
        helper finds that device robustly across architectures.
        """
        try:
            model_for_check = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
            # Prefer finding the actual embedding parameter device
            for name, param in model_for_check.named_parameters():
                if name.endswith('embed_tokens.weight') or '.wte.weight' in name or 'embeddings.word_embeddings.weight' in name:
                    return param.device
        except Exception:
            pass

        # Fallback to device_map if available
        device_map = getattr(self.base_model, 'hf_device_map', None)
        if device_map is not None:
            try:
                # Look for known embedding module names
                for key in ['model.embed_tokens', 'model.model.embed_tokens', 'transformer.wte', 'embed_tokens', 'wte', 'embeddings']:
                    if key in device_map:
                        dev = device_map[key]
                        return torch.device(dev if isinstance(dev, str) else f"cuda:{int(dev)}")
                # Otherwise pick the first listed device
                first_dev = next(iter(device_map.values()))
                return torch.device(first_dev if isinstance(first_dev, str) else f"cuda:{int(first_dev)}")
            except Exception:
                pass

        # Last resort: use accelerator device
        return self._get_model_device()

    def _get_model_max_context_length(self) -> Optional[int]:
        """Get the model's maximum context length from its configuration."""
        model_for_check = self.model.module if hasattr(self.model, 'module') else self.model
        if hasattr(model_for_check, 'config'):
            # Try different config attribute names used by different model architectures
            for attr_name in ['max_position_embeddings', 'n_positions', 'max_sequence_length', 'n_ctx']:
                max_length = getattr(model_for_check.config, attr_name, None)
                if max_length is not None:
                    return int(max_length)
        return None
         
    def prepare_optimizer_and_scheduler(self, optimizer, scheduler=None):
        """Prepare optimizer and scheduler with Accelerate."""
        if scheduler is not None:
            optimizer, scheduler = self.accelerator.prepare(optimizer, scheduler)
            return optimizer, scheduler
        else:
            optimizer = self.accelerator.prepare(optimizer)
            return optimizer
    
    def prepare_dataloader(self, dataloader):
        """Prepare dataloader with Accelerate."""
        return self.accelerator.prepare(dataloader)
    
    def wait_for_everyone(self):
        """Synchronize all processes."""
        self.accelerator.wait_for_everyone()
    
    def _setup_device(self, device: Union[str, int, Dict]) -> str:
        """[DEPRECATED] Setup device configuration - now handled by Accelerate."""
        # This method is kept for backward compatibility but is no longer used
        if isinstance(device, int):
            return f"cuda:{device}"
        elif isinstance(device, str):
            if device == "auto":
                # Will be handled by device_map in model loading
                return "cuda"
            elif device.startswith("cuda"):
                return device
            else:
                return "cuda" if torch.cuda.is_available() else "cpu"
        else:
            return "cuda"

    def _clear_memory(self, aggressive: bool = False):
        """Optimized memory clearing with reduced overhead."""
        if not torch.cuda.is_available():
            return
            
        import gc
        torch.cuda.empty_cache()
        if aggressive:
            gc.collect()
            torch.cuda.synchronize()
    
    def _get_memory_info(self):
        """Get current GPU memory usage information."""
        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated() / 1024**3  # GB
            reserved = torch.cuda.memory_reserved() / 1024**3    # GB
            max_allocated = torch.cuda.max_memory_allocated() / 1024**3  # GB
            return {
                'allocated': allocated,
                'reserved': reserved, 
                'max_allocated': max_allocated,
                'free': reserved - allocated
            }
        return {'allocated': 0, 'reserved': 0, 'max_allocated': 0, 'free': 0}
    
    def _log_memory_usage(self, prefix: str = ""):
        """Log current memory usage - disabled for performance."""
        pass
    
    def _suggest_memory_optimizations(self):
        """Suggest memory optimization settings based on current memory usage."""
        memory_info = self._get_memory_info()
        suggestions = {}
        
        if memory_info['allocated'] > 20:  # > 20GB
            suggestions.update({
                'batch_size': 1,
                'gradient_accumulation_steps': 8,
                'max_length': 2048,
                'use_gradient_checkpointing': True
            })
        elif memory_info['allocated'] > 15:  # > 15GB
            suggestions.update({
                'batch_size': 1,
                'gradient_accumulation_steps': 4,
                'max_length': 4096,
                'use_gradient_checkpointing': True
            })
        elif memory_info['allocated'] > 10:  # > 10GB
            suggestions.update({
                'batch_size': 2,
                'gradient_accumulation_steps': 2,
                'max_length': 8192,
                'use_gradient_checkpointing': True
            })
        else:
            suggestions.update({
                'batch_size': 4,
                'gradient_accumulation_steps': 1,
                'max_length': 16384,
                'use_gradient_checkpointing': False
            })
        
        if self.is_main_process:
            print(f"💡 Memory optimization suggestions based on {memory_info['allocated']:.1f}GB usage:")
            for key, value in suggestions.items():
                print(f"   {key}: {value}")
        
        return suggestions
    
    def reset_parameters(self):
        """Reset model parameters to initial state"""
        # Clear memory first
        self._clear_memory()
        
        # Clean up current adapter if exists
        if self.current_adapter is not None:
            print("🧹 Cleaning up current adapter during reset...")
            self.current_adapter.cleanup()
            self.current_adapter = None
        
        # Reset base model parameters
        if self.initial_params is not None:
            model_for_reset = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
            with torch.no_grad():
                for name, param in model_for_reset.named_parameters():
                    # Copy from CPU snapshot to the param's device
                    param.copy_(self.initial_params[name].to(param.device))
            print("✅ Model parameters reset to initial values")
        else:
            # For device-mapped models, skip parameter reset to avoid memory issues
            print("⚠️ Skipping parameter reset for device-mapped model")
        
        self.model = self.base_model
        self._clear_memory()
    
    def test_time_train(
        self,
        dataset: LoadDataset,
        config: Dict,
        samples_per_epoch: int,
        reset_params: bool = True,
        logger: Optional[WandBLogger] = None,
        max_length: Optional[int] = None,
        eval_dataset: Optional[LoadDataset] = None,
        eval_dataset_secondary: Optional[LoadDataset] = None,
        eval_config: Optional[Dict] = None,
        output_dir: Optional[str] = None,
        use_enhanced_eval: bool = True,
        use_vllm_for_eval: bool = False,
    ):
        """
        Perform test-time training using the provided dataset.
        
        Args:
            dataset: Training dataset
            config: Training configuration
            reset_params: Whether to reset parameters before training
            logger: Optional WandB logger
            max_length: Maximum sequence length for tokenization
            eval_dataset: Optional dataset for intermediate evaluations (primary)
            eval_dataset_secondary: Optional dataset for secondary evaluations (dual evaluation)
            eval_config: Configuration for intermediate evaluations
            output_dir: Directory to save checkpoints and results
            use_enhanced_eval: Whether to use enhanced evaluation
        """
        if reset_params:
            self.reset_parameters()
        
        # Set up adaptation method
        adaptation_config = config.get('adaptation', {})
        method = adaptation_config.get('method', 'full_ft')
        
        if self.is_main_process:  # Only print on main process
            print(f"Using adaptation method: {method}")
        
        # Ensure no prior adapters are attached before applying a new one
        self._ensure_no_active_peft()
        # Get the actual model (unwrap DDP if needed)
        base_model_for_adapter = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
        self.current_adapter = get_adapter(method, base_model_for_adapter, adaptation_config)
        adapted_model = self.current_adapter.prepare_model()
        
        # Re-wrap with DDP if using distributed training
        if self.use_distributed and self.world_size > 1:
            self.model = DDP(
                adapted_model,
                device_ids=[self.local_rank],
                output_device=self.local_rank,
                find_unused_parameters=False
            )
        else:
            self.model = adapted_model
        
        # CRITICAL FIX: Ensure model is in training mode after adapter application
        self.model.train()
        
        # Double-check that LoRA parameters are trainable
        if method == 'lora' and self.rank == 0:
            model_for_check = self.model.module if hasattr(self.model, 'module') else self.model
            trainable_params = [p for p in model_for_check.parameters() if p.requires_grad]
            print(f"🔧 After adapter application:")
            print(f"   - Model training mode: {model_for_check.training}")
            print(f"   - Trainable parameters: {len(trainable_params)}")
            if trainable_params:
                print(f"   - First trainable param requires_grad: {trainable_params[0].requires_grad}")
            else:
                print("   ⚠️  CRITICAL: Still no trainable parameters found!")
        
        # Prepare optimizer
        trainable_params = self.current_adapter.get_trainable_params()
        
        # CRITICAL FIX: Verify trainable parameters for optimizer
        if self.is_main_process:
            print(f"🔧 Optimizer Configuration:")
            print(f"   - Number of trainable parameters: {len(trainable_params)}")
            if trainable_params:
                print(f"   - First param shape: {trainable_params[0].shape}")
                print(f"   - First param requires_grad: {trainable_params[0].requires_grad}")
                print(f"   - Learning rate: {config['learning_rate']}")
            else:
                print("   ⚠️  CRITICAL: No trainable parameters for optimizer!")
                raise ValueError("No trainable parameters found for optimizer!")
        
        optimizer = torch.optim.AdamW(
            trainable_params,
            lr=config['learning_rate'],
            weight_decay=config.get('weight_decay', 0.01),
            betas=config.get('betas', (0.9, 0.999))
        )
        
        # Log model parameter statistics (only on main process)
        if logger is not None and self.rank == 0:
            num_params_trainable = sum(p.numel() for p in trainable_params)
            logger.log_model_summary(
                num_params_total=self.num_params_total,
                num_params_trainable=num_params_trainable
            )
        
        # Create DataLoader with distributed sampler if needed
        batch_size = config.get('batch_size', 1)
        max_seq_length = max_length or config.get('max_length')
        
        # Create partial function with tokenizer and max_length
        collate_fn_with_args = partial(
            collate_fn, 
            tokenizer=self.tokenizer, 
            max_length=max_seq_length
        )
        
        # Setup distributed sampler if using distributed training
        sampler = None
        if self.use_distributed and self.world_size > 1:
            from torch.utils.data.distributed import DistributedSampler
            sampler = DistributedSampler(
                dataset,
                num_replicas=self.world_size,
                rank=self.rank,
                shuffle=True
            )
        
        # Create new random subset for this epoch
        indices = list(range(len(dataset)))
        random.shuffle(indices)  # shuffle to ensure random subset
        subset_indices = indices[:samples_per_epoch]
        
        # Create new subset dataset
        epoch_training_dataset = Subset(dataset, subset_indices)
        
        # Update sampler and dataloader for this epoch
        if self.use_distributed and self.world_size > 1:
            epoch_sampler = DistributedSampler(
                epoch_training_dataset,
                num_replicas=self.world_size,
                rank=self.rank,
                shuffle=True
            )
            epoch_sampler.set_epoch(0)  # Set initial epoch
        else:
            epoch_sampler = None
        
        epoch_dataloader = DataLoader(
            epoch_training_dataset,
            batch_size=batch_size,
            shuffle=(epoch_sampler is None),
            sampler=epoch_sampler,
            collate_fn=collate_fn_with_args
        )
        
        # Calculate total training steps for scheduler (now that we have dataloader)
        num_epochs = config.get('num_epochs', 1)
        steps_per_epoch = len(epoch_dataloader) // config.get('gradient_accumulation_steps', 1)
        total_training_steps = num_epochs * steps_per_epoch
        
        # Setup learning rate scheduler
        scheduler = None
        lr_schedule = config.get('lr_schedule', 'cosine')  # 'cosine', 'linear', or 'constant'
        
        if lr_schedule != 'constant':
            warmup_steps = config.get('warmup_steps', max(1, total_training_steps // 10))  # 10% warmup by default
            
            if lr_schedule == 'cosine':
                scheduler = get_cosine_schedule_with_warmup(
                    optimizer,
                    num_warmup_steps=warmup_steps,
                    num_training_steps=total_training_steps
                )
            elif lr_schedule == 'linear':
                from transformers import get_linear_schedule_with_warmup
                scheduler = get_linear_schedule_with_warmup(
                    optimizer,
                    num_warmup_steps=warmup_steps,
                    num_training_steps=total_training_steps
                )
            
            if self.is_main_process:
                print(f"Using {lr_schedule} learning rate schedule with {warmup_steps} warmup steps out of {total_training_steps} total steps")
        else:
            if self.is_main_process:
                print(f"Using constant learning rate: {config['learning_rate']}")
        
        # Prepare optimizer, scheduler and dataloader with Accelerate  
        if scheduler is not None:
            optimizer, scheduler = self.prepare_optimizer_and_scheduler(optimizer, scheduler)
        else:
            optimizer = self.prepare_optimizer_and_scheduler(optimizer)
        
        epoch_dataloader = self.prepare_dataloader(epoch_dataloader)
        
        if self.is_main_process:
            print(f"Using {len(epoch_training_dataset)} samples (subset of {len(dataset)} total)")
        
        # Set up intermediate evaluation and checkpointing
        eval_every_steps = config.get('eval_every_steps', -1)
        save_every_steps = config.get('save_every_steps', -1)
        
        should_save_or_eval = (save_every_steps != -1 or eval_every_steps != -1) and eval_dataset is not None and eval_config is not None and self.rank == 0
        
        if should_save_or_eval and self.rank == 0:
            if save_every_steps != -1:
                print(f"Saving checkpoints every {save_every_steps} steps")
            if eval_every_steps != -1:
                print(f"Running evaluation every {eval_every_steps} steps")
        
        # Log training setup
        if self.is_main_process:
            if samples_per_epoch is not None and samples_per_epoch < len(dataset):
                print(f"Training setup: {samples_per_epoch} samples per epoch (out of {len(dataset)} total)")
            else:
                print(f"Training setup: Using full dataset ({len(dataset)} samples) each epoch")
        
        # Training loop
        self.model.train()
        
        # CRITICAL FIX: Ensure LoRA parameters are trainable
        if method == 'lora' and self.rank == 0:
            print(f"🔧 LoRA Configuration:")
            print(f"   - Target modules: {adaptation_config.get('lora_target_modules', [])}")
            print(f"   - LoRA rank: {adaptation_config.get('lora_r', 16)}")
            print(f"   - LoRA alpha: {adaptation_config.get('lora_alpha', 32)}")
            print(f"   - LoRA dropout: {adaptation_config.get('lora_dropout', 0.1)}")
            
            # Check if LoRA parameters are properly configured
            model_for_check = self.model.module if hasattr(self.model, 'module') else self.model
            trainable_params = [p for p in model_for_check.parameters() if p.requires_grad]
            lora_params = [p for name, p in model_for_check.named_parameters() if 'lora_' in name]
            print(f"   - Trainable parameters: {len(trainable_params)}")
            print(f"   - LoRA parameters: {len(lora_params)}")
            if trainable_params:
                print(f"   - First trainable param shape: {trainable_params[0].shape}")
                print(f"   - First trainable param requires_grad: {trainable_params[0].requires_grad}")
            if lora_params:
                print(f"   - First LoRA param shape: {lora_params[0].shape}")
                print(f"   - First LoRA param requires_grad: {lora_params[0].requires_grad}")
            else:
                print("   ⚠️  WARNING: No LoRA parameters found!")
                
            # Check if model is in training mode
            print(f"   - Model training mode: {model_for_check.training}")
            print(f"   - Model device: {next(model_for_check.parameters()).device}")
            
            # Final verification that we have trainable parameters
            if not trainable_params:
                raise ValueError("No trainable parameters found! LoRA configuration failed.")
        
        num_epochs = config.get('num_epochs', 1)
        total_steps = 0
        
        for epoch in range(num_epochs):
            # Set epoch for distributed sampler
            if sampler is not None:
                sampler.set_epoch(epoch)
            
            epoch_loss = 0
            if self.is_main_process:  # Only show progress on main process
                progress_bar = tqdm(epoch_dataloader, desc=f"Epoch {epoch+1}/{num_epochs}")
            else:
                progress_bar = epoch_dataloader
            
            accumulated_loss = 0
            for batch_idx, batch in enumerate(progress_bar):
                # Handle checkpoint saving and/or evaluation
                if (save_every_steps != -1 and total_steps % save_every_steps == 0):
                    if save_every_steps != -1 and total_steps % save_every_steps == 0:
                        print(f"\nSaving checkpoint at step {total_steps}...")
                        checkpoint_path = output_dir / f"step_{total_steps}"
                        self.save_checkpoint(checkpoint_path, total_steps, epoch, accumulated_loss)
                        print(f"Checkpoint saved to {checkpoint_path}")
                
                if eval_every_steps != -1 and total_steps % eval_every_steps == 0:
                    print(f"\nRunning intermediate evaluation at step {total_steps}...")
                    
                    # CRITICAL FIX: Set model to eval mode and save current training state
                    was_training = self.model.training
                    self.model.eval()
                    
                    eval_checkpoint_path = None
                    if use_vllm_for_eval:
                        # Save checkpoint before evaluation for vLLM
                        eval_checkpoint_path = output_dir / f"step_{total_steps}" if output_dir else None
                        if eval_checkpoint_path and not eval_checkpoint_path.exists():
                            print(f"💾 Saving checkpoint for evaluation: {eval_checkpoint_path}")
                            self.save_checkpoint(eval_checkpoint_path, total_steps, epoch, accumulated_loss)
                    
                    # Primary evaluation
                    eval_results = generate_and_evaluate(
                        model=self,
                        eval_dataset=eval_dataset,
                        max_length=max_seq_length,
                        eval_config=eval_config,
                        results_file=output_dir / f"results@step={total_steps}.json" if output_dir else None,
                        silent=False,
                        use_enhanced=use_enhanced_eval,
                        checkpoint_path=str(eval_checkpoint_path) if eval_checkpoint_path else None,
                        use_vllm_for_eval=use_vllm_for_eval,
                    )

                    # Secondary evaluation (if available)
                    eval_results_secondary = None
                    if eval_dataset_secondary is not None:
                        print(f"Running secondary evaluation at step {total_steps}...")
                        eval_results_secondary = generate_and_evaluate(
                            model=self,
                            eval_dataset=eval_dataset_secondary,
                            max_length=max_seq_length,
                            eval_config=eval_config,
                            results_file=output_dir / f"results_secondary@step={total_steps}.json" if output_dir else None,
                            silent=False,
                            use_enhanced=use_enhanced_eval,
                            checkpoint_path=str(eval_checkpoint_path) if eval_checkpoint_path else None,
                            use_vllm_for_eval=use_vllm_for_eval,
                        )

                    if use_vllm_for_eval:
                        # Delete checkpoint after evaluation
                        if eval_checkpoint_path and eval_checkpoint_path.exists():
                            print(f"🗑️ Deleting checkpoint after evaluation: {eval_checkpoint_path}")
                            shutil.rmtree(eval_checkpoint_path)
                    
                    # CRITICAL FIX: Restore training mode
                    if was_training:
                        self.model.train()
                    
                    if logger is not None:
                        # Log primary evaluation results
                        for metric_name, metric_value in eval_results['metrics'].items():
                            logger.log_metric(f"eval/{metric_name}", metric_value, step=total_steps)
                        
                        # Log secondary evaluation results (if available)
                        if eval_results_secondary is not None:
                            for metric_name, metric_value in eval_results_secondary['metrics'].items():
                                logger.log_metric(f"eval_secondary/{metric_name}", metric_value, step=total_steps)
                            
                            # Log comparison metrics
                            primary_accuracy = eval_results['metrics']['answer_accuracy_mean']
                            secondary_accuracy = eval_results_secondary['metrics']['answer_accuracy_mean']
                            accuracy_diff = secondary_accuracy - primary_accuracy
                            
                            logger.log_metric("eval_comparison/accuracy_difference", accuracy_diff, step=total_steps)
                            logger.log_metric("eval_comparison/primary_accuracy", primary_accuracy, step=total_steps)
                            logger.log_metric("eval_comparison/secondary_accuracy", secondary_accuracy, step=total_steps)
                    
                    print(f"Primary evaluation completed: accuracy = {eval_results['metrics']['answer_accuracy_mean']:.3f}")
                    if eval_results_secondary is not None:
                        print(f"Secondary evaluation completed: accuracy = {eval_results_secondary['metrics']['answer_accuracy_mean']:.3f}")
                        print(f"Accuracy difference (secondary - primary): {eval_results_secondary['metrics']['answer_accuracy_mean'] - eval_results['metrics']['answer_accuracy_mean']:.3f}")
                    print(f"🔄 Resuming training...")
                
                # Clear memory before processing batch
                self._clear_memory()
                
                # Reduced logging for performance
                if batch_idx % 4 == 0 and self.is_main_process:
                    print(f"Train batch {batch_idx}: {batch['input_ids'].shape}")
                
                input_ids = batch['input_ids']
                attention_mask = batch['attention_mask']
                labels = batch['labels']
                
                # CRITICAL FIX: Ensure all tensors are on the correct device for sharded models
                is_sharded = getattr(self.base_model, 'hf_device_map', None) is not None
                
                if is_sharded:
                    # For sharded models, move inputs to the embedding device
                    embed_device = self._get_embedding_device()
                    if input_ids.device != embed_device:
                        input_ids = input_ids.to(embed_device)
                    if attention_mask.device != embed_device:
                        attention_mask = attention_mask.to(embed_device)
                    if labels.device != embed_device:
                        labels = labels.to(embed_device)
                
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                loss = outputs.loss / config['gradient_accumulation_steps']
                accumulated_loss += loss.item()
                
                # CRITICAL FIX: Ensure loss has gradients enabled for LoRA
                if method == 'lora' and not loss.requires_grad:
                    print(f"⚠️  WARNING: Loss tensor does not require gradients!")
                    print(f"   - Loss shape: {loss.shape}")
                    print(f"   - Loss requires_grad: {loss.requires_grad}")
                    print(f"   - Loss grad_fn: {loss.grad_fn}")
                    
                    # Try to enable gradients on the loss
                    loss.requires_grad_(True)
                    print(f"   - After fix, loss requires_grad: {loss.requires_grad}")
                
                # Backward pass with Accelerate
                self.accelerator.backward(loss)
                
                # Clear intermediate tensors
                del input_ids, attention_mask, labels, outputs, loss
                
                # More aggressive cleanup for long sequences
                if batch_idx % 2 == 0:
                    self._clear_memory(aggressive=False)
                
                # Update parameters when we've accumulated enough gradients
                if batch_idx % config['gradient_accumulation_steps'] == 0:
                    # Update parameters
                    torch.nn.utils.clip_grad_norm_(trainable_params, config['max_grad_norm'])
                    optimizer.step()
                    
                    # Update learning rate scheduler
                    current_lr = config['learning_rate']  # Default fallback
                    if scheduler is not None:
                        scheduler.step()
                        current_lr = scheduler.get_last_lr()[0]
                    
                    optimizer.zero_grad()
                    
                    epoch_loss += accumulated_loss
                    total_steps += 1
                    
                    # Log metrics (only on main process)
                    if logger is not None and self.rank == 0:
                        logger.log_training_step(
                            loss=accumulated_loss,
                            learning_rate=current_lr,
                            step=total_steps,
                            epoch=epoch,
                            grad_norm=torch.nn.utils.clip_grad_norm_(trainable_params, float('inf')).item()
                        )

                    # Update progress bar (only on main process)
                    if self.rank == 0 and hasattr(progress_bar, 'set_postfix'):
                        progress_bar.set_postfix({
                            'loss': accumulated_loss, 
                            'avg_epoch_loss': epoch_loss/(total_steps+1),
                            'step': total_steps,
                            'lr': f'{current_lr:.2e}'
                        })
                    
                    # Reset accumulated loss
                    accumulated_loss = 0
            
            # Handle remaining gradients if not evenly divisible
            if batch_idx % config['gradient_accumulation_steps'] != 0:
                torch.nn.utils.clip_grad_norm_(trainable_params, config['max_grad_norm'])
                optimizer.step()
                
                # Update learning rate scheduler
                current_lr = config['learning_rate']  # Default fallback
                if scheduler is not None:
                    scheduler.step()
                    current_lr = scheduler.get_last_lr()[0]
                
                optimizer.zero_grad()
                epoch_loss += accumulated_loss
                total_steps += 1
                    
                # Log metrics (only on main process)
                if logger is not None and self.rank == 0:
                    logger.log_training_step(
                        loss=accumulated_loss,
                        learning_rate=current_lr,
                        step=total_steps,
                        epoch=epoch,
                        grad_norm=torch.nn.utils.clip_grad_norm_(trainable_params, float('inf')).item()
                    )

                # Update progress bar (only on main process)
                if self.rank == 0 and hasattr(progress_bar, 'set_postfix'):
                    progress_bar.set_postfix({
                        'loss': accumulated_loss, 
                        'avg_epoch_loss': epoch_loss/(total_steps+1),
                        'step': total_steps,
                        'lr': f'{current_lr:.2e}'
                    })
                
                # Reset accumulated loss
                accumulated_loss = 0
            
            avg_epoch_loss = epoch_loss / len(epoch_dataloader)
            if self.is_main_process:
                print(f"Epoch {epoch+1} completed. Average loss: {avg_epoch_loss:.4f}")
            
            # Optional end-of-epoch evaluation
            run_epoch_eval = config.get('run_epoch_eval', False)
            if run_epoch_eval and eval_dataset is not None and eval_config is not None and self.rank == 0:
                print(f"\nRunning end-of-epoch evaluation...")
                
                # CRITICAL FIX: Set model to eval mode and save current training state
                was_training = self.model.training
                self.model.eval()
                
                # Save checkpoint for end-of-epoch evaluation
                epoch_checkpoint_path = output_dir / f"epoch_{epoch}" if output_dir else None
                if epoch_checkpoint_path and not epoch_checkpoint_path.exists():
                    print(f"💾 Saving checkpoint for epoch evaluation: {epoch_checkpoint_path}")
                    self.save_checkpoint(epoch_checkpoint_path, total_steps, epoch, avg_epoch_loss)
                
                # Primary evaluation
                eval_results = generate_and_evaluate(
                    model=self,
                    eval_dataset=eval_dataset,
                    max_length=max_seq_length,
                    eval_config=eval_config,
                    results_file=output_dir / f"results@epoch={epoch}.json" if output_dir else None,
                    use_enhanced=use_enhanced_eval,
                    checkpoint_path=str(epoch_checkpoint_path) if epoch_checkpoint_path else None,
                    use_vllm_for_eval=use_vllm_for_eval,
                )
                
                # Secondary evaluation (if available)
                eval_results_secondary = None
                if eval_dataset_secondary is not None:
                    print(f"Running secondary evaluation for epoch {epoch}...")
                    eval_results_secondary = generate_and_evaluate(
                        model=self,
                        eval_dataset=eval_dataset_secondary,
                        max_length=max_seq_length,
                        eval_config=eval_config,
                        results_file=output_dir / f"results_secondary@epoch={epoch}.json" if output_dir else None,
                        use_enhanced=use_enhanced_eval,
                        checkpoint_path=str(epoch_checkpoint_path) if epoch_checkpoint_path else None,
                        use_vllm_for_eval=use_vllm_for_eval,
                    )

                if use_vllm_for_eval:
                    # Delete checkpoint after evaluation
                    if epoch_checkpoint_path and epoch_checkpoint_path.exists():
                        print(f"🗑️ Deleting checkpoint after evaluation: {epoch_checkpoint_path}")
                        shutil.rmtree(epoch_checkpoint_path)
                
                # CRITICAL FIX: Restore training mode
                if was_training:
                    self.model.train()

                if logger is not None:
                    # Log primary evaluation results
                    for metric_name, metric_value in eval_results['metrics'].items():
                        logger.log_metric(f"eval/{metric_name}", metric_value, step=total_steps)
                        logger.log_metric(f"eval/epoch_{metric_name}", metric_value, step=epoch+1)
                    
                    # Log secondary evaluation results (if available)
                    if eval_results_secondary is not None:
                        for metric_name, metric_value in eval_results_secondary['metrics'].items():
                            logger.log_metric(f"eval_secondary/{metric_name}", metric_value, step=total_steps)
                            logger.log_metric(f"eval_secondary/epoch_{metric_name}", metric_value, step=epoch+1)
                        
                        # Log comparison metrics
                        primary_accuracy = eval_results['metrics']['answer_accuracy_mean']
                        secondary_accuracy = eval_results_secondary['metrics']['answer_accuracy_mean']
                        accuracy_diff = secondary_accuracy - primary_accuracy
                        
                        logger.log_metric("eval_comparison/accuracy_difference", accuracy_diff, step=total_steps)
                        logger.log_metric("eval_comparison/epoch_accuracy_difference", accuracy_diff, step=epoch+1)
                
                print(f"Primary evaluation completed: accuracy = {eval_results['metrics']['answer_accuracy_mean']:.3f}")
                if eval_results_secondary is not None:
                    print(f"Secondary evaluation completed: accuracy = {eval_results_secondary['metrics']['answer_accuracy_mean']:.3f}")
                    print(f"Accuracy difference (secondary - primary): {eval_results_secondary['metrics']['answer_accuracy_mean'] - eval_results['metrics']['answer_accuracy_mean']:.3f}")
                print(f"🔄 Resuming training...")
            
            # Log epoch-level metrics (only on main process)
            if logger is not None and self.rank == 0:
                logger.log_epoch_summary(
                    epoch=epoch,
                    avg_loss=avg_epoch_loss,
                    total_batches=len(epoch_dataloader)
                )
            
            # Clear memory after epoch
            self._clear_memory()
        
        # Save final trained model after all epochs complete
        # if output_dir and self.rank == 0:
        #     final_checkpoint_path = Path(output_dir) / "final_model"
        #     print(f"\n🎯 Training completed! Saving final model to {final_checkpoint_path}")
        #     self.save_checkpoint(final_checkpoint_path, total_steps, num_epochs, avg_epoch_loss)
            
        #     # Also save it as the default model for easy loading
        #     default_model_path = Path(output_dir) / "model"
        #     if not default_model_path.exists():
        #         print(f"💾 Creating symlink at {default_model_path} -> {final_checkpoint_path}")
        #         try:
        #             default_model_path.symlink_to(final_checkpoint_path.name)
        #         except Exception as e:
        #             print(f"⚠️  Could not create symlink: {e}")
        #             # Copy instead of symlink
        #             if final_checkpoint_path.exists():
        #                 shutil.copytree(final_checkpoint_path, default_model_path)
        #                 print(f"📁 Copied final model to {default_model_path}")
    
    def test_time_train_grpo(
        self,
        dataset: LoadDataset,
        config: Dict,
        samples_per_epoch: int,
        reset_params: bool = True,
        logger: Optional[WandBLogger] = None,
        max_length: Optional[int] = None,
        eval_dataset: Optional[LoadDataset] = None,
        eval_dataset_secondary: Optional[LoadDataset] = None,
        eval_config: Optional[Dict] = None,
        output_dir: Optional[str] = None,
        use_enhanced_eval: bool = True,
        use_vllm_for_eval: bool = False,
    ):
        """
        Perform test-time training using GRPO (Group Relative Policy Optimization).
        
        This method samples multiple trajectories for each problem and learns from
        correct/incorrect reasoning paths using reinforcement learning.
        
        Args:
            dataset: Training dataset
            config: Training configuration (should include grpo_config)
            samples_per_epoch: Number of training samples per epoch
            reset_params: Whether to reset parameters before training
            logger: Optional WandB logger
            max_length: Maximum sequence length for tokenization
            eval_dataset: Optional dataset for intermediate evaluations
            eval_dataset_secondary: Optional dataset for secondary evaluations
            eval_config: Configuration for intermediate evaluations
            output_dir: Directory to save checkpoints and results
            use_enhanced_eval: Whether to use enhanced evaluation
            use_vllm_for_eval: Whether to use vLLM for evaluation
        """
        from trl import GRPOConfig, GRPOTrainer
        from transformers import TrainerCallback, TrainerControl, TrainerState
        
        if reset_params:
            self.reset_parameters()
        
        # Set up adaptation method
        adaptation_config = config.get('adaptation', {})
        method = adaptation_config.get('method', 'full_ft')
        
        if self.is_main_process:
            print(f"🔄 Using GRPO with adaptation method: {method}")
        
        # Ensure no prior adapters are attached before applying a new one
        self._ensure_no_active_peft()
        # Get the actual model (unwrap DDP if needed)
        base_model_for_adapter = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
        self.current_adapter = get_adapter(method, base_model_for_adapter, adaptation_config)
        adapted_model = self.current_adapter.prepare_model()
        
        # For GRPO, we need the model without DDP wrapper initially
        self.model = adapted_model
        
        # Set up intermediate evaluation and checkpointing
        eval_every_steps = config.get('eval_every_steps', -1)
        save_every_steps = config.get('save_every_steps', -1)
        
        if self.is_main_process:
            if save_every_steps != -1:
                print(f"Saving checkpoints every {save_every_steps} steps")
            if eval_every_steps != -1:
                print(f"Running evaluation every {eval_every_steps} steps")
        
        # GRPO configuration with correct TRL parameters
        grpo_config = GRPOConfig(
            output_dir=str(output_dir) if output_dir else "./grpo_output",
            learning_rate=config['learning_rate'],
            per_device_train_batch_size=config.get('batch_size', 1),
            gradient_accumulation_steps=config.get('gradient_accumulation_steps', 4),
            max_grad_norm=config.get('max_grad_norm', 1.0),
            num_train_epochs=config.get('num_epochs', 1),
            weight_decay=config.get('weight_decay', 0.01),
            warmup_steps=config.get('warmup_steps', 10),
            lr_scheduler_type=config.get('lr_schedule', 'cosine'),
            
            # GRPO specific parameters (corrected names)
            num_generations=config.get('num_samples_per_prompt', 16),
            temperature=config.get('temperature', 0.7),
            top_p=config.get('top_p', 0.9),
            max_completion_length=config.get('answer_budget', 512),
            
            # Logging
            logging_steps=4,
            save_steps=config.get('save_every_steps', -1) if config.get('save_every_steps', -1) > 0 else 500,
            eval_steps=config.get('eval_every_steps', 4) if config.get('eval_every_steps', -1) > 0 else 500,
            
            # Additional useful parameters
            beta=0.0,  # No KL penalty as recommended in recent papers
            remove_unused_columns=False,  # Keep all columns for reward function

            # logging
            wandb_log_unique_prompts=False,
            # log_completions=True,
        )
        
        # Create reward function for math problems
        def math_reward_function(completions, raw_answers, **kwargs) -> List[float]:
            """
            Reward function for math problems.
            Returns 1.0 for correct answers, 0.0 for incorrect answers.
            
            Args:
                completions: List of generated completions
                raw_answers: List of correct answers from the dataset
                **kwargs: Additional arguments passed by TRL
            """
            rewards = []
            
            # Use enhanced evaluation 
            from ..evaluation.enhanced_eval import math_equal_enhanced
            use_enhanced = True
            
            for completion, answer in zip(completions, raw_answers):
                if use_enhanced:
                    # Use enhanced math comparison
                    is_correct = math_equal_enhanced(completion, answer)
                else:
                    # Fallback to simple string matching
                    is_correct = answer in completion if completion else False
                
                rewards.append(1.0 if is_correct else 0.0)
            
            return rewards
        
        # Prepare dataset for GRPO
        max_seq_length = max_length or config.get('max_length', 4096)
        
        # Create subset for this epoch
        indices = list(range(len(dataset)))
        random.shuffle(indices)
        subset_indices = indices[:samples_per_epoch]
        
        # Create training examples for GRPO (TRL format)
        training_examples = []
        for idx in subset_indices:
            example = dataset[idx]
            
            # Prepare prompt (input without the solution)
            prompt = self.tokenizer.decode(example['input_ids'], skip_special_tokens=True)
            
            # Remove solution part to get just the question
            if 'Solution:' in prompt:
                prompt = prompt.split('Solution:')[0].strip()
            
            # Get the reference answer
            raw_answer = example['raw_answer']
            
            training_examples.append({
                'prompt': prompt,  # TRL expects 'prompt' column
                'raw_answers': raw_answer,  # Custom column for reward function
            })
        
        if self.is_main_process:
            print(f"📊 Prepared {len(training_examples)} training examples for GRPO")
        
        # Convert to HuggingFace Dataset
        from datasets import Dataset
        training_dataset = Dataset.from_list(training_examples)
        
        # Prepare evaluation dataset for GRPO trainer (if provided)
        eval_dataset_for_grpo = None
        if eval_dataset is not None:
            # Convert a subset of evaluation dataset to GRPO format
            eval_examples = []
            num_eval_examples = len(eval_dataset)
            
            for i in range(num_eval_examples):
                example = eval_dataset[i]
                
                # Prepare prompt (input without the solution)
                prompt = self.tokenizer.decode(example['input_ids'], skip_special_tokens=True)
                
                # Remove solution part to get just the question
                if 'Solution:' in prompt:
                    prompt = prompt.split('Solution:')[0].strip()
                
                # Get the reference answer
                raw_answer = example['raw_answer']
                
                eval_examples.append({
                    'prompt': prompt,
                    'raw_answers': raw_answer,
                })
            
            eval_dataset_for_grpo = Dataset.from_list(eval_examples)
            
            if self.is_main_process:
                print(f"📊 Prepared {len(eval_examples)} evaluation examples for GRPO intermediate evaluation")
        
        # Create custom callback for full evaluation (like vanilla TTT)
        class FullEvaluationCallback(TrainerCallback):
            def __init__(self, ttt_model, eval_dataset, eval_dataset_secondary, eval_config, 
                         max_seq_length, output_dir, use_enhanced_eval, use_vllm_for_eval, 
                         eval_every_steps, logger, rank):
                self.ttt_model = ttt_model
                self.eval_dataset = eval_dataset
                self.eval_dataset_secondary = eval_dataset_secondary
                self.eval_config = eval_config
                self.max_seq_length = max_seq_length
                self.output_dir = output_dir
                self.use_enhanced_eval = use_enhanced_eval
                self.use_vllm_for_eval = use_vllm_for_eval
                self.eval_every_steps = eval_every_steps
                self.logger = logger
                self.rank = rank
                self._has_run_initial_eval = False

            def run_full_eval(self, state, control):
                if (self.rank == 0 and self.eval_every_steps != -1 and 
                    self.eval_dataset is not None and self.eval_config is not None):
                    print(f"\n🔍 Running GRPO full evaluation at step {state.global_step}...")
                    was_training = self.ttt_model.model.training
                    self.ttt_model.model.eval()
                    eval_checkpoint_path = None
                    if self.use_vllm_for_eval:
                        eval_checkpoint_path = self.output_dir / f"step_{state.global_step}" if self.output_dir else None
                        if eval_checkpoint_path and not eval_checkpoint_path.exists():
                            print(f"💾 Saving checkpoint for evaluation: {eval_checkpoint_path}")
                            self.ttt_model.save_checkpoint(eval_checkpoint_path, state.global_step, 
                                                         state.epoch, state.log_history[-1].get('train_loss', 0.0) if state.log_history else 0.0)
                    eval_results = generate_and_evaluate(
                        model=self.ttt_model,
                        eval_dataset=self.eval_dataset,
                        max_length=self.max_seq_length,
                        eval_config=self.eval_config,
                        results_file=self.output_dir / f"results@step={state.global_step}.json" if self.output_dir else None,
                        silent=False,
                        use_enhanced=self.use_enhanced_eval,
                        checkpoint_path=str(eval_checkpoint_path) if eval_checkpoint_path else None,
                        use_vllm_for_eval=self.use_vllm_for_eval,
                    )
                    if self.use_vllm_for_eval:
                        if eval_checkpoint_path and eval_checkpoint_path.exists():
                            print(f"🗑️ Deleting checkpoint after evaluation: {eval_checkpoint_path}")
                            shutil.rmtree(eval_checkpoint_path)
                    if was_training:
                        self.ttt_model.model.train()
                    if self.logger is not None:
                        print(f"Logging metrics for step {state.global_step}")
                        for metric_name, metric_value in eval_results['metrics'].items():
                            print(f"Logging metric: {metric_name} = {metric_value}")
                            self.logger.log_metric(f"eval/{metric_name}", metric_value, step=state.global_step)
                    print(f"Primary evaluation completed: accuracy = {eval_results['metrics']['answer_accuracy_mean']:.3f}")
                    print(f"🔄 Resuming GRPO training...")
                return control

            def on_train_begin(self, args, state: TrainerState, control: TrainerControl, **kwargs):
                # Run evaluation at step 0 before training starts
                if not self._has_run_initial_eval:
                    state.global_step = 0
                    self.run_full_eval(state, control)
                    self._has_run_initial_eval = True
                return control

            def on_step_end(self, args, state: TrainerState, control: TrainerControl, **kwargs):
                if (self.rank == 0 and self.eval_every_steps != -1 and 
                    state.global_step % self.eval_every_steps == 0 and
                    self.eval_dataset is not None and self.eval_config is not None):
                    self.run_full_eval(state, control)
                return control
        
        # Initialize GRPO trainer
        grpo_trainer = GRPOTrainer(
            model=self.model,
            args=grpo_config,
            processing_class=self.tokenizer,
            reward_funcs=math_reward_function,
            train_dataset=training_dataset,
            eval_dataset=eval_dataset_for_grpo,  # TRL's internal evaluation dataset
        )
        
        # Add our custom callback for full evaluation
        if eval_dataset is not None and eval_config is not None:
            full_eval_callback = FullEvaluationCallback(
                ttt_model=self,
                eval_dataset=eval_dataset,
                eval_dataset_secondary=eval_dataset_secondary,
                eval_config=eval_config,
                max_seq_length=max_seq_length,
                output_dir=Path(output_dir) if output_dir else None,
                use_enhanced_eval=use_enhanced_eval,
                use_vllm_for_eval=use_vllm_for_eval,
                eval_every_steps=eval_every_steps,
                logger=logger,
                rank=self.rank
            )
            grpo_trainer.add_callback(full_eval_callback)
            
            if self.is_main_process:
                print(f"🔍 Added full evaluation callback - will run every {eval_every_steps} steps")
        
        # Log model parameter statistics
        if logger is not None and self.rank == 0:
            trainable_params = self.current_adapter.get_trainable_params()
            num_params_trainable = sum(p.numel() for p in trainable_params)
            logger.log_model_summary(
                num_params_total=self.num_params_total,
                num_params_trainable=num_params_trainable
            )
        
        # Training with GRPO
        if self.is_main_process:
            print("🚀 Starting GRPO training...")
        
        # Start training (TRL handles the training loop)
        grpo_trainer.train()
        
        if self.is_main_process:
            print("🎯 GRPO training completed!")
        
        # Save final model
        if output_dir and self.rank == 0:
            final_checkpoint_path = Path(output_dir) / "grpo_final_model"
            self.save_checkpoint(final_checkpoint_path, 0, grpo_config.num_train_epochs, 0.0)
            print(f"💾 GRPO final model saved to {final_checkpoint_path}")
    
    def _prepare_frozen_kv_cache(self, context_tokens: torch.Tensor, dtype_str: str = 'bf16', reserved_space: int = 0) -> tuple:
        """
        Simple KV cache preparation using standard forward pass.
        With context parallelism, the model handles sharding automatically.
        
        Args:
            context_tokens: Full context tokens (length L)
            dtype_str: Data type for cached KV tensors ('fp16' or 'bf16')
        
        Returns:
            Frozen KV cache tuple
        """
        # Convert dtype string to torch dtype
        if dtype_str == 'fp16':
            cache_dtype = torch.float16
        elif dtype_str == 'bf16':
            cache_dtype = torch.bfloat16
        else:
            raise ValueError(f"Unsupported dtype: {dtype_str}")
        
        # Apply aggressive context length limits to avoid OOM and warnings
        # CRITICAL FIX: Account for reserved space for question during evaluation
        model_max_length = self._get_model_max_context_length()
        original_length = len(context_tokens)
        
        # Use more conservative limits to avoid OOM warnings and improve speed
        effective_max_length = min(model_max_length or 131072, 131072)  # Stay well under limits
        
        # Reserve space for the question during evaluation
        max_context_length = effective_max_length - reserved_space
        
        if len(context_tokens) > max_context_length:
            context_tokens = context_tokens[:max_context_length]
            if self.is_main_process:
                print(f"🧊 Truncated context: {original_length} → {len(context_tokens)} tokens (reserved {reserved_space} tokens for question)")
        
        if self.is_main_process:
            print(f"🧊 Preparing KV cache for {len(context_tokens)} tokens...")
        
        # Simple single forward pass - let context parallelism handle the distribution
        self._toggle_gradient_checkpointing(self.base_model, disable=True)
        with torch.no_grad():
            # Single forward pass with the full context
            input_ids = context_tokens.unsqueeze(0)  # [1, L]
            
            # Move to embedding device if model is sharded
            is_sharded = getattr(self.base_model, 'hf_device_map', None) is not None
            if is_sharded:
                embed_device = self._get_embedding_device()
                input_ids = input_ids.to(embed_device)
            
            # Forward pass to build KV cache
            outputs = self.model(
                input_ids=input_ids,
                use_cache=True,
                output_hidden_states=False,
                output_attentions=False,
            )
            
            past_key_values = outputs.past_key_values
            
            # Convert to target dtype efficiently
            from transformers.cache_utils import Cache
            is_cache_obj = isinstance(past_key_values, Cache)

            if is_cache_obj:
                # For Cache objects, handle different cache types
                if hasattr(past_key_values, 'key_cache') and hasattr(past_key_values, 'value_cache'):
                    # Legacy cache with key_cache/value_cache attributes
                    for i in range(len(past_key_values.key_cache)):
                        past_key_values.key_cache[i] = past_key_values.key_cache[i].to(dtype=cache_dtype)
                        past_key_values.value_cache[i] = past_key_values.value_cache[i].to(dtype=cache_dtype)
                    frozen_kv = past_key_values
                else:
                    # For modern cache objects (like DynamicCache), create a copy with correct dtype
                    # and preserve the Cache interface
                    try:
                        # Try to create a new cache of the same type
                        from transformers.cache_utils import DynamicCache
                        if isinstance(past_key_values, DynamicCache):
                            # Create a new DynamicCache with converted tensors
                            new_cache = DynamicCache()
                            legacy_cache = past_key_values.to_legacy_cache()
                            for layer_idx, (key, value) in enumerate(legacy_cache):
                                new_cache.update(
                                    key.to(dtype=cache_dtype).unsqueeze(0),  # Add batch dim
                                    value.to(dtype=cache_dtype).unsqueeze(0),  # Add batch dim
                                    layer_idx
                                )
                            frozen_kv = new_cache
                        else:
                            # Generic cache handling - try to preserve original object
                            # but convert internal tensors to the target dtype
                            if hasattr(past_key_values, 'to_legacy_cache'):
                                legacy_cache = past_key_values.to_legacy_cache()
                                # Convert to tuple format as fallback
                                frozen_kv = tuple(
                                    tuple(t.to(dtype=cache_dtype) for t in layer)
                                    for layer in legacy_cache
                                )
                            else:
                                # Try to iterate directly over the cache
                                frozen_kv = tuple(
                                    tuple(t.to(dtype=cache_dtype) for t in layer)
                                    for layer in past_key_values
                                )
                    except Exception as e:
                        if self.is_main_process:
                            print(f"⚠️ Warning: Cache dtype conversion failed for {type(past_key_values)}, error: {e}")
                            print(f"   Keeping original cache with original dtype")
                        # Keep original cache without dtype conversion
                        frozen_kv = past_key_values
            else:
                # For tuple format, convert each tensor
                frozen_kv = tuple(
                    tuple(t.to(dtype=cache_dtype) for t in layer)
                    for layer in past_key_values
                )
        
        self._toggle_gradient_checkpointing(self.base_model, disable=False)
        
        if self.is_main_process:
            print(f"🧊 KV cache ready!")
        
        return frozen_kv
    
    def _copy_cache(self, cache):
        """
        Create a read-only copy of the cache to prevent in-place modifications.
        Supports both Cache objects and tuple format.
        """
        from transformers.cache_utils import Cache
        # For Cache objects, wrap without cloning tensors
        if isinstance(cache, Cache):
            return ReadOnlyCache(cache)
        
        # For tuple format, check if the model expects a Cache object
        # and convert if necessary (e.g., for Qwen3 which expects Cache interface)
        if isinstance(cache, tuple):
            # Check if the model requires Cache interface by looking at model type
            model_for_check = self.model.module if hasattr(self.model, 'module') else self.model
            model_type = getattr(model_for_check.config, 'model_type', '')
            
            # Models that require Cache interface (not tuple)
            cache_interface_models = {'qwen3', 'qwen2', 'llama', 'mistral'}
            
            if model_type in cache_interface_models:
                # Convert tuple back to DynamicCache for compatibility
                try:
                    from transformers.cache_utils import DynamicCache
                    new_cache = DynamicCache()
                    for layer_idx, (key, value) in enumerate(cache):
                        # Remove batch dimension if present, then add it back
                        if key.dim() == 4:  # [batch, num_heads, seq_len, head_dim]
                            key = key.squeeze(0)  # Remove batch dim
                            value = value.squeeze(0)
                        new_cache.update(
                            key.unsqueeze(0),  # Add batch dim back
                            value.unsqueeze(0),
                            layer_idx
                        )
                    return new_cache
                except Exception as e:
                    if self.is_main_process:
                        print(f"⚠️ Warning: Failed to convert tuple to DynamicCache: {e}")
                        print(f"   Falling back to tuple format")
        
        # For tuple format or fallback, return as-is
        return cache
    
    def _frozen_kv_ttt_step(self,
                            context_tokens: torch.Tensor,
                            frozen_kv,  # Can be Cache object or tuple
                            sample_m: int,
                            optimizer: torch.optim.Optimizer) -> float:
        """
        Frozen KV TTT step using the pre-computed KV cache for efficiency.
        """
        L = int(context_tokens.numel())
        if L <= 1:
            return 0.0

        # Sample M random positions from the context (excluding last token for targets)
        idx = torch.randint(0, L - 1, (sample_m,), device=context_tokens.device)
        
        # Get the next tokens to predict (targets)
        target_tokens = context_tokens[idx + 1]  # [M]
        
        # For the frozen KV approach, we append the sampled tokens as new queries
        # after the cached context, which allows us to reuse the KV cache
        query_tokens = context_tokens[idx].unsqueeze(0)  # [1, M]

        # Move to correct device if sharded
        is_sharded = getattr(self.base_model, 'hf_device_map', None) is not None
        if is_sharded:
            embed_device = self._get_embedding_device()
            query_tokens = query_tokens.to(embed_device)
            target_tokens = target_tokens.to(embed_device)

        # Use the frozen KV cache with new queries
        self._toggle_gradient_checkpointing(self.model, disable=True)
        
        # Copy cache to prevent in-place modifications
        cache_copy = self._copy_cache(frozen_kv)
        
        # Use autocast for speed
        with torch.amp.autocast('cuda', enabled=torch.cuda.is_available(), dtype=torch.bfloat16):
            # Forward pass using the frozen KV cache
            outputs = self.model(
                input_ids=query_tokens,
                past_key_values=cache_copy,
                use_cache=False,
            )
            logits = outputs.logits  # [1, M, vocab]
            
            # Compute loss on the predictions for next tokens
            loss = F.cross_entropy(
                logits.view(-1, logits.size(-1)), 
                target_tokens.view(-1)
            )

        # Clean up cache copy
        del cache_copy

        # Backward pass
        self.accelerator.backward(loss)
        optimizer.step()
        optimizer.zero_grad()

        self._toggle_gradient_checkpointing(self.model, disable=False)
        return float(loss.item())
    
    def _frozen_kv_ttt_step_simple(self,
                                   context_tokens: torch.Tensor,
                                   frozen_kv,  # Can be Cache object or tuple
                                   sample_m: int,
                                   optimizer: torch.optim.Optimizer) -> float:
        """
        Simple POC version of frozen KV TTT step.
        
        Does a standard forward pass over the entire context but only computes
        loss on randomly sampled M tokens. This avoids complex attention masking
        and should be more memory efficient.
        
        Args:
            context_tokens: Full context tokens on the correct device
            frozen_kv: Pre-computed frozen KV cache (kept on GPU)
            sample_m: Number of sampled positions for loss computation
            optimizer: Optimizer for LoRA parameters
            
        Returns:
            Scalar loss value for logging
        """
        L = int(context_tokens.numel())
        if L <= 1:
            return 0.0
            
        # Sample M random positions for loss computation (not at the last position)
        idx = torch.randint(0, L - 1, (sample_m,), device=context_tokens.device)
        
        # Standard forward pass over entire context
        # self._toggle_gradient_checkpointing(self.model, disable=True)
        # cache_copy = self._copy_cache(frozen_kv)
        
        # Forward pass without using the frozen cache (just for comparison/POC)
        # In practice, you might want to use the cache for efficiency
        input_ids = context_tokens.unsqueeze(0)  # [1, L]
        
        # Remove custom attention mask to avoid OOM - model handles causal masking automatically
        outputs = self.model(
            input_ids=input_ids,
            use_cache=False,
        )
        
        # Compute loss only on the sampled positions
        logits = outputs.logits  # [1, L, vocab_size]
        
        # Get the target tokens (next tokens to predict)
        targets = context_tokens[idx + 1]  # [sample_m]
        
        # Get logits for the sampled positions 
        sampled_logits = logits[0, idx, :]  # [sample_m, vocab_size]
        
        # Compute cross-entropy loss only for sampled positions
        loss_fct = torch.nn.CrossEntropyLoss()
        loss = loss_fct(sampled_logits, targets)
        
        self.accelerator.backward(loss)
        optimizer.step()
        optimizer.zero_grad()
        
        # del cache_copy
        # self._toggle_gradient_checkpointing(self.model, disable=False)
        return float(loss.item())
    
    def test_time_train_frozen_kv(self,
                                 problem_idx: Dict,
                                 context_tokens: torch.Tensor,
                                 config: Dict,
                                 logger: Optional[WandBLogger] = None,
                                 reserved_space_for_question: int = 0) -> Dict:
        """
        Perform frozen KV test-time training for a single problem.
        
        Args:
            problem_idx: Problem idx for logging
            context_tokens: Full context tokens
            config: Frozen KV TTT configuration
            logger: Optional WandB logger
        
        Returns:
            Results dictionary
        """
        # Extract frozen KV config with backward-compatible keys
        def _cfg(name: str, legacy_name: str, default):
            return config.get(name, config.get(legacy_name, default))

        sample_m = int(_cfg('sample_M', 'frozen_kv_sample_m', 32))  # Reduced from 64
        lora_rank = int(_cfg('lora_rank', 'frozen_kv_lora_rank', 16))
        num_steps = int(_cfg('num_epochs', 'frozen_kv_num_steps', 4))  # Reduced from 8
        dtype_str = str(_cfg('dtype', 'frozen_kv_dtype', 'bf16'))
        lr = float(_cfg('learning_rate_frozen_kv', 'frozen_kv_lr', 1e-4))  # Increased LR
        
        print(f"🧊 Starting frozen KV TTT: M={sample_m}, rank={lora_rank}, steps={num_steps}, dtype={dtype_str}, lr={lr}")
        
        # Step 1: Prepare frozen KV cache with space reserved for question
        frozen_kv = self._prepare_frozen_kv_cache(context_tokens, dtype_str, reserved_space_for_question)
        # Stash active KV for downstream evaluation reuse
        self._active_frozen_kv = frozen_kv
        self._active_frozen_kv_len = int(context_tokens.numel())
        
        # Step 2: Ultra-fast LoRA adapter setup
        self._ensure_no_active_peft()
        base_model_for_adapter = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
        
        # Minimal LoRA config
        frozen_kv_config = {
            'lora_r': lora_rank,
            'lora_alpha': lora_rank * 2,
            'lora_dropout': 0.0,
            'frozen_kv_target_modules': ['q_proj', 'o_proj']
        }
        
        from .adaptation import LoRAAdapter
        adapter = LoRAAdapter(base_model_for_adapter, frozen_kv_config)
        adapted_model = adapter.prepare_model()
        self.model = adapted_model
        self.model.train()
        
        # Step 3: Minimal optimizer setup
        trainable_params = adapter.get_trainable_params()
        optimizer = torch.optim.AdamW(trainable_params, lr=lr, 
                                    fused=torch.cuda.is_available(), eps=1e-6)
        
        # Step 4: Streamlined training loop
        losses = []
        if self.is_main_process:
            print(f"🧊 Training for {num_steps} steps...")
        
        for step in range(num_steps):
            loss = self._frozen_kv_ttt_step(context_tokens, frozen_kv, sample_m, optimizer)
            losses.append(loss)
            
            # Minimal logging
            if self.is_main_process and (step % 8 == 0 or step == num_steps - 1):
                print(f"🧊 Step {step+1}/{num_steps}: loss = {loss:.4f}")
            
            if logger and step % 4 == 0:
                logger.log_metric(f"frozen_kv/step_loss", loss, step=num_steps*problem_idx + step)
            
            # Aggressive early stopping check
            if step >= 4:  # Start checking after just 2 steps
                recent = losses[-3:] if len(losses) >= 3 else losses
                if len(recent) >= 2 and max(recent) - min(recent) < 0.01:  # More lenient threshold
                    if self.is_main_process:
                        print(f"⏭️  Early stop at step {step+1} (loss plateaued)")
                    break
        
        # Log final metrics
        avg_loss = sum(losses) / len(losses) if losses else 0.0
        final_loss = losses[-1] if losses else 0.0
        
        print(f"🧊 Frozen KV TTT completed: avg_loss={avg_loss:.4f}, final_loss={final_loss:.4f}")
        
        # Return adapted model and results
        return {
            'avg_loss': avg_loss,
            'final_loss': final_loss,
            'losses': losses,
            'adapted_model': self.model,
            'frozen_kv': frozen_kv,
            'adapter': adapter,
            'context_length': self._active_frozen_kv_len,
        }
    
    def test_time_train_zeroscrolls(
        self,
        eval_dataset: LoadDataset,
        config: Dict,
        logger: Optional[WandBLogger] = None,
        max_length: Optional[int] = None,
        eval_config: Optional[Dict] = None,
        output_dir: Optional[str] = None,
        use_enhanced_eval: bool = True,
        use_vllm_for_eval: bool = False,
        num_problems: Optional[int] = None,
        use_context_batchification: bool = False,
        context_batch_size: int = 128,
        min_chunk_length: int = 256,
    ):
        """
        Perform test-time training for long-context datasets (ZeroSCROLLS, LongBench-v2, TutorEval) with per-problem training.
        
        For these datasets, each problem has its own unique long context document.
        We perform individual test-time training for each problem using only
        that problem's specific context.
        
        Args:
            eval_dataset: Evaluation dataset containing ZeroSCROLLS/LongBench-v2/TutorEval problems
            config: Training configuration
            logger: Optional WandB logger
            max_length: Maximum sequence length for tokenization
            eval_config: Configuration for evaluation
            output_dir: Directory to save results
            use_enhanced_eval: Whether to use enhanced evaluation
            use_vllm_for_eval: Whether to use vLLM for evaluation
            num_problems: Number of problems to process (None for all)
            use_context_batchification: Whether to use context batchification
            context_batch_size: Number of chunks for context batchification
            min_chunk_length: Minimum length for each chunk
        
        Returns:
            Dictionary containing aggregated results across all problems
        """
        print("🌀 Starting long-context dataset per-problem test-time training...")
        
        # Enable memory optimization flags for CUDA
        if torch.cuda.is_available():
            try:
                import os
                os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
                print("🔧 Set PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True")
            except Exception as e:
                print(f"⚠️ Could not set CUDA alloc conf: {e}")
        
        # Detect dataset type
        if not hasattr(eval_dataset, 'problems') or not eval_dataset.problems:
            raise ValueError("Long-context dataset TTT requires evaluation dataset with problems")
        
        sample_problem = eval_dataset.problems[0]
        is_zeroscrolls = sample_problem.get('dataset') in [
            'gov_report', 'summ_screen_fd', 'qmsum', 'squality', 'qasper', 
            'narrative_qa', 'quality', 'musique', 'space_digest', 'book_sum_sort'
        ]
        is_longbench_v2 = sample_problem.get('dataset').startswith('longbench_v2_')
        is_tutoreval = sample_problem.get('dataset').startswith('tutoreval_')
        is_olmo_bugs = sample_problem.get('dataset').startswith('olmo_bugs_')
        
        if not (is_zeroscrolls or is_longbench_v2 or is_tutoreval or is_olmo_bugs):
            raise ValueError("Dataset does not appear to be ZeroSCROLLS, LongBench-v2, TutorEval, or OLMo Bugs format")
        
        dataset_name = sample_problem.get('dataset', 'unknown')
        print(f"🔍 Detected dataset: {dataset_name}")
        
        # Store original model state only if not using Frozen-KV (we do not modify base weights there)
        original_state = None
        if not config.get('use_frozen_kv', False):
            original_state = self._save_model_state()
        
        # Setup adaptation method
        adaptation_config = config.get('adaptation', {})
        method = adaptation_config.get('method', 'lora')
        print(f"Using adaptation method: {method} for per-problem TTT")
        
        # Process problems one by one
        num_problems_to_process = min(num_problems or len(eval_dataset.problems), len(eval_dataset.problems))
        all_results = []
        aggregated_metrics = {}
        
        # Setup output directory
        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            zeroscrolls_dir = output_dir
            zeroscrolls_dir.mkdir(exist_ok=True)
        else:
            zeroscrolls_dir = None
        
        for problem_idx in tqdm(range(num_problems_to_process), desc="Processing ZeroSCROLLS problems"):
            problem = eval_dataset.problems[problem_idx]
            problem_id = problem.get('id', f"problem_{problem_idx}")
            
            # [PERF] 减少日志输出
            if problem_idx % 10 == 0:  # 每 10 个问题打印一次
                print(f"\n🔄 Processing problem {problem_idx + 1}/{num_problems_to_process}: {problem_id}")
            
            # Reset model to original state if we saved it
            if original_state is not None:
                self._restore_model_state(original_state)
            
            # Aggressive memory cleanup before each problem
            self._clear_memory(aggressive=False)
            
            # Check if using frozen KV TTT
            if config.get('use_frozen_kv', False):
                print(f"🧊 Using frozen KV TTT for problem {problem_id}")
                
                # Extract context from the problem
                context_text = ""
                if 'context' in problem and problem['context']:
                    context_text = problem['context']
                elif 'document' in problem and problem['document']:
                    context_text = problem['document']
                elif 'chapter' in problem and problem['chapter']:  # TutorEval uses 'chapter' field
                    context_text = problem['chapter']
                else:
                    print(f"⚠️ Skipping problem {problem_id} - no context found")
                    print(f"   Available fields: {list(problem.keys())}")
                    continue
                
                # CRITICAL FIX: Calculate question length to reserve space for it
                question_text = problem.get('question', '')
                question_tokens = eval_dataset.tokenizer(
                    question_text,
                    add_special_tokens=False,
                    return_tensors="pt"
                ).input_ids.squeeze(0)
                question_length = len(question_tokens)
                
                # Reserve additional space for prompt formatting (e.g., "Problem: ", "Solution: ", etc.)
                formatting_buffer = 50  # Conservative estimate for formatting tokens
                reserved_space = question_length + formatting_buffer
                
                if self.is_main_process:
                    print(f"🔍 Question length: {question_length} tokens, reserved space: {reserved_space} tokens")
                
                # Tokenize context and move to the embedding device when sharded.
                # With HF device_map sharding, inputs must be on the embedding's GPU.
                input_device = self._get_embedding_device() if getattr(self.base_model, 'hf_device_map', None) is not None else self._get_model_device()
                context_tokens = eval_dataset.tokenizer(
                    context_text,
                    add_special_tokens=False,
                    return_tensors="pt"
                ).input_ids.squeeze(0).to(input_device)
                
                # Apply maximum context length limit - use the more restrictive of dataset limit and model limit
                # max_allowed_length = eval_dataset.max_context_length
                
                # # Also check model's maximum context length
                # model_max_length = self._get_model_max_context_length()
                # if model_max_length is not None:
                #     max_allowed_length = min(max_allowed_length, model_max_length)
                #     print(f"🧊 Using effective max context length: {max_allowed_length} (dataset: {eval_dataset.max_context_length}, model: {model_max_length})")
                # else:
                #     print(f"🧊 Using dataset max context length: {max_allowed_length}")
                
                # if len(context_tokens) > max_allowed_length:
                #     original_length = len(context_tokens)
                #     context_tokens = context_tokens[:max_allowed_length]
                #     print(f"🧊 Truncated context from {original_length} to {len(context_tokens)} tokens")
                
                # Perform frozen KV TTT with reserved space for question
                frozen_kv_results = self.test_time_train_frozen_kv(
                    problem_idx=problem_idx,
                    context_tokens=context_tokens,
                    config=config,
                    logger=logger,
                    reserved_space_for_question=reserved_space
                )
                
                # Evaluate the adapted model directly using generate_single_example
                from ..utils.evaluation_utils import generate_single_example
                
                if self.is_main_process:
                    print(f"🔍 Evaluating frozen KV adapted model for problem {problem_id}")
                
                eval_results = generate_single_example(
                    model=self,
                    problem=problem,
                    eval_config=eval_config,
                    max_length=max_length,
                    silent=False,
                )
                
                # Process the result from generate_single_example
                # generate_single_example returns a dict with the result directly
                problem_results = eval_results
                
                # Add any missing fields for compatibility
                if 'metrics' not in problem_results:
                    problem_results['metrics'] = {
                        'answer_accuracy_mean': 1.0 if problem_results.get('is_correct', False) else 0.0,
                        'total_examples': 1
                    }
                
                # Clean up adapter for next problem to avoid PEFT warnings
                if 'adapter' in frozen_kv_results:
                    print(f"🧹 Cleaning up frozen KV adapter for problem {problem_id}")
                    frozen_kv_results['adapter'].cleanup()
                
                # Reset model to base state for next problem
                self.model = self.base_model
                
                all_results.append(problem_results)
                    
            else:
                # Original TTT training approach
                # Create single-problem dataset for training
                single_problem_dataset = self._create_single_problem_dataset(
                    problem, eval_dataset.tokenizer, eval_dataset.max_context_length,
                    eval_dataset.max_question_length, eval_dataset.max_solution_length
                )
                
                if len(single_problem_dataset) == 0:
                    print(f"⚠️ Skipping problem {problem_id} - no training data")
                    continue
                    
                # Setup adapter for this problem
                base_model_for_adapter = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
                current_adapter = get_adapter(method, base_model_for_adapter, adaptation_config)
                adapted_model = current_adapter.prepare_model()
                self.model = adapted_model
                self.model.train()
                
                # Get epoch checkpoints from config, defaulting to the original behavior
                epoch_checkpoints = config.get('epoch_checkpoints', None)
                
                problem_results = self._train_single_problem(
                    single_problem_dataset=single_problem_dataset,
                    problem=problem,
                    problem_idx=problem_idx,
                    config=config,
                    max_length=max_length,
                    eval_config=eval_config,
                    current_adapter=current_adapter,
                    zeroscrolls_dir=zeroscrolls_dir,
                    use_enhanced_eval=use_enhanced_eval,
                    use_vllm_for_eval=use_vllm_for_eval,
                    logger=logger,
                    epoch_checkpoints=epoch_checkpoints,
                    use_context_batchification=use_context_batchification,
                    context_batch_size=context_batch_size,
                    min_chunk_length=min_chunk_length,
                )
                
                all_results.append(problem_results)
                # [PERF] 减少日志
                # print(f"✅ Problem {problem_id} completed")
                
                # Clean up adapter to avoid PEFT warnings in next iteration
                if current_adapter is not None:
                    # [PERF] 减少日志
                    # print(f"🧹 Cleaning up adapter for problem {problem_id}")
                    current_adapter.cleanup()
                    current_adapter = None
                
                # Reset model to base state for next problem
                self.model = self.base_model
            
            # Clear memory after each problem - use aggressive cleanup to prevent OOM
            self._clear_memory(aggressive=True)
        
        # Aggregate results across all problems
        if all_results:
            # Handle both single-epoch and multi-epoch checkpoint results
            epoch_checkpoints = config.get('epoch_checkpoints')
            if epoch_checkpoints is None:
                epoch_checkpoints = [config.get('num_epochs', 4)]
            print(f"Epoch checkpoints: {epoch_checkpoints}")
            aggregated_metrics = {}
            
            # Aggregate results for each epoch checkpoint
            for epoch in epoch_checkpoints:
                epoch_results = []
                for result in all_results:
                    if 'checkpoint_results' in result:
                        # Multi-checkpoint result
                        if epoch in result['checkpoint_results']:
                            epoch_results.append(result['checkpoint_results'][epoch])
                    else:
                        # Single result (backward compatibility)
                        if epoch == epoch_checkpoints[0]:  # Only for the first/only epoch
                            epoch_results.append(result)
                
                # Aggregate metrics for this epoch
                if epoch_results:
                    epoch_aggregated = {}
                    for result in epoch_results:
                        metrics = result.get('metrics', {})
                        print(f"Metrics: {metrics}")
                        for key, value in metrics.items():
                            if key not in epoch_aggregated:
                                epoch_aggregated[key] = []
                            epoch_aggregated[key].append(value)
                    
                    for key, values in epoch_aggregated.items():
                        epoch_aggregated[key] = np.mean(values)
                    
                    aggregated_metrics[f'epoch_{epoch}'] = epoch_aggregated
                    
                    # Log aggregated results for this epoch
                    if logger is not None:
                        for metric_name, metric_value in epoch_aggregated.items():
                            logger.log_metric(f"eval/{dataset_name}/epoch_{epoch}/{metric_name}", metric_value, step=(problem_idx+1)*max(epoch_checkpoints))
                
                # For backward compatibility, also create top-level aggregated metrics from the last epoch
                if epoch_checkpoints:
                    last_epoch = max(epoch_checkpoints)
                    if f'epoch_{last_epoch}' in aggregated_metrics:
                        for key, value in aggregated_metrics[f'epoch_{last_epoch}'].items():
                            aggregated_metrics[key] = value
            
            # Save final results
            if zeroscrolls_dir:
                final_results_file = zeroscrolls_dir / "results.json"
                with open(final_results_file, 'w') as f:
                    json.dump({
                        'aggregated_metrics': aggregated_metrics,
                        'individual_results': all_results,
                        'dataset_name': dataset_name,
                        'num_problems_processed': len(all_results),
                        'config': config,
                        'epoch_checkpoints': epoch_checkpoints
                    }, f, indent=2)
                print(f"📁 Saved aggregated results to {final_results_file}")
                
                # Also save per-epoch detailed results if we have checkpoints
                if len(epoch_checkpoints) > 1:
                    for epoch in epoch_checkpoints:
                        if f'epoch_{epoch}' in aggregated_metrics:
                            epoch_file = zeroscrolls_dir / f"results_epoch_{epoch}.json"
                            with open(epoch_file, 'w') as f:
                                json.dump({
                                    'epoch': epoch,
                                    'aggregated_metrics': aggregated_metrics[f'epoch_{epoch}'],
                                    'dataset_name': dataset_name,
                                    'num_problems_processed': len(all_results),
                                }, f, indent=2)
                    print(f"📁 Saved per-epoch results for epochs: {epoch_checkpoints}")
        
        # Restore original model state if it was saved
        if original_state is not None:
            self._restore_model_state(original_state)
        
        print(f"🎯 ZeroSCROLLS per-problem TTT completed!")
        print(f"   Processed: {len(all_results)}/{num_problems_to_process} problems")
        if aggregated_metrics:
            print(f"   Average performance: {aggregated_metrics.get('average_accuracy', 0.0):.3f}")
        
        return {
            'metrics': aggregated_metrics,
            'individual_results': all_results,
            'num_problems_processed': len(all_results)
        }

    def test_time_train_bank_transactions(
        self,
        eval_dataset: LoadDataset,
        config: Dict,
        logger: Optional[WandBLogger] = None,
        max_length: Optional[int] = None,
        eval_config: Optional[Dict] = None,
        output_dir: Optional[str] = None,
        use_enhanced_eval: bool = True,
        use_vllm_for_eval: bool = False,
        num_problems: Optional[int] = None,
    ) -> Dict:
        """
        Per-problem test-time training for Bank Transactions.

        For each problem, adapt on the transaction log (context) only, then evaluate
        on that same problem. This uses the frozen KV fast path by default.
        """
        print("🏦 Starting Bank Transactions per-problem test-time training...")

        # Detect dataset type
        if not hasattr(eval_dataset, 'problems') or not eval_dataset.problems:
            raise ValueError("Bank Transactions TTT requires evaluation dataset with problems")

        sample_problem = eval_dataset.problems[0]
        is_bank_tx = sample_problem.get('dataset').startswith('bank_transactions')
        if not is_bank_tx:
            raise ValueError("Dataset does not appear to be Bank Transactions format")

        dataset_name = sample_problem.get('dataset', 'bank_transactions')
        print(f"🔍 Detected dataset: {dataset_name}")

        # Store original model state only if not using Frozen-KV (we do not modify base weights there)
        original_state = None
        if not config.get('use_frozen_kv', True):
            original_state = self._save_model_state()

        # Setup adaptation method (used only for non-frozen-KV fallback)
        adaptation_config = config.get('adaptation', {})
        method = adaptation_config.get('method', 'lora')
        print(f"Using adaptation method: {method} for Bank Transactions per-problem TTT")

        # Process problems one by one
        total_to_process = min(num_problems or len(eval_dataset.problems), len(eval_dataset.problems))
        all_results = []

        # Setup output directory
        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

        for problem_idx in tqdm(range(total_to_process), desc="Processing Bank Tx problems"):
            problem = eval_dataset.problems[problem_idx]
            problem_id = problem.get('id', f"problem_{problem_idx}")

            print(f"\n🔄 Processing problem {problem_idx + 1}/{total_to_process}: {problem_id}")

            # Reset model to original state if we saved it (for non-frozen-KV)
            if original_state is not None:
                self._restore_model_state(original_state)

            # Extract transaction log as context
            context_text = problem.get('context', '') or ''
            if not context_text:
                print(f"⚠️ Skipping problem {problem_id} - no transaction context found")
                continue

            # Tokenize context and move to the embedding device when sharded
            input_device = self._get_embedding_device() if getattr(self.base_model, 'hf_device_map', None) is not None else self._get_model_device()
            context_tokens = eval_dataset.tokenizer(
                context_text,
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0).to(input_device)

            if config.get('use_frozen_kv', True):
                # Perform ultra-fast frozen KV TTT on context tokens
                fkv_results = self.test_time_train_frozen_kv(
                    problem_idx=problem_idx,
                    context_tokens=context_tokens,
                    config=config,
                    logger=logger
                )

                # Evaluate adapted model for this problem
                from ..utils.evaluation_utils import generate_single_example
                if self.is_main_process:
                    print(f"🔍 Evaluating adapted model for problem {problem_id}")
                example_result = generate_single_example(
                    model=self,
                    problem=problem,
                    eval_config=eval_config,
                    max_length=max_length,
                    silent=False,
                )

                # Attach minimal training stats
                example_result['frozen_kv_metrics'] = {
                    'avg_loss': fkv_results.get('avg_loss', 0.0),
                    'final_loss': fkv_results.get('final_loss', 0.0),
                    'num_steps': len(fkv_results.get('losses', [])),
                    'context_length': fkv_results.get('context_length', int(context_tokens.numel()))
                }

                # Clean up adapter before next problem
                if 'adapter' in fkv_results and fkv_results['adapter'] is not None:
                    print(f"🧹 Cleaning up adapter for problem {problem_id}")
                    fkv_results['adapter'].cleanup()
                self.model = self.base_model
                all_results.append(example_result)
            else:
                # Fallback: simple per-problem LoRA training on context chunks
                # Reuse ZeroSCROLLS single-problem path with context batchification
                base_model_for_adapter = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
                current_adapter = get_adapter(method, base_model_for_adapter, adaptation_config)
                adapted_model = current_adapter.prepare_model()
                self.model = adapted_model
                self.model.train()

                problem_results = self._train_single_problem(
                    single_problem_dataset=self._create_single_problem_dataset(
                        problem, eval_dataset.tokenizer, eval_dataset.max_context_length,
                        eval_dataset.max_question_length, eval_dataset.max_solution_length
                    ),
                    problem=problem,
                    problem_idx=problem_idx,
                    config=config,
                    max_length=max_length,
                    eval_config=eval_config,
                    current_adapter=current_adapter,
                    zeroscrolls_dir=Path(output_dir) if output_dir else None,
                    use_enhanced_eval=use_enhanced_eval,
                    use_vllm_for_eval=use_vllm_for_eval,
                    logger=logger,
                    epoch_checkpoints=config.get('epoch_checkpoints', None),
                    use_context_batchification=True,
                    context_batch_size=config.get('context_batch_size', 128),
                    min_chunk_length=config.get('min_chunk_length', 256),
                )

                all_results.append(problem_results)
                if current_adapter is not None:
                    print(f"🧹 Cleaning up adapter for problem {problem_id}")
                    current_adapter.cleanup()
                    current_adapter = None
                self.model = self.base_model

            # Clear memory after each problem - use aggressive cleanup to prevent OOM
            self._clear_memory(aggressive=True)

        # Aggregate simple metrics: accuracy over problems (using 'correct' flag when present)
        aggregated_metrics = {}
        if all_results:
            correctness = []
            for r in all_results:
                if 'correct' in r:
                    correctness.append(1.0 if r['correct'] else 0.0)
                elif 'metrics' in r and 'correct' in r['metrics']:
                    correctness.append(1.0 if r['metrics']['correct'] else 0.0)
            if correctness:
                aggregated_metrics['answer_accuracy_mean'] = float(np.mean(correctness))
                aggregated_metrics['answer_accuracy_std'] = float(np.std(correctness))
                aggregated_metrics['total_examples'] = int(len(correctness))

        # Save final results
        if output_dir:
            final_results_file = Path(output_dir) / "results.json"
            with open(final_results_file, 'w') as f:
                json.dump({
                    'aggregated_metrics': aggregated_metrics,
                    'individual_results': all_results,
                    'dataset_name': dataset_name,
                    'num_problems_processed': len(all_results),
                    'config': config,
                }, f, indent=2)
            print(f"📁 Saved aggregated results to {final_results_file}")

        print("🎯 Bank Transactions per-problem TTT completed!")
        if aggregated_metrics:
            print(f"   Average accuracy: {aggregated_metrics.get('answer_accuracy_mean', 0.0):.3f}")

        return {
            'metrics': aggregated_metrics,
            'individual_results': all_results,
            'num_problems_processed': len(all_results)
        }

    def _create_single_problem_dataset(self, problem: Dict, tokenizer, max_context_length: int, 
                                       max_question_length: int, max_solution_length: int):
        """Create a dataset with just one problem for individual TTT."""
        from ..data.load_dataset import LoadDataset
        
        # Create a dataset with just this problem for training
        # Use the problem's context as training data
        single_problem_dataset = LoadDataset(
            model_name=self.model_name,
            problems=[problem],  # Just this one problem
            tokenizer=tokenizer,
            max_context_examples=0,  # No additional context examples
            max_context_length=max_context_length,
            max_question_length=max_question_length,
            max_solution_length=max_solution_length,
            context_problems=None,  # No additional context
            mask_question_in_loss=False,
            eval_mode=True,
            reasoning_mode=False,
            create_long_context_sequence=False,  # Use individual problem
        )
        
        return single_problem_dataset

    def _create_context_chunks_for_training(self, problem: Dict, tokenizer, 
                                           context_batch_size: int = 128, 
                                           min_chunk_length: int = 256):
        """Create context chunks for a single problem to enable batch training.
        
        Args:
            problem: Single problem with long context
            tokenizer: Tokenizer to use for chunking
            context_batch_size: Number of chunks to create
            min_chunk_length: Minimum tokens per chunk
            
        Returns:
            List of training samples, each with a context chunk + question + solution
        """
        # Check if this is a ZeroSCROLLS, LongBench-v2, or TutorEval problem
        is_zeroscrolls = 'context' in problem and 'dataset' in problem and problem.get('dataset') in [
            'gov_report', 'summ_screen_fd', 'qmsum', 'squality', 'qasper', 
            'narrative_qa', 'quality', 'musique', 'space_digest', 'book_sum_sort'
        ]
        is_longbench_v2 = 'context' in problem and 'dataset' in problem and problem.get('dataset', '').startswith('longbench_v2_')
        is_tutoreval = 'dataset' in problem and problem.get('dataset', '').startswith('tutoreval_')
        
        # For TutorEval, context is in 'chapter' field; for others it's in 'context'
        context_field = 'chapter' if is_tutoreval else 'context'
        
        if not (is_zeroscrolls or is_longbench_v2 or is_tutoreval) or context_field not in problem:
            # Not a long context problem, return single sample
            return [problem]
        
        # Get the full context
        context_text = problem[context_field].replace('\n\nAnswer:', '').strip()
        if not context_text:
            return [problem]
        
        # Tokenize the full context
        context_tokens = tokenizer(
            context_text,
            add_special_tokens=False,
            return_tensors="pt"
        ).input_ids.squeeze(0)
        
        total_context_length = len(context_tokens)
        
        # Calculate chunk size
        chunk_size = max(min_chunk_length, total_context_length // context_batch_size)
        
        # If context is already small, no need to chunk
        if total_context_length <= chunk_size:
            return [problem]
        
        # Create chunks
        num_chunks = (total_context_length + chunk_size - 1) // chunk_size
        chunk_samples = []
        
        for i in range(num_chunks):
            start_idx = i * chunk_size
            end_idx = min(start_idx + chunk_size, total_context_length)
            
            chunk_tokens = context_tokens[start_idx:end_idx]
            chunk_text = tokenizer.decode(chunk_tokens, skip_special_tokens=True)
            
            # Create a training sample with this chunk
            chunk_sample = problem.copy()
            chunk_sample[context_field] = chunk_text
            chunk_samples.append(chunk_sample)
        
        print(f"📊 Context batchification: Split {total_context_length} tokens into {num_chunks} chunks of ~{chunk_size} tokens each")
        return chunk_samples

    def _toggle_gradient_checkpointing(self, model_for_generation: PreTrainedModel, disable: bool = True):
        """Disable gradient checkpointing for a model."""
        model_for_generation.eval()
        toggled_modules = []
        for module in model_for_generation.modules():
            if hasattr(module, 'gradient_checkpointing') and getattr(module, 'gradient_checkpointing') is True:
                module.gradient_checkpointing = False
                toggled_modules.append(module)
        
        if disable:
            if hasattr(model_for_generation, 'config'):
                model_for_generation.config.use_cache = True
            if hasattr(model_for_generation, 'model') and hasattr(model_for_generation.model, 'config'):
                model_for_generation.model.config.use_cache = True
            if hasattr(model_for_generation, 'gradient_checkpointing_disable'):
                model_for_generation.gradient_checkpointing_disable()
        else:
            for module in toggled_modules:
                module.gradient_checkpointing = True
            if hasattr(model_for_generation, 'gradient_checkpointing_enable'):
                model_for_generation.gradient_checkpointing_enable()

    def _train_single_problem(self, single_problem_dataset, problem: Dict, problem_idx: int,
                             config: Dict, max_length: int, eval_config: Dict, current_adapter,
                             zeroscrolls_dir: Optional[Path], use_enhanced_eval: bool, 
                             use_vllm_for_eval: bool, logger: Optional[WandBLogger] = None,
                             epoch_checkpoints: Optional[List[int]] = None,
                             use_context_batchification: bool = False,
                             context_batch_size: int = 128,
                             min_chunk_length: int = 256) -> Dict:
        """Train the model on a single ZeroSCROLLS problem and evaluate."""
        
        problem_id = problem.get('id', f"problem_{problem_idx}")
        
        # Handle epoch checkpoints - default to just final epoch for backward compatibility
        if epoch_checkpoints is None:
            epoch_checkpoints = [config.get('num_epochs', 3)]
        
        # Prepare optimizer
        trainable_params = current_adapter.get_trainable_params()
        optimizer = torch.optim.AdamW(
            trainable_params,
            lr=config['learning_rate'],
            weight_decay=config.get('weight_decay', 0.01),
            betas=config.get('betas', (0.9, 0.999))
        )
        
        # Create DataLoader for this problem
        max_seq_length = max_length or config.get('max_length', 4096)
        collate_fn_with_args = partial(
            collate_fn, 
            tokenizer=self.tokenizer, 
            max_length=max_seq_length
        )
        
        # Handle context batchification if enabled
        if use_context_batchification:
            # Create context chunks for this problem
            chunk_samples = self._create_context_chunks_for_training(
                problem, self.tokenizer, context_batch_size, min_chunk_length
            )
            
            if len(chunk_samples) > 1:
                print(f"📊 Using context batchification: {len(chunk_samples)} chunks for training")
                # Create a temporary dataset with all chunks
                from ..data.load_dataset import LoadDataset
                chunk_dataset = LoadDataset(
                    model_name=self.model_name,
                    problems=chunk_samples,
                    tokenizer=self.tokenizer,
                    max_context_examples=0,
                    max_context_length=single_problem_dataset.max_context_length,
                    max_question_length=single_problem_dataset.max_question_length,
                    max_solution_length=single_problem_dataset.max_solution_length,
                    context_problems=None,
                    mask_question_in_loss=False,
                    eval_mode=False,
                    reasoning_mode=False,
                    create_long_context_sequence=False,
                )
                training_dataset = chunk_dataset
                effective_batch_size = min(len(chunk_samples), 32)  # Reasonable batch size
            else:
                training_dataset = single_problem_dataset
                effective_batch_size = config.get('batch_size', 1)
        else:
            training_dataset = single_problem_dataset
            effective_batch_size = config.get('batch_size', 1)
            
        dataloader = DataLoader(
            training_dataset,
            batch_size=effective_batch_size,
            shuffle=False,  # Don't shuffle to maintain context order
            collate_fn=collate_fn_with_args
        )
        
        # Prepare DataLoader and optimizer with Accelerate
        optimizer, dataloader = self.accelerator.prepare(optimizer, dataloader)
        
        # Train for a few epochs on this problem
        max_epochs = max(epoch_checkpoints)  # Train until the maximum requested epoch
        gradient_accumulation_steps = config.get('gradient_accumulation_steps', 1)
        total_loss = 0
        num_steps = 0
        checkpoint_results = {}  # Store results for each checkpoint
        
        # Clear any lingering cache before training
        self._clear_memory(aggressive=False)
        
        for epoch in range(max_epochs):
            epoch_loss = 0
            epoch_steps = 0
            accumulation_counter = 0
            for batch in dataloader:
                self.model.train()
                
                input_ids = batch['input_ids']
                attention_mask = batch['attention_mask']
                labels = batch['labels']
                
                # CRITICAL FIX: Ensure all tensors are on the correct device for sharded models
                is_sharded = getattr(self.base_model, 'hf_device_map', None) is not None
                
                if is_sharded:
                    # For sharded models, move inputs to the embedding device
                    embed_device = self._get_embedding_device()
                    if input_ids.device != embed_device:
                        input_ids = input_ids.to(embed_device)
                    if attention_mask.device != embed_device:
                        attention_mask = attention_mask.to(embed_device)
                    if labels.device != embed_device:
                        labels = labels.to(embed_device)
                
                # Forward pass with mixed precision
                from contextlib import nullcontext
                context = torch.amp.autocast('cuda', enabled=torch.cuda.is_available(), dtype=torch.bfloat16) if torch.cuda.is_available() else nullcontext()
                with context:
                    outputs = self.model(
                        input_ids=input_ids,
                        attention_mask=attention_mask,
                        labels=labels
                    )
                    loss = outputs.loss / gradient_accumulation_steps  # Scale loss for accumulation
                
                unscaled_loss = loss.item() * gradient_accumulation_steps  # Unscale for logging
                total_loss += unscaled_loss
                epoch_loss += unscaled_loss
                
                # Backward pass with gradient accumulation
                self.accelerator.backward(loss)
                accumulation_counter += 1
                
                # Immediate cleanup of large tensors and memory
                del outputs
                # Remove immediate cache cleanup to avoid CUDA errors
                
                # Update weights every gradient_accumulation_steps
                if accumulation_counter % gradient_accumulation_steps == 0:
                    torch.nn.utils.clip_grad_norm_(trainable_params, config['max_grad_norm'])
                    optimizer.step()
                    optimizer.zero_grad()
                    num_steps += 1
                    epoch_steps += 1
                
                # Aggressive memory cleanup
                del input_ids, attention_mask, labels, loss
                
                # [PERF] 减少内存清理频率 - 每 epoch 结束时清理而不是每几步
                # if accumulation_counter % (gradient_accumulation_steps * 4) == 0:
                #     self._clear_memory(aggressive=False)
            
            # Log epoch loss for this problem
            if logger is not None and epoch_steps > 0:
                avg_epoch_loss = epoch_loss / epoch_steps
                logger.log_metric(f"train/epoch_loss", avg_epoch_loss, step=max_epochs*problem_idx + epoch)
            
            # Check if this epoch is a checkpoint we need to evaluate
            current_epoch = epoch + 1  # Convert to 1-indexed
            if current_epoch in epoch_checkpoints:
                # Evaluate at this checkpoint
                self.model.eval()
                from ..utils.evaluation_utils import generate_single_example
                
                checkpoint_result = generate_single_example(
                    model=self,
                    problem=problem,
                    eval_config=eval_config,
                    max_length=max_seq_length,
                    silent=True,
                )
                
                # Add checkpoint-specific information
                checkpoint_result['problem'] = problem.get('question', ''),
                checkpoint_result['problem_id'] = problem_id
                checkpoint_result['problem_idx'] = problem_idx
                checkpoint_result['training_loss'] = total_loss / max(num_steps, 1)
                checkpoint_result['num_training_steps'] = num_steps
                checkpoint_result['epoch'] = current_epoch
                
                # Store result for this checkpoint
                checkpoint_results[current_epoch] = checkpoint_result
                
                print(f"  📊 Checkpoint evaluation at epoch {current_epoch}: "
                      f"accuracy={checkpoint_result.get('is_correct', False)}")
        
        avg_training_loss = total_loss / max(num_steps, 1)
        
        # Final memory cleanup for this problem - use aggressive cleanup to prevent OOM
        del training_dataset, dataloader
        self._clear_memory(aggressive=True)
        
        # Return results for all checkpoints
        # If only one checkpoint (backward compatibility), return just that result
        if len(checkpoint_results) == 1:
            return list(checkpoint_results.values())[0]
        else:
            # Return all checkpoint results
            return {
                'checkpoint_results': checkpoint_results,
                'problem_id': problem_id,
                'problem_idx': problem_idx,
                'avg_training_loss': avg_training_loss,
                'total_training_steps': num_steps,
                'epoch_checkpoints': sorted(checkpoint_results.keys())
            }

    def _save_model_state(self) -> Dict:
        """Save current model state for restoration later."""
        # Save the original base model state on CPU to avoid duplicating GPU memory
        base_model = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
        state_dict = {name: tensor.detach().to('cpu') for name, tensor in base_model.state_dict().items()}
        
        return {
            'state_dict': state_dict,
            'model_training_mode': base_model.training
        }

    def _restore_model_state(self, saved_state: Dict):
        """Restore model to a previous state."""
        # Clean up current adapter first to avoid PEFT warnings
        if self.current_adapter is not None:
            print("🧹 Cleaning up current adapter before restoring state...")
            self.current_adapter.cleanup()
            self.current_adapter = None
        
        # Unwrap DDP
        base_model = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
        
        # If LoRA/PEFT adapters are present, unwrap to the base transformer before loading
        try:
            from peft import PeftModel
            if isinstance(base_model, PeftModel):
                print("🔄 Unwrapping PEFT model to base model...")
                base_model = base_model.get_base_model()
                self.base_model = base_model
                self.model = base_model
        except Exception as e:
            print(f"⚠️ Warning during PEFT unwrapping: {e}")

        # Clear any active cached KV to avoid mismatch across problems
        self._active_frozen_kv = None
        self._active_frozen_kv_len = 0

        # Load the original weights
        # Load to current device non-blocking; PyTorch will move as needed
        base_model.load_state_dict(saved_state['state_dict'], strict=True)
        base_model.train(saved_state['model_training_mode'])

    def _aggregate_results(self, all_results: List[Dict], dataset_name: str) -> Dict:
        """Aggregate results across all problems."""
        if not all_results:
            return {}
        
        # Collect metrics from all problems
        all_metrics = []
        all_correct = []
        for result in all_results:
            if 'metrics' in result:
                all_metrics.append(result['metrics'])
            if 'is_correct' in result:
                all_correct.append(result['is_correct'])
        
        if not all_metrics:
            return {}
        
        # Aggregate common metrics
        aggregated = {}
        
        # Standard metrics that can be averaged
        metrics_to_average = [
            'rouge1_f1', 'rouge2_f1', 'rougeL_f1', 'rouge',
            'bleu_score', 'exact_match', 'f1_score', 'tfidf_similarity'
        ]
        
        for metric_name in metrics_to_average:
            values = [m.get(metric_name, 0.0) for m in all_metrics if metric_name in m]
            if values:
                aggregated[f'average_{metric_name}'] = np.mean(values)
                aggregated[f'std_{metric_name}'] = np.std(values)
                aggregated[f'min_{metric_name}'] = np.min(values)
                aggregated[f'max_{metric_name}'] = np.max(values)
        
        # Overall statistics
        aggregated['num_problems'] = len(all_results)
        aggregated['dataset_name'] = dataset_name
        
        # Primary accuracy metric - compute from correctness values
        if all_correct:
            aggregated['accuracy'] = np.mean(all_correct)
            aggregated['accuracy_std'] = np.std(all_correct)
            aggregated['total_correct'] = sum(all_correct)
            aggregated['total_examples'] = len(all_correct)
        
        # Prediction length statistics
        prediction_lengths = [r.get('prediction_length', 0) for r in all_results if 'prediction_length' in r]
        if prediction_lengths:
            aggregated['prediction_length_mean'] = np.mean(prediction_lengths)
            aggregated['prediction_length_std'] = np.std(prediction_lengths)
        
        # Training statistics
        training_losses = [r.get('training_loss', 0.0) for r in all_results if 'training_loss' in r]
        if training_losses:
            aggregated['average_training_loss'] = np.mean(training_losses)
            aggregated['training_loss_std'] = np.std(training_losses)
        
        # Frozen KV specific metrics
        frozen_kv_metrics = [r.get('frozen_kv_metrics', {}) for r in all_results if 'frozen_kv_metrics' in r]
        if frozen_kv_metrics:
            # Aggregate frozen KV training losses
            avg_losses = [fkv.get('avg_loss', 0.0) for fkv in frozen_kv_metrics]
            final_losses = [fkv.get('final_loss', 0.0) for fkv in frozen_kv_metrics]
            num_steps = [fkv.get('num_steps', 0) for fkv in frozen_kv_metrics]
            
            if avg_losses:
                aggregated['frozen_kv_avg_loss_mean'] = np.mean(avg_losses)
                aggregated['frozen_kv_avg_loss_std'] = np.std(avg_losses)
            if final_losses:
                aggregated['frozen_kv_final_loss_mean'] = np.mean(final_losses)
                aggregated['frozen_kv_final_loss_std'] = np.std(final_losses)
            if num_steps:
                aggregated['frozen_kv_steps_mean'] = np.mean(num_steps)
                aggregated['frozen_kv_steps_std'] = np.std(num_steps)
        
        return aggregated

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        max_new_tokens: int = 512,
        **kwargs
    ) -> torch.Tensor:
        """
        Generate text using the model.
        
        Args:
            input_ids: Input token ids
            attention_mask: Attention mask
            max_new_tokens: Maximum number of tokens to generate
            **kwargs: Additional generation parameters
        
        Returns:
            Generated token ids
        """
        # Ensure inputs are on the embedding device if the model is sharded via device_map
        is_sharded = getattr(self.base_model, 'hf_device_map', None) is not None
        if is_sharded:
            target_device = self._get_embedding_device()
            if input_ids.device != target_device:
                input_ids = input_ids.to(target_device)
            if attention_mask is not None and attention_mask.device != target_device:
                attention_mask = attention_mask.to(target_device)

        # Apply YaRN scaling if needed to avoid exceeding positional limits
        total_needed = int(input_ids.shape[1] + max_new_tokens)
        eval_cfg = kwargs.get('eval_config', {}) if isinstance(kwargs.get('eval_config', {}), dict) else {}
        maybe_apply_yarn_to_hf_model(self, needed_total_len=total_needed, eval_config=eval_cfg)

        # Use the underlying model for generation (unwrap DDP if needed)
        model_for_generation = self.model.module if hasattr(self.model, 'module') else self.model
        model_for_generation.eval()
        
        # Ultra-fast generation config optimized for speed
        # Remove invalid generation flags to avoid warnings
        valid_generation_kwargs = {k: v for k, v in kwargs.items() if k not in [
            'temperature', 'top_p', 'top_k', 'eval_config'  # Remove problematic keys
        ]}
        
        generation_kwargs = {
            'do_sample': False,
            'pad_token_id': self.tokenizer.pad_token_id,
            'eos_token_id': self.tokenizer.eos_token_id,
            'use_cache': True,
            'num_beams': 1,  # Force beam=1 for speed
            **valid_generation_kwargs
        }
        
        # Fast path: if we have an active frozen KV built on the same context prefix, reuse it
        if False and getattr(self, '_active_frozen_kv', None) is not None and self._active_frozen_kv_len > 0:
            return self._generate_with_past_cache(
                model_for_generation,
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                past_key_values=self._active_frozen_kv,
                past_length=self._active_frozen_kv_len,
                **kwargs,
            )

        return model_for_generation.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_new_tokens=max_new_tokens,
            **generation_kwargs
        )

    def _expand_past_for_batch(self, past_key_values, batch_size: int):
        """Expand cached past; supports legacy tuple and Cache objects (Cache only for batch_size==1)."""
        from transformers.cache_utils import Cache
        if isinstance(past_key_values, ReadOnlyCache):
            if batch_size != 1:
                raise ValueError("Cache-based KV only supports batch_size==1 in fast path. Reduce eval batch size.")
            return past_key_values
        if isinstance(past_key_values, Cache):  # ReadOnlyCache now inherits from Cache
            if batch_size != 1:
                raise ValueError("Cache-based KV only supports batch_size==1 in fast path. Reduce eval batch size.")
            # Wrap to prevent in-place growth during generation
            return ReadOnlyCache(past_key_values)
        
        # Ensure proper device placement when expanding tensors
        if batch_size == 1:
            # No expansion needed, just ensure device consistency
            return tuple(
                tuple(t.contiguous() for t in layer)
                for layer in past_key_values
            )
        else:
            # Get device from the first tensor to ensure consistency
            first_tensor = past_key_values[0][0]
            target_device = first_tensor.device
            
            return tuple(
                tuple(t.expand(batch_size, *t.shape[1:]).contiguous().to(target_device) for t in layer)
                for layer in past_key_values
            )

    @torch.no_grad()
    def _generate_with_past_cache(
        self,
        model_for_generation: PreTrainedModel,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        max_new_tokens: int,
        past_key_values,  # Can be Cache object or tuple
        past_length: int,
        **kwargs,
    ) -> torch.Tensor:
        # Extract parameters with the same defaults as the main generate method
        do_sample = kwargs.get('do_sample', False)
        temperature = float(kwargs.get('temperature', 0.0))  # Default to 0.0 to match main method
        top_p = float(kwargs.get('top_p', 1.0))  # Default to 1.0 to match transformers
        top_k = int(kwargs.get('top_k', 50))
        repetition_penalty = float(kwargs.get('repetition_penalty', 1.0))
        num_beams = int(kwargs.get('num_beams', 1))
        pad_token_id = kwargs.get('pad_token_id', self.tokenizer.pad_token_id)
        eos_token_id = kwargs.get('eos_token_id', self.tokenizer.eos_token_id)

        batch_size, total_len = input_ids.shape
        device = input_ids.device

        # Expand past to batch size
        cur_past = self._expand_past_for_batch(past_key_values, batch_size)

        # Advance past with the tail tokens after the cached context
        tail_ids = input_ids[:, past_length:]
        tail_len = tail_ids.shape[1]

        self._toggle_gradient_checkpointing(model_for_generation, disable=True)
        if tail_len > 0:
            full_mask = torch.cat([
                torch.ones((batch_size, past_length), dtype=attention_mask.dtype, device=device),
                attention_mask[:, past_length:],
            ], dim=1)
            outputs = model_for_generation(
                input_ids=tail_ids,
                attention_mask=full_mask,
                past_key_values=cur_past,
                use_cache=True,
            )
            cur_past = outputs.past_key_values
            next_logits = outputs.logits[:, -1, :]
        else:
            # Bootstrap by feeding the last context token to get initial logits
            last_ctx = input_ids[:, max(past_length - 1, 0):past_length]
            full_mask = torch.ones((batch_size, past_length + 1), dtype=attention_mask.dtype, device=device)
            outputs = model_for_generation(
                input_ids=last_ctx,
                attention_mask=full_mask,
                past_key_values=cur_past,
                use_cache=True,
            )
            cur_past = outputs.past_key_values
            next_logits = outputs.logits[:, -1, :]

        generated = []
        finished = torch.zeros(batch_size, dtype=torch.bool, device=device)
        generated_tokens = input_ids.clone()  # Track all generated tokens for repetition penalty

        for _ in range(max_new_tokens):
            logits = next_logits.clone()
            
            # Apply repetition penalty if needed
            if repetition_penalty != 1.0:
                for batch_idx in range(batch_size):
                    for token_id in generated_tokens[batch_idx]:
                        if logits[batch_idx, token_id] < 0:
                            logits[batch_idx, token_id] *= repetition_penalty
                        else:
                            logits[batch_idx, token_id] /= repetition_penalty
            
            if do_sample and temperature > 0:
                logits = logits / temperature
                # Top-k filtering
                if top_k > 0:
                    topk_vals, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                    kth = topk_vals[:, -1:].expand_as(logits)
                    logits = torch.where(logits < kth, torch.full_like(logits, float('-inf')), logits)
                # Top-p (nucleus) filtering
                if 0.0 < top_p < 1.0:
                    sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                    cumulative_probs = torch.softmax(sorted_logits, dim=-1).cumsum(dim=-1)
                    sorted_mask = cumulative_probs > top_p
                    # shift mask to include at least one token
                    sorted_mask[..., 1:] = sorted_mask[..., :-1].clone()
                    sorted_mask[..., 0] = 0
                    logits[torch.arange(batch_size).unsqueeze(-1), sorted_indices] = torch.where(
                        sorted_mask, torch.full_like(sorted_logits, float('-inf')), sorted_logits
                    )
                probs = torch.softmax(logits, dim=-1)
                next_tokens = torch.multinomial(probs, num_samples=1).squeeze(-1)
            else:
                # Greedy decoding
                next_tokens = torch.argmax(logits, dim=-1)

            # Respect EOS and PAD tokens
            if eos_token_id is not None:
                next_tokens = torch.where(
                    finished, torch.full_like(next_tokens, eos_token_id), next_tokens
                )
            elif pad_token_id is not None:
                next_tokens = torch.where(
                    finished, torch.full_like(next_tokens, pad_token_id), next_tokens
                )

            generated.append(next_tokens)
            finished |= (next_tokens == eos_token_id)
            
            # Update generated_tokens for repetition penalty tracking
            generated_tokens = torch.cat([generated_tokens, next_tokens.unsqueeze(1)], dim=1)
            
            if torch.all(finished):
                break

            # Advance with the new token
            outputs = model_for_generation(
                input_ids=next_tokens.unsqueeze(1),
                past_key_values=cur_past,
                use_cache=True,
            )
            cur_past = outputs.past_key_values
            next_logits = outputs.logits[:, -1, :]

        self._toggle_gradient_checkpointing(model_for_generation, disable=False)

        if generated:
            gen_seq = torch.stack(generated, dim=1)
            return torch.cat([input_ids, gen_seq], dim=1)
        else:
            return input_ids
    
    def save_checkpoint(self, checkpoint_path: Path, step: int, epoch: int, loss: float):
        """Save model checkpoint in HuggingFace format for vLLM/HuggingFace compatibility."""
        checkpoint_path.mkdir(parents=True, exist_ok=True)
        
        # Get the actual model (unwrap DDP if needed)
        model_to_save = self.model.module if hasattr(self.model, 'module') else self.model
        
        if self.is_main_process:
            print(f"💾 Saving HuggingFace-compatible checkpoint to {checkpoint_path}")
        
        # Save in HuggingFace format for vLLM compatibility
        try:
            # Get base model for config reference
            base_model = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
            
            # CRITICAL FIX: Handle LoRA adapters properly for vLLM
            if self.current_adapter and hasattr(model_to_save, 'merge_and_unload'):
                if self.is_main_process:
                    print("🔀 Merging LoRA adapter for vLLM compatibility...")
                
                # Merge LoRA weights into the model
                merged_model = model_to_save.merge_and_unload()
                
                if self.is_main_process:
                    print("✅ Successfully merged LoRA adapter")
                
                # Save the model
                merged_model.save_pretrained(checkpoint_path)
                if self.is_main_process:
                    print(f"✅ Saved merged model to {checkpoint_path}")
                
                # CRITICAL: Ensure config.json has model_type
                config_path = checkpoint_path / "config.json"
                if config_path.exists():
                    import json
                    with open(config_path, 'r') as f:
                        config_dict = json.load(f)
                    
                    # Add model_type if missing
                    if 'model_type' not in config_dict and hasattr(base_model.config, 'model_type'):
                        config_dict['model_type'] = base_model.config.model_type
                        with open(config_path, 'w') as f:
                            json.dump(config_dict, f, indent=2)
                        if self.is_main_process:
                            print(f"✅ Added model_type '{base_model.config.model_type}' to config.json")
                elif hasattr(base_model, 'config'):
                    # Create config if it doesn't exist
                    base_model.config.save_pretrained(checkpoint_path)
                    if self.is_main_process:
                        print("✅ Created config.json from base model")
                
            elif hasattr(model_to_save, 'save_pretrained'):
                # For full fine-tuning or other adapters
                model_to_save.save_pretrained(checkpoint_path)
            else:
                # Fallback: try to get the base model and save it
                base_model = getattr(model_to_save, 'base_model', model_to_save)
                if hasattr(base_model, 'save_pretrained'):
                    base_model.save_pretrained(checkpoint_path)
                else:
                    # Last resort: save state dict with warning
                    torch.save(model_to_save.state_dict(), checkpoint_path / "pytorch_model.bin")
                    if self.is_main_process:
                        print("⚠️  Could not use save_pretrained, saved state dict only")
            
            # Save tokenizer (required for vLLM)
            if hasattr(self, 'tokenizer') and self.tokenizer is not None:
                self.tokenizer.save_pretrained(checkpoint_path)
                if self.is_main_process:
                    print("✅ Saved tokenizer")
            else:
                if self.is_main_process:
                    print("⚠️ No tokenizer found - vLLM evaluation may fail")
            
            # Save additional checkpoint metadata
            metadata = {
                'step': step,
                'epoch': epoch,
                'loss': loss,
                'model_name': self.model_name,
                'adapter_type': self.current_adapter.__class__.__name__ if self.current_adapter else None,
                'checkpoint_format': 'huggingface',
                'vllm_compatible': True,
                'is_merged': hasattr(model_to_save, 'merge_and_unload')  # Track if LoRA was merged
            }
            
            import json
            with open(checkpoint_path / "checkpoint_metadata.json", 'w') as f:
                json.dump(metadata, f, indent=2)
            
            # Also save adapter state separately if using adapters (for debugging)
            if self.current_adapter is not None:
                adapter_state = self.current_adapter.get_state_dict()
                torch.save(adapter_state, checkpoint_path / "adapter_state.pt")
            
            if self.is_main_process:
                print(f"✅ Saved HuggingFace checkpoint: step={step}, epoch={epoch}, loss={loss:.4f}")
                print(f"   Model files: {list(checkpoint_path.glob('*'))}")
                
        except Exception as e:
            if self.is_main_process:
                print(f"❌ Error saving HuggingFace checkpoint: {e}")
                print("   Falling back to state dict save...")
            
            # Fallback to original state dict saving
            torch.save(model_to_save.state_dict(), checkpoint_path / "model.pt")
            
            # Save adapter state if using adapters
            if self.current_adapter is not None:
                adapter_state = self.current_adapter.get_state_dict()
                torch.save(adapter_state, checkpoint_path / "adapter.pt")
            
            # Save checkpoint metadata
            metadata = {
                'step': step,
                'epoch': epoch,
                'loss': loss,
                'model_name': self.model_name,
                'adapter_type': self.current_adapter.__class__.__name__ if self.current_adapter else None,
                'checkpoint_format': 'state_dict',
                'vllm_compatible': False
            }
            
            import json
            with open(checkpoint_path / "metadata.json", 'w') as f:
                json.dump(metadata, f, indent=2)
            
            if self.is_main_process:
                print(f"⚠️  Saved fallback checkpoint: step={step}, epoch={epoch}, loss={loss:.4f}")
    
    def load_checkpoint(self, checkpoint_path: Path):
        """Load model checkpoint for evaluation."""
        # Check what format the checkpoint is in
        metadata_files = [
            checkpoint_path / "checkpoint_metadata.json",
            checkpoint_path / "metadata.json"
        ]
        
        metadata = None
        for metadata_file in metadata_files:
            if metadata_file.exists():
                import json
                with open(metadata_file, 'r') as f:
                    metadata = json.load(f)
                break
        
        checkpoint_format = metadata.get('checkpoint_format', 'state_dict') if metadata else 'state_dict'
        
        if checkpoint_format == 'huggingface':
            # Load HuggingFace format
            model_to_load = self.model.module if hasattr(self.model, 'module') else self.model
            if hasattr(model_to_load, 'load_state_dict'):
                # Load from HuggingFace format
                from transformers import AutoModelForCausalLM
                # [OFFLINE MODE] 这里是从本地 checkpoint 加载，不需要联网，但加上 local_files_only 以防万一
                loaded_model = AutoModelForCausalLM.from_pretrained(checkpoint_path, device_map=None, local_files_only=True)
                model_to_load.load_state_dict(loaded_model.state_dict())
                if self.is_main_process:
                    print(f"✅ Loaded HuggingFace checkpoint from {checkpoint_path}")
            else:
                if self.is_main_process:
                    print("⚠️  Cannot load HuggingFace format, model doesn't support load_state_dict")
                checkpoint_format = 'state_dict'  # Fall back
        
        if checkpoint_format == 'state_dict':
            # Load original state dict format
            model_state_path = checkpoint_path / "model.pt"
            if model_state_path.exists():
                model_to_load = self.model.module if hasattr(self.model, 'module') else self.model
                model_to_load.load_state_dict(torch.load(model_state_path))
                if self.is_main_process:
                    print(f"✅ Loaded state dict checkpoint from {checkpoint_path}")
            
            # Load adapter state if exists
            adapter_state_path = checkpoint_path / "adapter.pt"
            if adapter_state_path.exists() and self.current_adapter is not None:
                adapter_state = torch.load(adapter_state_path)
                self.current_adapter.load_state_dict(adapter_state)
        
        return metadata

    def test_time_train_on_reasoning(
        self,
        eval_dataset: LoadDataset,
        config: Dict,
        logger: Optional[WandBLogger] = None,
        max_length: Optional[int] = None,
        max_reasoning_tokens: Optional[int] = None,
        max_answer_tokens: Optional[int] = None,
        eval_config: Optional[Dict] = None,
        output_dir: Optional[str] = None,
        use_enhanced_eval: bool = True,
        use_vllm_for_eval: bool = False,
    ):
        """
        Performs test-time training on the model's own generated reasoning.
        For each problem, it first generates a reasoning trace, then fine-tunes
        on that trace, and finally generates and evaluates the final answer.
        """
        all_results = []
        problems = eval_dataset.problems
        if "num_problems" in config and config["num_problems"] is not None:
            problems = problems[:config["num_problems"]]

        adaptation_config = config.get('adaptation', {})
        method = adaptation_config.get('method', 'lora')

        progress_bar = tqdm(enumerate(problems), total=len(problems), desc="Reasoning TTT")
        
        for problem_idx, problem in progress_bar:
            saved_state = self._save_model_state()
            
            # 1. Generate reasoning
            reasoning_prompt = problem['question']
            reasoning_input_ids = self.tokenizer.encode(reasoning_prompt, return_tensors='pt')
            
            with torch.no_grad():
                reasoning_output_ids = self.generate(
                    input_ids=reasoning_input_ids,
                    attention_mask=torch.ones_like(reasoning_input_ids),
                    max_new_tokens=config.get("reasoning_budget", 512)
                )
            full_reasoning_text = self.tokenizer.decode(reasoning_output_ids[0], skip_special_tokens=True)
            if full_reasoning_text.startswith(reasoning_prompt):
                generated_reasoning = full_reasoning_text[len(reasoning_prompt):].strip()
            else:
                generated_reasoning = full_reasoning_text.strip()

            reasoning_problem = {"question": reasoning_prompt, "solution": generated_reasoning}
            reasoning_dataset = self._create_single_problem_dataset(
                reasoning_problem, eval_dataset.tokenizer, eval_dataset.max_context_length,
                eval_dataset.max_question_length, eval_dataset.max_solution_length
            )
            
            # Setup adapter for this reasoning problem
            # Ensure no prior adapters are attached before applying a new one
            self._ensure_no_active_peft()
            base_model_for_adapter = self.base_model.module if hasattr(self.base_model, 'module') else self.base_model
            reasoning_adapter = get_adapter(method, base_model_for_adapter, adaptation_config)
            adapted_model = reasoning_adapter.prepare_model()
            self.model = adapted_model
            self.model.train()
            
            problem_results = self._train_single_problem(
                single_problem_dataset=reasoning_dataset,
                problem=problem,
                problem_idx=problem_idx,
                config=config,
                max_length=max_length,
                eval_config=eval_config,
                current_adapter=reasoning_adapter,
                zeroscrolls_dir=None,
                use_enhanced_eval=use_enhanced_eval,
                use_vllm_for_eval=use_vllm_for_eval,
                logger=logger
            )
            all_results.append(problem_results)

            # 5. Restore model state
            self._restore_model_state(saved_state)
        
        # Aggregate results across all problems
        if all_results:
            all_metrics = {}
            for result in all_results:
                metrics = result.get('metrics', {})
                for key, value in metrics.items():
                    if key not in all_metrics:
                        all_metrics[key] = []
                    all_metrics[key].append(value)
            aggregated_metrics = {}
            for key, value in all_metrics.items():
                if key == 'correct':
                    aggregated_metrics['accuracy'] = np.mean(value)
                else:
                    aggregated_metrics[key] = np.mean(value)
            
            # Log aggregated results
            if logger is not None:
                for metric_name, metric_value in aggregated_metrics.items():
                    logger.log_metric(f"eval/{metric_name}", metric_value, step=(problem_idx+1)*config['num_epochs'])
            
            # Save final results
            if output_dir:
                final_results_file = output_dir / "results.json"
                with open(final_results_file, 'w') as f:
                    json.dump({
                        'aggregated_metrics': aggregated_metrics,
                        'individual_results': all_results,
                        'num_problems_processed': len(all_results),
                        'config': config
                    }, f, indent=2)
                print(f"📁 Saved aggregated results to {final_results_file}")
        
        # Restore original model state
        self._restore_model_state(saved_state)
        
        print(f"🎯 ZeroSCROLLS per-problem TTT completed!")
        print(f"   Processed: {len(all_results)}/{len(problems)} problems")
        if aggregated_metrics:
            print(f"   Average performance: {aggregated_metrics.get('average_accuracy', 0.0):.3f}")
        
        return {
            'metrics': aggregated_metrics,
            'individual_results': all_results,
            'num_problems_processed': len(all_results)
        }

    def _create_single_problem_dataset(self, problem: Dict, tokenizer, max_context_length: int, 
                                       max_question_length: int, max_solution_length: int):
        """Create a dataset with just one problem for individual TTT."""
        from ..data.load_dataset import LoadDataset
        
        # Create a dataset with just this problem for training
        # Use the problem's context as training data
        single_problem_dataset = LoadDataset(
            model_name=self.model_name,
            problems=[problem],  # Just this one problem
            tokenizer=tokenizer,
            max_context_examples=0,  # No additional context examples
            max_context_length=max_context_length,
            max_question_length=max_question_length,
            max_solution_length=max_solution_length,
            context_problems=None,  # No additional context
            mask_question_in_loss=False,
            eval_mode=True,
            reasoning_mode=False,
            create_long_context_sequence=False,  # Use individual problem
        )
        
        return single_problem_dataset