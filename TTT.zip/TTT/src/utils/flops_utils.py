"""flops_utils.py
UPDATED: Provides *exact-ish* FLOP estimates based on transformer architecture
parameters (layer count, hidden size, feed-forward dim, etc.) instead of the
coarse per-token multiplier.

If you only need a quick relative comparison you can still rely on the
`estimate_flops` function that treats every token as 1 FLOP.  For architecture
aware accounting use `estimate_exact_flops` (see docstring below).
Utility functions to produce rough FLOP estimates for different experiment
modes (context-only, TTT, GRPO, etc.).

The goal is *not* to provide cycle-accurate hardware accounting, but rather a
fast analytic rule-of-thumb that lets us compare configurations at the same
"compute budget" (tokens × passes).  We deliberately keep the formulae
simple, assuming that
• each forward pass over one token costs *flop_per_token* FLOPs, and
• each backward pass costs the same amount again (≈ symmetrical work).
The constant *flop_per_token* cancels when we only need *relative* budgets,
so by default it is set to 1.

----------------------------------------------------------------------------
Estimate rules
----------------------------------------------------------------------------
1. Context-only (in-context learning, no training)
FLOPs = N_eval × (reasoning_budget + answer_budget) × flop_per_token

2. Test-Time-Training ("ttt" + variants)
FLOPs = 2 × N_train × seq_len × num_epochs            # forward+backward
        + N_eval × (reasoning_budget + answer_budget)   # inference

3. GRPO (policy optimisation with K rollouts per prompt)
FLOPs = 2 × N_train × seq_len × num_epochs            # policy updates
        + K × N_train × answer_budget                   # sampled rollouts
        + N_eval × (reasoning_budget + answer_budget)

The function is intentionally minimal; pass only what you need.
"""

from __future__ import annotations

from typing import Literal

Mode = Literal["context_only", "ttt", "grpo", "reasoning_ttt"]


def estimate_flops(
    *,
    mode: Mode,
    num_train_examples: Optional[int] = None,
    train_seq_len: Optional[int] = None,
    num_epochs: int = 1,
    reasoning_budget: int = 0,
    answer_budget: int = 0,
    num_eval_examples: int = 0,
    # GRPO-specific
    num_samples_per_prompt: int = 1,
    # constant that multiplies every token (keep at 1 for relative comparisons)
    flop_per_token: float = 1.0,
) -> float:
    """Return a rough FLOP estimate for the given experiment *mode*.

    Parameters
    ----------
    mode: str
        One of ``"context_only"``, ``"ttt"``, ``"grpo"``, or ``"reasoning_ttt"``.
    num_train_examples: Optional[int]
        Number of training/context examples seen during TTT/GRPO.  Ignored for
        ``context_only``.
    train_seq_len: Optional[int]
        Effective sequence length of each training example (context + question +
        solution).  Ignored for ``context_only``.
    num_epochs: int, default 1
        How many epochs of TTT/GRPO are performed.  For plain TTT this is often
        \=100.
    reasoning_budget: int, default 0
        Max new tokens generated *before* the final answer during evaluation.
    answer_budget: int, default 0
        Max new tokens for the final answer during evaluation.
    num_eval_examples: int, default 0
        How many problems are evaluated at the end.
    num_samples_per_prompt: int, default 1
        For GRPO: number of rollout samples per prompt (affects compute during
        sampling).
    flop_per_token: float, default 1.0
        Multiplier translating *tokens* → FLOPs.  When making *relative*
        comparisons you can keep the default of 1.

    Returns
    -------
    float
        Estimated FLOPs.
    """

    mode = mode.lower()
    if mode not in {"context_only", "ttt", "grpo", "reasoning_ttt"}:
        raise ValueError(f"Unsupported mode: {mode}")

    # Inference cost common to all modes
    inference_tokens = num_eval_examples * (reasoning_budget + answer_budget)
    inference_flops = inference_tokens * flop_per_token

    if mode == "context_only":
        return inference_flops

    # All remaining modes involve training
    if num_train_examples is None or train_seq_len is None:
        raise ValueError("num_train_examples and train_seq_len must be provided for training modes")

    training_tokens = num_train_examples * train_seq_len * num_epochs
    training_flops = 2 * training_tokens * flop_per_token  # fwd + bwd

    if mode == "ttt" or mode == "reasoning_ttt":
        return training_flops + inference_flops

    if mode == "grpo":
        # Extra compute for rollouts (forward only)
        rollout_tokens = num_train_examples * answer_budget * num_samples_per_prompt
        rollout_flops = rollout_tokens * flop_per_token
        return training_flops + rollout_flops + inference_flops

    # Should never reach here
    raise RuntimeError("Unhandled mode")


# ---------------------------------------------------------------------------
# Convenience: estimate directly from the full experiment *config* dict
# ---------------------------------------------------------------------------

def estimate_flops_from_config(config: dict, *, flop_per_token: float = 1.0) -> float:
    """Wrapper around :func:`estimate_flops` that pulls the right fields out of
    the experiment ``config`` dictionary produced by ``create_config_from_args``.
    
    Only the fields that influence our analytic FLOP model are accessed; if the
    config does not contain some of them an informative ``ValueError`` is
    raised.
    """
    mode = config.get("mode")
    if mode is None:
        raise ValueError("config must contain a 'mode' key")

    data_cfg = config.get("data", {})
    ttt_cfg = config.get("ttt", {})
    eval_cfg = config.get("eval", {})

    return estimate_flops(
        mode=mode,
        num_train_examples=data_cfg.get("max_train_examples"),
        train_seq_len=data_cfg.get("max_length"),  # =context+question+reasoning in training
        num_epochs=ttt_cfg.get("num_epochs", 1),
        reasoning_budget=eval_cfg.get("reasoning_budget", 0),
        answer_budget=eval_cfg.get("answer_budget", 0),
        num_eval_examples=len(config.get("eval_dataset", [])) if "eval_dataset" in config else 0,
        num_samples_per_prompt=ttt_cfg.get("num_samples_per_prompt", 1),
        flop_per_token=flop_per_token,
    )

# =============================================================================
# Architecture-aware exact-ish FLOP estimation
# =============================================================================
from typing import Optional

try:
    # transformers is an optional dependency here – only needed if users want to
    # derive the numbers straight from a HuggingFace model identifier.
    from transformers import AutoConfig  # type: ignore
except ImportError:  # pragma: no cover – transformers not installed
    AutoConfig = None  # type: ignore


def _layer_forward_flops(seq_len: int, hidden_size: int, intermediate_size: int) -> int:
    """Approximate FLOPs for **one** transformer layer (forward pass).

    Formula loosely based on standard GPT-style architecture with quadratic
    dot-product attention (no flash / linear attention tricks).

    Components counted:
        • Q,K,V,O projections: 4 × S × H × H
        • Attention score + weighted sum: 2 × S² × H   (multiply-adds)
        • Feed-forward (geglu/linear): 2 × S × H × I
    where S=seq_len, H=hidden_size, I=intermediate_size (usually 4×H).
    """
    proj_flops = 4 * seq_len * hidden_size * hidden_size
    attn_flops = 2 * seq_len * seq_len * hidden_size
    ffn_flops = 2 * seq_len * hidden_size * intermediate_size
    return proj_flops + attn_flops + ffn_flops


def _layer_forward_flops_lora(seq_len: int, hidden_size: int, intermediate_size: int, 
                              lora_r: int, lora_target_modules: List[str]) -> int:
    """Approximate FLOPs for **one** transformer layer (forward pass) with LoRA adapters.

    LoRA adds low-rank matrices A and B such that the adaptation is BA where:
    - A: H × r (down projection)  
    - B: r × H (up projection)
    
    For each LoRA-adapted projection, we add:
    - Down projection: S × H × r
    - Up projection: S × r × H
    Total per adapted projection: 2 × S × H × r
    
    Args:
        seq_len: Sequence length
        hidden_size: Model hidden dimension
        intermediate_size: Feed-forward intermediate dimension
        lora_r: LoRA rank
        lora_target_modules: List of modules with LoRA (e.g., ["q_proj", "v_proj", "k_proj", "o_proj"])
    """
    # Base transformer layer FLOPs (unchanged)
    base_flops = _layer_forward_flops(seq_len, hidden_size, intermediate_size)
    
    # Additional LoRA FLOPs
    lora_flops = 0
    
    # Standard attention projection modules
    attention_modules = {"q_proj", "k_proj", "v_proj", "o_proj"}
    # Standard FFN modules  
    ffn_modules = {"gate_proj", "up_proj", "down_proj", "fc1", "fc2"}
    
    for module in lora_target_modules:
        if module in attention_modules:
            # Attention projections: input/output size is hidden_size
            lora_flops += 2 * seq_len * hidden_size * lora_r
        elif module in ffn_modules:
            # FFN projections: could be H→I or I→H
            if module in {"gate_proj", "up_proj", "fc1"}:  # H → I
                lora_flops += 2 * seq_len * hidden_size * lora_r
            elif module in {"down_proj", "fc2"}:  # I → H  
                lora_flops += 2 * seq_len * intermediate_size * lora_r
        # Note: For simplicity, assume all LoRA modules are H×H. 
        # In practice, you might want more precise accounting.
    
    return base_flops + lora_flops


def _layer_backward_flops_lora(seq_len: int, hidden_size: int, intermediate_size: int,
                               lora_r: int, lora_target_modules: List[str]) -> int:
    """Approximate backward FLOPs for LoRA training.
    
    Key insight: In LoRA training, we only compute gradients for the LoRA parameters,
    not the frozen base model weights. This significantly reduces backward pass cost.
    
    Backward pass cost is roughly:
    - Gradient computation for LoRA A matrices: S × H × r  
    - Gradient computation for LoRA B matrices: S × r × H
    Total per LoRA module: 2 × S × H × r (same as forward)
    
    Plus we still need the full forward activations for gradient computation,
    but gradients only flow through LoRA paths.
    """
    # For LoRA, backward pass cost is primarily from LoRA parameter gradients
    lora_backward_flops = 0
    
    attention_modules = {"q_proj", "k_proj", "v_proj", "o_proj"}
    ffn_modules = {"gate_proj", "up_proj", "down_proj", "fc1", "fc2"}
    
    for module in lora_target_modules:
        if module in attention_modules:
            lora_backward_flops += 2 * seq_len * hidden_size * lora_r
        elif module in ffn_modules:
            if module in {"gate_proj", "up_proj", "fc1"}:
                lora_backward_flops += 2 * seq_len * hidden_size * lora_r  
            elif module in {"down_proj", "fc2"}:
                lora_backward_flops += 2 * seq_len * intermediate_size * lora_r
    
    # Add some overhead for activation gradients (but much less than full backward)
    base_activation_overhead = seq_len * hidden_size * 4  # rough estimate
    
    return lora_backward_flops + base_activation_overhead


def _model_forward_flops(seq_len: int, num_layers: int, hidden_size: int, intermediate_size: int) -> int:
    """Forward FLOPs for a full transformer stack."""
    return num_layers * _layer_forward_flops(seq_len, hidden_size, intermediate_size)


def _get_arch_params(
    *,
    model_name: Optional[str] = None,
    num_hidden_layers: Optional[int] = None,
    hidden_size: Optional[int] = None,
    intermediate_size: Optional[int] = None,
) -> tuple[int, int, int]:
    """Resolve architecture parameters, optionally loading from a HuggingFace config."""
    if model_name is not None:
        if AutoConfig is None:
            raise ImportError("transformers not installed – cannot fetch config for '" + model_name + "'")
        cfg = AutoConfig.from_pretrained(model_name, trust_remote_code=True)
        num_hidden_layers = cfg.num_hidden_layers
        hidden_size = cfg.hidden_size
        intermediate_size = getattr(cfg, "intermediate_size", 4 * cfg.hidden_size)

    elif num_hidden_layers is None or hidden_size is None or intermediate_size is None:
        raise ValueError("Must provide either 'model_name' or (num_hidden_layers & hidden_size)")

    return num_hidden_layers, hidden_size, intermediate_size


def estimate_exact_flops(
    *,
    mode: Mode,
    # Training / evaluation counts
    train_batch_size: Optional[int] = None,
    seq_len: Optional[int] = None,
    train_seq_len: Optional[int] = None,
    num_epochs: int = 1,
    num_eval_examples: int = 1,
    reasoning_budget: int = 0,
    answer_budget: int = 0,
    num_samples_per_prompt: int = 1,
    # LoRA-specific parameters
    use_lora: bool = False,
    lora_r: int = 16,
    lora_target_modules: Optional[List[str]] = None,
    # Architecture – provide any of these OR just model_name
    model_name: Optional[str] = None,
    num_hidden_layers: Optional[int] = None,
    hidden_size: Optional[int] = None,
    intermediate_size: Optional[int] = None,
) -> float:
    """Estimate total FLOPs using a transformer-aware formula.

    This is a more detailed counterpart to :pyfunc:`estimate_flops`.
    Pass either a ``model_name`` (HuggingFace ID) **or** the raw architecture
    numbers (``num_hidden_layers`` & ``hidden_size``).  ``intermediate_size``
    defaults to 4×hidden_size if omitted.
    """

    mode = mode.lower()
    if mode not in {"context_only", "ttt", "grpo", "reasoning_ttt"}:
        raise ValueError(f"Unsupported mode: {mode}")

    n_layers, h_size, i_size = _get_arch_params(
        model_name=model_name,
        num_hidden_layers=num_hidden_layers,
        hidden_size=hidden_size,
        intermediate_size=intermediate_size,
    )
    
    # Default LoRA target modules if not specified
    if use_lora and lora_target_modules is None:
        lora_target_modules = ["q_proj", "v_proj"]  # common default

    # Helper to compute forward FLOPs for an arbitrary sequence length
    def forward_flops(seq_len: int) -> int:
        if use_lora:
            return n_layers * _layer_forward_flops_lora(seq_len, h_size, i_size, lora_r, lora_target_modules)
        else:
            return _model_forward_flops(seq_len, n_layers, h_size, i_size)

    def backward_flops(seq_len: int) -> int:
        if use_lora:
            return n_layers * _layer_backward_flops_lora(seq_len, h_size, i_size, lora_r, lora_target_modules)
        else:
            # Full fine-tuning: backward ≈ forward
            return forward_flops(seq_len)

    # -----------------------
    # Inference-only baseline
    # -----------------------
    inference_seq_len = seq_len + reasoning_budget + answer_budget  # omitting prompt length for simplicity
    inference_flops = num_eval_examples * forward_flops(inference_seq_len)

    if mode == "context_only":
        return inference_flops

    # -----------------------
    # Modes with training
    # -----------------------
    if train_batch_size is None or seq_len is None:
        raise ValueError("Training modes require 'train_batch_size' and 'seq_len'")

    train_forward_flops = forward_flops(train_seq_len) * train_batch_size
    train_backward_flops = backward_flops(train_seq_len) * train_batch_size
    train_total_flops = (train_forward_flops + train_backward_flops) * num_epochs

    if mode in {"ttt", "reasoning_ttt"}:
        return train_total_flops + inference_flops

    if mode == "grpo":
        # Extra forward passes for rollouts (no backward)
        rollout_flops = train_batch_size * num_samples_per_prompt * forward_flops(answer_budget)
        return train_total_flops + rollout_flops + inference_flops

    raise RuntimeError("Unhandled mode")


def estimate_exact_flops_from_config(config: dict) -> float:
    """Wrapper to estimate exact FLOPs from experiment config, including LoRA support."""
    mode = config.get("mode")
    if mode is None:
        raise ValueError("config must contain a 'mode' key")

    data_cfg = config.get("data", {})
    ttt_cfg = config.get("ttt", {})
    eval_cfg = config.get("eval", {})
    model_cfg = config.get("model", {})
    
    # Extract LoRA configuration
    adaptation_cfg = ttt_cfg.get("adaptation", {})
    use_lora = adaptation_cfg.get("method") == "lora"
    lora_r = adaptation_cfg.get("lora_r", 16)
    lora_target_modules = adaptation_cfg.get("lora_target_modules", None)
    
    return estimate_exact_flops(
        mode=mode,
        train_batch_size=data_cfg.get("max_train_examples"),
        seq_len=data_cfg.get("max_context_length", 0),
        train_seq_len=data_cfg.get("max_length"),
        num_epochs=ttt_cfg.get("num_epochs", 1),
        num_eval_examples=1,  # Usually evaluating one problem at a time
        reasoning_budget=eval_cfg.get("reasoning_budget", 0),
        answer_budget=eval_cfg.get("answer_budget", 0),
        num_samples_per_prompt=ttt_cfg.get("num_samples_per_prompt", 1),
        use_lora=use_lora,
        lora_r=lora_r,
        lora_target_modules=lora_target_modules,
        model_name=model_cfg.get("name"),
    )
