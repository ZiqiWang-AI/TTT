"""
GPU utilities for multi-GPU optimization and memory management.
"""

import torch
import torch.distributed as dist
import logging
from typing import Dict, List, Optional, Union
import os
import psutil
import gc

logger = logging.getLogger(__name__)

def get_gpu_info() -> Dict:
    """Get information about available GPUs."""
    if not torch.cuda.is_available():
        return {"available": False, "count": 0}
    
    gpu_count = torch.cuda.device_count()
    gpu_info = {
        "available": True,
        "count": gpu_count,
        "devices": []
    }
    
    for i in range(gpu_count):
        props = torch.cuda.get_device_properties(i)
        memory_total = torch.cuda.get_device_properties(i).total_memory
        memory_allocated = torch.cuda.memory_allocated(i)
        memory_free = memory_total - memory_allocated
        
        gpu_info["devices"].append({
            "id": i,
            "name": props.name,
            "memory_total_gb": memory_total / 1e9,
            "memory_allocated_gb": memory_allocated / 1e9,
            "memory_free_gb": memory_free / 1e9,
            "compute_capability": f"{props.major}.{props.minor}"
        })
    
    return gpu_info

def optimize_memory_settings():
    """Apply memory optimization settings for multi-GPU training."""
    if torch.cuda.is_available():
        # Enable memory pool allocator
        torch.cuda.empty_cache()
        
        # Set memory growth to avoid fragmentation
        os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"
        
        # Enable TensorFloat-32 for faster training on Ampere GPUs
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        
        # Enable cuDNN auto-tuner for optimal kernel selection
        torch.backends.cudnn.benchmark = True
        
        logger.info("Applied GPU memory optimizations")

def create_device_map(model_name: str, gpu_count: int) -> Dict:
    """
    Create an optimal device map for model parallelism.
    
    Args:
        model_name: Name of the model to get layer count estimates
        gpu_count: Number of available GPUs
    
    Returns:
        Device map dictionary for model placement
    """
    if gpu_count <= 1:
        return "cuda:0"
    
    # Estimate layer distribution based on model size
    if "7B" in model_name or "8B" in model_name:
        # For 7B-8B models, distribute across available GPUs
        layers_per_gpu = 32 // gpu_count
        device_map = {}
        
        for i in range(gpu_count):
            start_layer = i * layers_per_gpu
            end_layer = min((i + 1) * layers_per_gpu, 32)
            for layer_idx in range(start_layer, end_layer):
                device_map[f"model.layers.{layer_idx}"] = f"cuda:{i}"
        
        # Place embedding and output layers
        device_map["model.embed_tokens"] = "cuda:0"
        device_map["model.norm"] = f"cuda:{gpu_count-1}"
        device_map["lm_head"] = f"cuda:{gpu_count-1}"
        
    elif "13B" in model_name:
        # For 13B models, need more careful distribution
        layers_per_gpu = 40 // gpu_count
        device_map = {}
        
        for i in range(gpu_count):
            start_layer = i * layers_per_gpu
            end_layer = min((i + 1) * layers_per_gpu, 40)
            for layer_idx in range(start_layer, end_layer):
                device_map[f"model.layers.{layer_idx}"] = f"cuda:{i}"
        
        device_map["model.embed_tokens"] = "cuda:0"
        device_map["model.norm"] = f"cuda:{gpu_count-1}"
        device_map["lm_head"] = f"cuda:{gpu_count-1}"
        
    else:
        # Default: use auto device mapping
        return "auto"
    
    return device_map

def setup_distributed_training(rank: int, world_size: int, master_port: int = 12355):
    """
    Initialize distributed training setup.
    
    Args:
        rank: Rank of current process
        world_size: Total number of processes
        master_port: Port for communication
    """
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = str(master_port)
    os.environ['RANK'] = str(rank)
    os.environ['LOCAL_RANK'] = str(rank)
    os.environ['WORLD_SIZE'] = str(world_size)
    
    # Initialize the process group
    dist.init_process_group(
        backend='nccl',
        rank=rank,
        world_size=world_size
    )
    
    # Set CUDA device for this process
    torch.cuda.set_device(rank)
    
    logger.info(f"Initialized distributed training: rank {rank}/{world_size}")

def cleanup_distributed():
    """Clean up distributed training resources."""
    if dist.is_initialized():
        dist.destroy_process_group()

def clear_gpu_memory(device_ids: Optional[List[int]] = None):
    """
    Clear GPU memory on specified devices.
    
    Args:
        device_ids: List of GPU device IDs to clear. If None, clear all available.
    """
    if not torch.cuda.is_available():
        return
    
    if device_ids is None:
        device_ids = list(range(torch.cuda.device_count()))
    
    for device_id in device_ids:
        with torch.cuda.device(device_id):
            torch.cuda.empty_cache()
    
    # Force garbage collection
    gc.collect()

def monitor_gpu_memory() -> Dict:
    """Monitor current GPU memory usage across all devices."""
    if not torch.cuda.is_available():
        return {"available": False}
    
    memory_info = {"available": True, "devices": []}
    
    for i in range(torch.cuda.device_count()):
        allocated = torch.cuda.memory_allocated(i)
        reserved = torch.cuda.memory_reserved(i)
        total = torch.cuda.get_device_properties(i).total_memory
        
        memory_info["devices"].append({
            "device_id": i,
            "allocated_gb": allocated / 1e9,
            "reserved_gb": reserved / 1e9,
            "total_gb": total / 1e9,
            "utilization": allocated / total * 100
        })
    
    return memory_info

def estimate_batch_size(model_size_gb: float, sequence_length: int, available_memory_gb: float) -> int:
    """
    Estimate optimal batch size based on model size and available memory.
    
    Args:
        model_size_gb: Model size in GB
        sequence_length: Input sequence length
        available_memory_gb: Available GPU memory in GB
    
    Returns:
        Estimated optimal batch size
    """
    # Rough estimation: activations use ~4x model size per token
    memory_per_token_gb = (model_size_gb * 4) / 1000  # Convert to GB per token
    memory_per_sequence_gb = memory_per_token_gb * sequence_length
    
    # Reserve 20% memory for CUDA overhead and gradients
    usable_memory_gb = available_memory_gb * 0.8
    
    # Calculate batch size
    estimated_batch_size = max(1, int(usable_memory_gb / memory_per_sequence_gb))
    
    # Cap at reasonable maximum
    return min(estimated_batch_size, 32)

def auto_select_device_strategy(model_name: str) -> Dict:
    """
    Automatically select the best device strategy based on available hardware.
    
    Args:
        model_name: Name of the model
    
    Returns:
        Dictionary with recommended device strategy
    """
    gpu_info = get_gpu_info()
    
    if not gpu_info["available"]:
        return {"strategy": "cpu", "device": "cpu"}
    
    gpu_count = gpu_info["count"]
    total_memory_gb = sum(dev["memory_free_gb"] for dev in gpu_info["devices"])
    
    # Estimate model memory requirements
    if "7B" in model_name or "8B" in model_name:
        model_memory_gb = 16  # Rough estimate for 7B-8B models in fp16
    elif "13B" in model_name:
        model_memory_gb = 26  # Rough estimate for 13B models
    elif "30B" in model_name or "33B" in model_name:
        model_memory_gb = 66  # Rough estimate for 30B+ models
    else:
        model_memory_gb = 16  # Default estimate
    
    strategy = {
        "model_memory_gb": model_memory_gb,
        "total_available_memory_gb": total_memory_gb,
        "gpu_count": gpu_count
    }
    
    if model_memory_gb <= gpu_info["devices"][0]["memory_free_gb"] * 0.8:
        # Model fits on single GPU
        strategy.update({
            "strategy": "single_gpu",
            "device": "cuda:0",
            "recommended_batch_size": estimate_batch_size(
                model_memory_gb, 2048, gpu_info["devices"][0]["memory_free_gb"]
            )
        })
    elif gpu_count > 1 and model_memory_gb <= total_memory_gb * 0.8:
        # Model fits across multiple GPUs
        strategy.update({
            "strategy": "multi_gpu_model_parallel",
            "device": "auto",
            "device_map": create_device_map(model_name, gpu_count),
            "recommended_batch_size": estimate_batch_size(
                model_memory_gb, 2048, total_memory_gb / gpu_count
            )
        })
    elif gpu_count > 1:
        # Use distributed training
        strategy.update({
            "strategy": "distributed_data_parallel",
            "device": "cuda",
            "use_distributed": True,
            "world_size": gpu_count,
            "recommended_batch_size": estimate_batch_size(
                model_memory_gb, 2048, gpu_info["devices"][0]["memory_free_gb"]
            )
        })
    else:
        # Fallback to CPU or smaller model
        strategy.update({
            "strategy": "cpu_fallback",
            "device": "cpu",
            "warning": "Model too large for available GPU memory"
        })
    
    return strategy 