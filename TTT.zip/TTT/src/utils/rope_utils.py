import math
from typing import Optional

try:
    import torch
except Exception:
    torch = None


def _unwrap_hf_model(model):
    """Return the underlying HF PreTrainedModel regardless of wrappers."""
    # TTTLanguageModel
    if hasattr(model, 'model'):
        model_obj = model.model
    else:
        model_obj = model
    # DDP / Accelerate wrapper
    if hasattr(model_obj, 'module'):
        model_obj = model_obj.module
    return model_obj


def _get_config(model_obj):
    return getattr(model_obj, 'config', None)


def _get_max_positions_from_config(cfg):
    if cfg is None:
        return None
    for name in ['max_position_embeddings', 'n_positions', 'max_sequence_length', 'n_ctx']:
        val = getattr(cfg, name, None)
        if val is not None:
            try:
                return int(val)
            except Exception:
                pass
    return None


def maybe_apply_yarn_to_hf_model(model, needed_total_len: int, eval_config: Optional[dict] = None, buffer_tokens: Optional[int] = None) -> bool:
    """
    Apply YaRN rope scaling to an HF model if the requested total sequence length
    exceeds the model's current positional limit.

    - model: TTTLanguageModel or HF PreTrainedModel
    - needed_total_len: prompt_len + max_new_tokens (+ optional buffer)
    - eval_config: may contain 'enable_yarn', 'yarn_orig_max_pos', 'yarn_factor'
    - buffer_tokens: override safety buffer (default 20 if not provided)

    Returns True if scaling was applied, else False.
    """
    cfg = eval_config or {}
    buf = buffer_tokens if buffer_tokens is not None else int(cfg.get('yarn_buffer_tokens', 20))
    requested = int(needed_total_len) + buf

    model_obj = _unwrap_hf_model(model)
    model_cfg = _get_config(model_obj)

    current_max = _get_max_positions_from_config(model_cfg)
    # Source of truth for original max positions
    original_max = int(cfg.get('yarn_orig_max_pos', current_max if current_max is not None else 32768))

    # Decide if we should enable YaRN
    enable_flag = bool(cfg.get('enable_yarn', False)) or (current_max is not None and requested > current_max)

    if not enable_flag:
        return False

    # Compute required factor
    required_factor = math.ceil(requested / max(1, original_max))
    user_factor = cfg.get('yarn_factor', None)
    try:
        factor = float(user_factor) if user_factor is not None else float(required_factor)
    except Exception:
        factor = float(required_factor)

    # Cap factor to a reasonable range
    if factor < 1.0:
        factor = 1.0
    if factor > 4.0:
        # Keep consistent with vLLM path
        factor = 4.0

    # Skip if no scaling needed
    if factor <= 1.0:
        return False

    # Prepare HF rope_scaling dict (HF expects key 'type', not 'rope_type')
    rope_scaling = {
        'type': 'yarn',
        'factor': float(factor),
        'original_max_position_embeddings': int(original_max),
    }

    # Apply to config in-place
    if model_cfg is not None:
        try:
            setattr(model_cfg, 'rope_scaling', rope_scaling)
            # Also raise the visible max positions if the config exposes the field
            target_max = int(original_max * factor)
            if hasattr(model_cfg, 'max_position_embeddings'):
                setattr(model_cfg, 'max_position_embeddings', target_max)
        except Exception:
            # Best-effort application
            pass

    # Return True to indicate we attempted scaling
    return True


