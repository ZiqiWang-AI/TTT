# [OFFLINE MODE] 注释掉 wandb 以禁用联网
# import wandb
from typing import Dict, Any, Optional
import logging
from pathlib import Path
import json

logger = logging.getLogger(__name__)

class WandBLogger:
    """Wrapper for W&B logging with experiment tracking."""
    
    def __init__(
        self,
        project: str,
        config: Dict[str, Any],
        mode: str = "disabled",  # [OFFLINE MODE] 默认禁用 wandb
        name: Optional[str] = None,
        group: Optional[str] = None,
    ):
        """
        Initialize W&B logger.
        
        Args:
            project: W&B project name
            config: Configuration dictionary
            mode: W&B mode ('online', 'offline', or 'disabled')
            name: Optional run name
            group: Optional group name for related experiments
        """
        # [OFFLINE MODE] 强制禁用 wandb 联网
        self.enabled = False  # mode != "disabled"
        if not self.enabled:
            self.step = 0
            logger.info("[OFFLINE MODE] W&B logging disabled")
            return
            
        # [OFFLINE MODE] 以下代码被禁用
        # # Generate a descriptive run name if not provided
        # if name is None:
        #     adaptation_method = config.get('ttt', {}).get('adaptation', {}).get('method', 'unknown')
        #     name = f"{adaptation_method}-{wandb.util.generate_id()}"
        # 
        # # Initialize wandb
        # wandb.init(
        #     project=project,
        #     config=config,
        #     name=name,
        #     group=group,
        #     mode=mode
        # )
        
        self.step = 0
        logger.info(f"Initialized W&B logging: project={project}, run={name}")
    
    def log_training_step(
        self,
        loss: float,
        learning_rate: float,
        step: int,
        epoch: Optional[int] = None,
        **additional_metrics
    ):
        """Log training step metrics."""
        if not self.enabled:
            return
            
        metrics = {
            'train/loss': loss,
            'train/learning_rate': learning_rate,
            'train/step': step,
        }
        
        if epoch is not None:
            metrics['train/epoch'] = epoch
            
        metrics.update({f'train/{k}': v for k, v in additional_metrics.items()})
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # wandb.log(metrics, step=self.step)
        self.step += 1
    
    def log_evaluation(
        self,
        metrics: Dict[str, float],
        step: Optional[int] = None,
        prefix: str = 'eval'
    ):
        """Log evaluation metrics."""
        if not self.enabled:
            return
            
        # Add prefix to metric names
        metrics = {f'{prefix}/{k}': v for k, v in metrics.items()}
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # wandb.log(metrics, step=step or self.step)
        pass
    
    def log_metric(
        self,
        metric_name: str,
        value: float,
        step: Optional[int] = None
    ):
        """Log a single metric with optional custom step."""
        if not self.enabled:
            return
        
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # wandb.log({metric_name: value}, step=step or self.step)
        pass
    
    def log_example(
        self,
        question: str,
        reference: str,
        prediction: str,
        correct: bool,
        example_id: int
    ):
        """Log an example prediction."""
        if not self.enabled:
            return
        
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # wandb.log({
        #     f'examples/{example_id}/question': question,
        #     f'examples/{example_id}/reference': reference,
        #     f'examples/{example_id}/prediction': prediction,
        #     f'examples/{example_id}/correct': correct
        # }, step=self.step)
        pass
    
    def log_model_summary(self, num_params_total: int, num_params_trainable: int):
        """Log model parameter statistics."""
        if not self.enabled:
            return
        
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # wandb.log({
        #     'model/num_parameters_total': num_params_total,
        #     'model/num_parameters_trainable': num_params_trainable,
        #     'model/trainable_param_ratio': num_params_trainable / num_params_total
        # }, step=self.step)
        pass
    
    def log_epoch_summary(
        self,
        epoch: int,
        avg_loss: float,
        total_batches: int,
        **additional_metrics
    ):
        """Log epoch-level summary metrics."""
        if not self.enabled:
            return
            
        metrics = {
            'epoch/number': epoch,
            'epoch/avg_loss': avg_loss,
            'epoch/total_batches': total_batches,
        }
        
        metrics.update({f'epoch/{k}': v for k, v in additional_metrics.items()})
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # wandb.log(metrics, step=self.step)
        pass
    
    def save_config(self, output_dir: str):
        """Save the wandb config to a file."""
        if not self.enabled:
            return
            
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # config_path = output_dir / 'wandb_config.json'
        # with open(config_path, 'w') as f:
        #     json.dump(dict(wandb.config), f, indent=2)
        #     
        # logger.info(f"Saved W&B config to {config_path}")
        pass
    
    def finish(self):
        """Finish the wandb run."""
        if not self.enabled:
            return
        
        # [OFFLINE MODE] 注释掉 wandb 联网调用
        # wandb.finish()
        pass 