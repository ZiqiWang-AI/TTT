"""
Evaluation utilities for test-time training experiments.
"""

import os
# Disable tokenizer parallelism to avoid forking warnings
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import torch
import numpy as np
import json
import re
from pathlib import Path
from typing import Dict, Any, Optional, List
from tqdm import tqdm
from torch.utils.data import DataLoader
from functools import partial
import time

from ..data.load_dataset import LoadDataset, collate_fn
from ..utils.rope_utils import maybe_apply_yarn_to_hf_model

# Try to import enhanced evaluator
try:
    from ..evaluation.enhanced_eval import evaluate_with_vllm, math_equal_enhanced, extract_answer_from_prediction, bank_transactions_equal
    ENHANCED_EVAL_AVAILABLE = True
except ImportError:
    ENHANCED_EVAL_AVAILABLE = False
    print("Enhanced evaluator not available, using basic evaluation")

# Try to import formal proof evaluator
try:
    from ..evaluation.formal_proof_eval import FormalProofEvaluator, evaluate_formal_proofs
    FORMAL_PROOF_EVAL_AVAILABLE = True
except ImportError:
    FORMAL_PROOF_EVAL_AVAILABLE = False
    print("Formal proof evaluator not available")

# Try to import ZeroSCROLLS evaluation metrics
try:
    from rouge_score import rouge_scorer
    from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    import nltk
    ZEROSCROLLS_EVAL_AVAILABLE = True
    
    # Download required NLTK data
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        nltk.download('punkt', quiet=True)
        
except ImportError as e:
    ZEROSCROLLS_EVAL_AVAILABLE = False
    print(f"ZeroSCROLLS evaluation metrics not available: {e}")
    print("To enable, install: pip install rouge-score nltk scikit-learn")


def cleanup_memory():
    """
    Comprehensive CUDA memory cleanup after evaluation.
    This ensures memory is properly freed before returning to training.
    """
    import gc
    import torch
    
    # Force garbage collection
    gc.collect()
    
    # Clear CUDA cache multiple times for thorough cleanup
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()  # Ensure all operations complete
        torch.cuda.empty_cache()  # Clear again after sync
        
        # Reset memory allocator if available
        try:
            torch.cuda.reset_peak_memory_stats()
        except:
            pass
    
    print("🧹 Memory cleanup completed")


def generate_single_example(
    model,  # TTTLanguageModel
    problem: Dict,
    eval_config: Dict[str, Any],
    max_length: int,
    silent: bool = True,
) -> Dict[str, Any]:
    """
    Generate and evaluate a single example efficiently.
    Returns just the example data without aggregation overhead.
    
    Args:
        model: The language model
        problem: Single problem dictionary
        eval_config: Evaluation configuration
        max_length: Maximum sequence length
        silent: Whether to suppress output
    
    Returns:
        Dictionary containing the example result
    """
    # Create single-example dataset
    from ..data.load_dataset import LoadDataset
    
    # CRITICAL FIX: For frozen KV evaluation, use smart truncation that preserves the question
    # Check if we're in frozen KV mode by looking for active frozen KV cache
    is_frozen_kv_mode = getattr(model, '_active_frozen_kv', None) is not None
    
    if is_frozen_kv_mode:
        # For frozen KV mode, use a larger context length since context was pre-truncated
        # and we want to ensure the question is never truncated
        eval_max_context_length = max_length * 2  # Allow more space
        if model.is_main_process:
            print(f"🧊 Using frozen KV evaluation mode with extended context length: {eval_max_context_length}")
    else:
        eval_max_context_length = max_length
    
    eval_dataset = LoadDataset(
        model_name=model.model_name,
        problems=[problem],
        tokenizer=model.tokenizer,
        max_context_examples=0,
        max_context_length=eval_max_context_length,
        max_question_length=max_length // 2,  # Give more space to questions
        max_solution_length=max_length // 4,
        context_problems=None,
        eval_mode=True,
        reasoning_mode=eval_config.get('reasoning_budget', 0) > 0,
    )
    
    if len(eval_dataset) == 0:
        return {
            'prediction': '',
            'question': problem.get('question', ''),
            'answer': problem.get('answer', ''),
            'correct': False,
            'error': 'Failed to create dataset'
        }
    
    # Get the single example
    from functools import partial
    from torch.utils.data import DataLoader
    from ..data.load_dataset import collate_fn
    
    collate_fn_with_args = partial(
        collate_fn, 
        tokenizer=model.tokenizer, 
        max_length=max_length
    )
    
    dataloader = DataLoader(
        eval_dataset,
        batch_size=1,
        shuffle=False,
        collate_fn=collate_fn_with_args
    )
    
    model.model.eval()
    with torch.no_grad():
        batch = next(iter(dataloader))
        
        # Move to correct device: for sharded models, use embedding device
        try:
            is_sharded = getattr(model.base_model, 'hf_device_map', None) is not None
        except Exception:
            is_sharded = False
        device_for_batch = model._get_embedding_device() if is_sharded else (model.device if not isinstance(model.device, dict) else list(model.device.values())[0])
        input_ids = batch['input_ids'].to(device_for_batch)
        attention_mask = batch['attention_mask'].to(device_for_batch)
        
        # Add /think suffix for reasoning mode to match vLLM approach
        reasoning_budget = eval_config.get('reasoning_budget', 0)
        if reasoning_budget > 0:
            # Decode current prompt and add /think suffix
            current_prompt = model.tokenizer.decode(input_ids[0], skip_special_tokens=True)
            if not current_prompt.endswith(' /think'):
                reasoning_prompt = current_prompt + ' /think'
                # Re-tokenize with /think suffix
                reasoning_tokens = model.tokenizer.encode(reasoning_prompt, return_tensors="pt").to(device_for_batch)
                reasoning_mask = torch.ones_like(reasoning_tokens).to(device_for_batch)
                input_ids = reasoning_tokens
                attention_mask = reasoning_mask
        
        # Generate prediction using two-phase approach
        final_prompts, reasoning_texts, predictions = generate_single_sample_batch(
            model=model,
            input_ids=input_ids,
            attention_mask=attention_mask,
            eval_config=eval_config,
            silent=silent
        )
        
        prediction = predictions[0]
        reasoning_text = reasoning_texts[0]
        final_prompt = final_prompts[0]
        
        # For reasoning mode, the prediction already includes the reasoning and answer parts
        # No need to remove input prompt since generate_single_sample_batch handles it
        
        # Get answer and question
        question = batch['raw_questions'][0]
        answer = batch['raw_answers'][0]
        solution = batch['raw_solutions'][0]
        
        # Detect dataset type and evaluate accordingly
        is_zeroscrolls = 'dataset' in problem and problem.get('dataset') in [
            'gov_report', 'summ_screen_fd', 'qmsum', 'squality', 'qasper', 
            'narrative_qa', 'quality', 'musique', 'space_digest', 'book_sum_sort'
        ]
        is_longbench_v2 = 'dataset' in problem and problem.get('dataset', '').startswith('longbench_v2_')
        is_olmo_bugs = 'dataset' in problem and problem.get('dataset').startswith('olmo_bugs_')
        
        if is_olmo_bugs:
            # Use OLMo Bugs evaluation
            from ..evaluation.enhanced_eval import compute_olmo_bugs_metrics
            
            # For OLMo bugs, use the full prediction without time limit truncation
            # The time limit logic can truncate the JSON response incorrectly
            full_model_response = prediction
            
            # Check if we have reasoning and answer components from two-phase generation
            if reasoning_text and reasoning_text.strip():
                # Combine reasoning and final answer for complete model response
                full_model_response = reasoning_text + '\n\n' + prediction
            
            # Compute detailed metrics using the full response
            olmo_metrics = compute_olmo_bugs_metrics(full_model_response, answer or solution)
            
            is_correct = olmo_metrics['overall_correct']
            location_correct = olmo_metrics['location_correct']
            fix_correct = olmo_metrics['fix_correct']
            
            # Additional metrics for detailed analysis
            metrics = {
                'overall_correct': is_correct,
                'location_correct': location_correct,
                'fix_correct': fix_correct,
                'extracted_json': olmo_metrics.get('extracted_json', {}),
                'pred_location': olmo_metrics.get('pred_location', ''),
                'ref_location': olmo_metrics.get('ref_location', ''),
                'pred_fix': olmo_metrics.get('pred_fix', ''),
                'ref_fix': olmo_metrics.get('ref_fix', ''),
                'correct': is_correct  # For compatibility
            }
            
            # For OLMo bugs, use the full response in the cleaned prediction
            cleaned_prediction = full_model_response.strip()
        elif is_zeroscrolls:
            # Use ZeroSCROLLS evaluation
            dataset_name = problem.get('dataset', 'unknown')
            task_type = _get_task_type_for_dataset(dataset_name)
            cleaned_prediction = _clean_zeroscrolls_prediction(prediction, task_type)
            metrics = _compute_single_example_metrics(cleaned_prediction, answer or solution, task_type)
            is_correct = metrics.get('exact_match', 0.0) > 0.5 or metrics.get('rouge', 0.0) > 0.3
        elif is_longbench_v2:
            # Use LongBench-v2 evaluation (reuse ZeroSCROLLS metrics with mc_qa task type)
            dataset_name = problem.get('dataset', 'unknown')
            task_type = _get_task_type_for_dataset(dataset_name)
            cleaned_prediction = _clean_zeroscrolls_prediction(prediction, task_type)
            metrics = _compute_single_example_metrics(cleaned_prediction, answer or solution, task_type)
            # For mc_qa, use accuracy as the primary metric
            is_correct = metrics.get('accuracy', 0.0) > 0.5
        else:
            # Use enhanced evaluation if available
            try:
                from ..evaluation.enhanced_eval import math_equal_enhanced, extract_answer_from_prediction, bank_transactions_equal
                
                # Check if this is a bank transactions dataset
                is_bank_transactions = (
                    hasattr(problem, 'get') and (
                        problem.get('dataset') == 'bank_transactions_easy' or
                        problem.get('is_bank_transactions', False)
                    )
                )
                
                if is_bank_transactions:
                    # Use bank transactions evaluation
                    is_correct = bank_transactions_equal(prediction, answer)
                    cleaned_prediction = prediction.strip()
                else:
                    # Use standard math evaluation
                    extracted_prediction = extract_answer_from_prediction(prediction)
                    is_correct = math_equal_enhanced(extracted_prediction, answer)
                    cleaned_prediction = extracted_prediction
                
                # Only set basic metrics if not already set by dataset-specific evaluation
                if 'metrics' not in locals():
                    metrics = {'correct': is_correct}
            except ImportError:
                # Fallback to simple string match
                cleaned_prediction = prediction.strip()
                is_correct = answer in cleaned_prediction if answer else False
                metrics = {'correct': is_correct}
        
        cleanup_memory()
        return {
            'final_prompt': final_prompt,
            'prediction': cleaned_prediction,
            'full_prediction': prediction,
            'reasoning': reasoning_text,
            'post-reasoning': prediction,
            'question': question,
            'answer': answer,
            'solution': solution,
            'correct': is_correct,
            'metrics': metrics,
            'problem_id': problem.get('id', 'unknown'),
            'dataset': problem.get('dataset', 'unknown'),
            'prediction_length': len(prediction.split()),
        }


def _get_zeroscrolls_task_type(dataset_name: str) -> str:
    """Get task type for ZeroSCROLLS dataset."""
    task_mapping = {
        'gov_report': 'summarization',
        'summ_screen_fd': 'summarization', 
        'qmsum': 'qb_summarization',
        'squality': 'qb_summarization',
        'qasper': 'qa',
        'narrative_qa': 'qa',
        'musique': 'qa',
        'quality': 'mc_qa',
        'book_sum_sort': 'aggregation',
        'space_digest': 'aggregation',
    }
    return task_mapping.get(dataset_name, 'qa')


def _get_longbench_v2_task_type(dataset_name: str) -> str:
    """Get task type for LongBench-v2 dataset."""
    # All LongBench-v2 problems are multiple choice QA
    if dataset_name.startswith('longbench_v2_'):
        return 'mc_qa'  # Multiple choice QA
    return 'mc_qa'  # Default for LongBench-v2


def _get_task_type_for_dataset(dataset_name: str) -> str:
    """Unified task type getter for both ZeroSCROLLS and LongBench-v2."""
    if dataset_name.startswith('longbench_v2_'):
        return _get_longbench_v2_task_type(dataset_name)
    else:
        return _get_zeroscrolls_task_type(dataset_name)


def generate_and_evaluate(
    model,  # TTTLanguageModel - avoiding import for now
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    use_enhanced: bool = True,  # New parameter to enable enhanced evaluation
    checkpoint_path: str = None,  # Path to saved model checkpoint for vLLM
    use_vllm_for_eval: bool = False,  # Use vLLM for base model (in-context learning)
) -> Dict[str, Any]:
    """
    Generate solutions and evaluate them for each example.
    
    Args:
        model: The language model (TTTLanguageModel)
        eval_dataset: Dataset containing evaluation examples
        eval_config: Evaluation configuration
        max_length: Maximum sequence length for tokenization
        results_file: Optional file to save results (for final evaluation)
        silent: If True, don't show progress bar or print messages
        num_samples: Number of samples to evaluate
        use_enhanced: If True and available, use enhanced evaluation with better math comparison
        checkpoint_path: Path to saved model checkpoint for vLLM acceleration
        use_vllm_for_eval: If True, use vLLM for base model evaluation (in-context learning)
    
    Returns:
        Dictionary containing metrics and example results
    """
    
    # Initialize results variable
    results = None
    
    # Detect dataset type by checking problem structure
    is_minif2f_dataset = False
    is_zeroscrolls_dataset = False
    is_longbench_v2_dataset = False
    is_olmo_bugs_dataset = False
    target_language = "lean"  # default
    zeroscrolls_dataset = None
    longbench_v2_dataset = None
    olmo_bugs_dataset = None
    
    if hasattr(eval_dataset, 'problems') and eval_dataset.problems:
        sample_problem = eval_dataset.problems[0]
        
        # Check for miniF2F
        if 'target_language' in sample_problem or 'context_setting' in sample_problem:
            is_minif2f_dataset = True
            target_language = sample_problem.get('target_language', 'lean')
            if not silent:
                print(f"🔍 Detected miniF2F dataset with target language: {target_language}")
        
        # Check for ZeroSCROLLS
        elif 'dataset' in sample_problem and sample_problem.get('dataset') in [
            'gov_report', 'summ_screen_fd', 'qmsum', 'squality', 'qasper', 
            'narrative_qa', 'quality', 'musique', 'space_digest', 'book_sum_sort'
        ]:
            is_zeroscrolls_dataset = True
            zeroscrolls_dataset = sample_problem.get('dataset')
            if not silent:
                print(f"🔍 Detected ZeroSCROLLS dataset: {zeroscrolls_dataset}")
        
        # Check for LongBench-v2
        elif 'dataset' in sample_problem and sample_problem.get('dataset', '').startswith('longbench_v2_'):
            is_longbench_v2_dataset = True
            longbench_v2_dataset = sample_problem.get('dataset')
            domain = sample_problem.get('domain', 'unknown')
            if not silent:
                print(f"🔍 Detected LongBench-v2 dataset: {longbench_v2_dataset} (domain: {domain})")

        elif 'dataset' in sample_problem and sample_problem.get('dataset', '').startswith('olmo_bugs_'):
            is_olmo_bugs_dataset = True
            olmo_bugs_dataset = sample_problem.get('dataset', '')
            if not silent:
                print(f"🔍 Detected OLMo Bugs dataset: {olmo_bugs_dataset}")
    
    # Use OLMo bugs-specific evaluation for OLMo bugs datasets
    if is_olmo_bugs_dataset and ENHANCED_EVAL_AVAILABLE:
        if not silent:
            print(f"🐛 Using OLMo Bugs evaluation for {olmo_bugs_dataset}")
        
        results = _generate_and_evaluate_olmo_bugs(
            model, eval_dataset, eval_config, max_length, results_file, 
            silent, num_samples, olmo_bugs_dataset, checkpoint_path, use_vllm_for_eval
        )
    
    # Use ZeroSCROLLS-specific evaluation for ZeroSCROLLS datasets
    elif is_zeroscrolls_dataset and ZEROSCROLLS_EVAL_AVAILABLE:
        if not silent:
            print(f"📊 Using ZeroSCROLLS evaluation for {zeroscrolls_dataset}")
        
        results = _generate_and_evaluate_zeroscrolls(
            model, eval_dataset, eval_config, max_length, results_file, 
            silent, num_samples, zeroscrolls_dataset, checkpoint_path, use_vllm_for_eval
        )
    
            # Use ZeroSCROLLS-like evaluation for LongBench-v2 datasets (reuse evaluation logic with vLLM support)
    elif is_longbench_v2_dataset and ZEROSCROLLS_EVAL_AVAILABLE:
        if not silent:
            print(f"📊 Using LongBench-v2 evaluation (with vLLM support) for {longbench_v2_dataset}")
        
        results = _generate_and_evaluate_zeroscrolls(
            model, eval_dataset, eval_config, max_length, results_file, 
            silent, num_samples, longbench_v2_dataset, checkpoint_path, use_vllm_for_eval
        )
    
    # Use formal proof evaluator for miniF2F datasets
    elif is_minif2f_dataset and FORMAL_PROOF_EVAL_AVAILABLE:
        if not silent:
            print(f"🎯 Using formal proof evaluation for {target_language}")
        
        results = _generate_and_evaluate_formal_proofs(
            model, eval_dataset, eval_config, max_length, results_file, 
            silent, num_samples, target_language, checkpoint_path, use_vllm_for_eval
        )
    # Use enhanced evaluator with vLLM if checkpoint path is provided
    elif use_enhanced and ENHANCED_EVAL_AVAILABLE and checkpoint_path and use_vllm_for_eval:
        if not silent:
            print(f"🚀 Using enhanced evaluation with vLLM from checkpoint: {checkpoint_path}")
        
        # Get dtype from model for consistency
        model_dtype = "auto"  # Default fallback
        if hasattr(model, 'dtype'):
            if model.dtype == torch.float16:
                model_dtype = "float16"
            elif model.dtype == torch.bfloat16:
                model_dtype = "bfloat16"
            else:
                model_dtype = "auto"
        
        results = evaluate_with_vllm(
            model_path=checkpoint_path,
            eval_dataset=eval_dataset,
            eval_config=eval_config,
            results_file=results_file,
            silent=silent,
            num_samples=num_samples,
            max_length=max_length,
            dtype=model_dtype,  # Pass dtype for consistency
            tensor_parallel_size=eval_config.get('tensor_parallel_size', None),
        )
    
    # Use vLLM for base model evaluation (in-context learning)
    elif use_enhanced and ENHANCED_EVAL_AVAILABLE and use_vllm_for_eval:
        if not silent:
            print(f"🚀 Using enhanced evaluation with vLLM for eval model: {model.model_name}")
        
        # Get dtype from model for consistency
        model_dtype = "auto"  # Default fallback
        if hasattr(model, 'dtype'):
            if model.dtype == torch.float16:
                model_dtype = "float16"
            elif model.dtype == torch.bfloat16:
                model_dtype = "bfloat16"
            else:
                model_dtype = "auto"
        
        results = evaluate_with_vllm(
            model_path=model.model_name,  # Use HuggingFace model name directly
            eval_dataset=eval_dataset,
            eval_config=eval_config,
            results_file=results_file,
            silent=silent,
            num_samples=num_samples,
            max_length=max_length,
            dtype=model_dtype,  # Pass dtype for consistency
            tensor_parallel_size=eval_config.get('tensor_parallel_size', None),
        )
    
    # Use enhanced evaluator with HuggingFace if available
    elif use_enhanced and ENHANCED_EVAL_AVAILABLE:
        if not silent:
            print("🧮 Using enhanced evaluation with HuggingFace (better math comparison)")
        
        results = _generate_and_evaluate_enhanced_hf(
            model, eval_dataset, eval_config, max_length, results_file, silent, num_samples
        )
    
    # Fallback to original implementation
    else:
        if not silent:
            print("📝 Using original evaluation")
        results = _generate_and_evaluate_original(
            model, eval_dataset, eval_config, max_length, results_file, silent, num_samples
        )
    
    return results

    cleanup_memory()


def _generate_and_evaluate_original(
    model,  # TTTLanguageModel - avoiding import for now
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Original evaluation implementation (kept for backward compatibility).
    """
    is_correct_list, length_list = [], []  # Accuracy for each sample
    examples = []
    
    # Track per-level metrics for MATH500
    level_metrics = {}  # level -> {'correct': count, 'total': count}
    
    # Clear/create results file if provided
    if results_file is not None:
        if results_file.exists():
            results_file.unlink()
        results_file.touch()
    
    # Create DataLoader for batched evaluation
    collate_fn_with_args = partial(
        collate_fn, 
        tokenizer=model.tokenizer, 
        max_length=max_length
    )
    
    eval_dataloader = DataLoader(
        eval_dataset,
        batch_size=eval_config['batch_size'],
        shuffle=False,  # Keep order for evaluation
        collate_fn=collate_fn_with_args
    )
    
    # Set model to evaluation mode
    model.model.eval()
    
    # Process batches
    progress_bar = None
    if not silent:
        progress_bar = tqdm(eval_dataloader, desc="Evaluating")
    else:
        progress_bar = eval_dataloader
    
    pre_process_prediction = lambda pred: pred.split('Solution:')[-1].strip() if 'Solution:' in pred else pred
    
    # Batch results for file I/O
    batch_results = []
    
    with torch.no_grad():
        num_samples_so_far = 0
        for batch_idx, batch in enumerate(progress_bar):
            batch_size = batch['input_ids'].shape[0]
            
            # Move batch to device once (embedding device if sharded)
            try:
                is_sharded = getattr(model.base_model, 'hf_device_map', None) is not None
            except Exception:
                is_sharded = False
            device_for_batch = model._get_embedding_device() if is_sharded else (model.device if not isinstance(model.device, dict) else list(model.device.values())[0])
            input_ids = batch['input_ids'].to(device_for_batch)
            attention_mask = batch['attention_mask'].to(device_for_batch)
            
            # Generate single sample per query (simplified)
            batch_predictions = generate_single_sample_batch(
                model=model,
                input_ids=input_ids,
                attention_mask=attention_mask,
                eval_config=eval_config,
                silent=silent
            )
            
            # Evaluate each example in the batch
            for i in range(batch_size):
                # Get problem data
                problem_idx = num_samples_so_far + i
                if problem_idx < len(eval_dataset.problems):
                    problem = eval_dataset.problems[problem_idx]
                    problem_level = problem.get('level', 'unknown')
                else:
                    problem_level = 'unknown'
                
                # Decode the input prompt for this example
                input_prompt = model.tokenizer.decode(
                    batch['input_ids'][i], 
                    skip_special_tokens=True
                )
                
                # context = batch['raw_contexts'][i]
                question = batch['raw_questions'][i]
                solution = batch['raw_solutions'][i]
                answer = batch['raw_answers'][i]
                prediction = batch_predictions[i]  # Single prediction now

                if prediction.startswith(input_prompt):
                    # Remove the input prompt to get only the generated text
                    prediction = prediction[len(input_prompt):]
                else:
                    # Fallback: use full prediction if prompt removal fails
                    prediction = prediction
                
                # Check if prediction contains the correct answer
                is_correct = answer in pre_process_prediction(prediction) if prediction else False
                is_correct_list.append(is_correct)
                length_list.append(len(prediction.split(' ')))
                
                # Track per-level metrics
                if problem_level not in level_metrics:
                    level_metrics[problem_level] = {'correct': 0, 'total': 0}
                level_metrics[problem_level]['total'] += 1
                if is_correct:
                    level_metrics[problem_level]['correct'] += 1
                
                # Store example for inspection (only for final evaluation)
                if results_file is not None and len(examples) < 100:
                    example_result = {
                        'input_prompt': input_prompt,
                        # 'context': context,
                        'question': question,
                        'solution': solution,
                        'answer': answer,
                        'prediction': pre_process_prediction(prediction),  # Single prediction
                        'correct': is_correct,
                        'prediction_length': len(prediction.split(' ')),
                        'level': problem_level
                    }
                    examples.append(example_result)
                    batch_results.append(example_result)
            
            num_samples_so_far += batch_size
            if num_samples is not None and num_samples_so_far >= num_samples:
                break
            
            # Clear batch tensors
            del input_ids, attention_mask
            
            # Update progress bar
            if not silent and hasattr(progress_bar, 'set_postfix'):
                current_accuracy = np.mean(is_correct_list) if is_correct_list else 0.0
                progress_bar.set_postfix({'accuracy': f'{current_accuracy:.3f}'})
            
            # File I/O only for final evaluation
            # if batch_results and len(batch_results) >= 50:
            #     write_results_batch(results_file, batch_results)
            #     batch_results = []
            
            # Memory management
            if torch.cuda.is_available() and len(is_correct_list) > 20:
                torch.cuda.empty_cache()
    
    # Write remaining results
    if batch_results and results_file is not None:
        write_results_batch(results_file, batch_results)
    
    if not silent and hasattr(progress_bar, 'close'):
        progress_bar.close()
    
    # Final memory cleanup
    if hasattr(model, '_clear_memory'):
        model._clear_memory()
    
    # Add comprehensive memory cleanup
    cleanup_memory()
    
    # Compile final metrics
    accuracy_mean = np.mean(is_correct_list) if is_correct_list else 0.0
    accuracy_std = np.std(is_correct_list) if is_correct_list else 0.0

    metrics = {
        'answer_accuracy_mean': accuracy_mean,
        'answer_accuracy_std': accuracy_std,
        'total_examples': len(is_correct_list),
        'prediction_length_mean': np.mean(length_list) if length_list else 0.0,
        'prediction_length_std': np.std(length_list) if length_list else 0.0,
    }
    
    # Add per-level metrics
    for level, level_data in level_metrics.items():
        level_accuracy = level_data['correct'] / level_data['total'] if level_data['total'] > 0 else 0.0
        metrics[f'accuracy_level_{level}'] = level_accuracy
        metrics[f'total_level_{level}'] = level_data['total']
        metrics[f'correct_level_{level}'] = level_data['correct']
    
    # Print per-level breakdown if not silent
    if not silent and level_metrics:
        print("\n📊 Per-Level Results:")
        for level in sorted(level_metrics.keys()):
            level_data = level_metrics[level]
            level_accuracy = level_data['correct'] / level_data['total'] if level_data['total'] > 0 else 0.0
            print(f"  Level {level}: {level_data['correct']}/{level_data['total']} = {level_accuracy:.3f}")
    
    return {
        'metrics': metrics,
        'examples': examples,
        'level_breakdown': level_metrics
    }


def _generate_and_evaluate_formal_proofs(
    model,  # TTTLanguageModel
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    target_language: str = "lean",
    checkpoint_path: str = None,
    use_vllm_for_eval: bool = False,
) -> Dict[str, Any]:
    """
    Generate and evaluate formal mathematical proofs for miniF2F dataset.
    
    This function specializes in evaluating formal proofs with syntax, structure,
    and semantic analysis appropriate for theorem proving languages.
    """
    if not FORMAL_PROOF_EVAL_AVAILABLE:
        if not silent:
            print("⚠️ Formal proof evaluator not available, falling back to basic evaluation")
        return _generate_and_evaluate_original(
            model, eval_dataset, eval_config, max_length, results_file, silent, num_samples
        )
    
    # Use vLLM for evaluation if available and requested
    if use_vllm_for_eval and ENHANCED_EVAL_AVAILABLE:
        if checkpoint_path:
            if not silent:
                print(f"🚀 Using vLLM with formal proof evaluation from checkpoint: {checkpoint_path}")
            model_path = checkpoint_path
        else:
            if not silent:
                print(f"🚀 Using vLLM with formal proof evaluation for model: {model.model_name}")
            model_path = model.model_name
        
        return _evaluate_formal_proofs_vllm(
            model_path, eval_dataset, eval_config, max_length, results_file,
            silent, num_samples, target_language
        )
    
    # Use HuggingFace with formal proof evaluation
    if not silent:
        print(f"🧮 Using HuggingFace with formal proof evaluation for {target_language}")
    
    predictions, references, problem_ids = [], [], []
    examples = []
    
    # Clear/create results file if provided
    if results_file is not None:
        if results_file.exists():
            results_file.unlink()
        results_file.touch()
    
    # Create DataLoader for batched evaluation
    collate_fn_with_args = partial(
        collate_fn, 
        tokenizer=model.tokenizer, 
        max_length=max_length
    )
    
    eval_dataloader = DataLoader(
        eval_dataset,
        batch_size=eval_config['batch_size'],
        shuffle=False,
        collate_fn=collate_fn_with_args
    )
    
    # Set model to evaluation mode
    model.model.eval()
    
    # Process batches to generate predictions
    progress_bar = None
    if not silent:
        progress_bar = tqdm(eval_dataloader, desc=f"Generating {target_language} proofs")
    else:
        progress_bar = eval_dataloader
    
    with torch.no_grad():
        num_samples_so_far = 0
        for batch_idx, batch in enumerate(progress_bar):
            batch_size = batch['input_ids'].shape[0]
            
            # Move batch to device once (embedding device if sharded)
            try:
                is_sharded = getattr(model.base_model, 'hf_device_map', None) is not None
            except Exception:
                is_sharded = False
            device_for_batch = model._get_embedding_device() if is_sharded else (model.device if not isinstance(model.device, dict) else list(model.device.values())[0])
            input_ids = batch['input_ids'].to(device_for_batch)
            attention_mask = batch['attention_mask'].to(device_for_batch)
            
            # Generate single sample per query
            batch_predictions = generate_single_sample_batch(
                model=model,
                input_ids=input_ids,
                attention_mask=attention_mask,
                eval_config=eval_config,
                silent=silent
            )
            
            # Extract predictions and references for each example in the batch
            for i in range(batch_size):
                # Get problem data
                problem_idx = num_samples_so_far + i
                if problem_idx < len(eval_dataset.problems):
                    problem = eval_dataset.problems[problem_idx]
                    problem_id = problem.get('problem_id', f"problem_{problem_idx}")
                else:
                    problem_id = f"problem_{problem_idx}"
                
                # Decode the input prompt for this example
                input_prompt = model.tokenizer.decode(
                    batch['input_ids'][i], 
                    skip_special_tokens=True
                )
                
                question = batch['raw_questions'][i]
                solution = batch['raw_solutions'][i]  # This is the formal proof
                answer = batch['raw_answers'][i]      # This should also be the formal proof
                prediction = batch_predictions[i]
                
                # Remove input prompt from prediction
                if prediction.startswith(input_prompt):
                    prediction = prediction[len(input_prompt):]
                
                # Extract only the proof part from prediction
                extracted_prediction = extract_formal_proof(prediction, target_language)
                
                # Store for batch evaluation
                predictions.append(extracted_prediction)
                references.append(solution)  # Use the full solution as reference
                problem_ids.append(problem_id)
                
                # Store example for inspection (only for final evaluation)
                if results_file is not None and len(examples) < 100:
                    examples.append({
                        'input_prompt': input_prompt,
                        'question': question,
                        'reference_solution': solution,
                        'answer': answer,
                        'prediction': extracted_prediction,
                        'full_prediction': prediction,
                        'problem_id': problem_id,
                        'target_language': target_language,
                        'prediction_length': len(extracted_prediction.split()),
                    })
            
            num_samples_so_far += batch_size
            if num_samples and num_samples_so_far >= num_samples:
                break
            
            # Clear batch tensors
            del input_ids, attention_mask
            
            # Memory management
            if torch.cuda.is_available() and len(predictions) > 20:
                torch.cuda.empty_cache()
    
    if not silent and hasattr(progress_bar, 'close'):
        progress_bar.close()
    
    # Final memory cleanup
    if hasattr(model, '_clear_memory'):
        model._clear_memory()
    
    # Evaluate all predictions using formal proof evaluator
    if not silent:
        print(f"📊 Evaluating {len(predictions)} formal proofs...")
    
    eval_results = evaluate_formal_proofs(
        predictions=predictions,
        references=references,
        language=target_language,
        problem_ids=problem_ids
    )
    
    # Convert formal proof evaluation results to standard format
    metrics = {
        'answer_accuracy_mean': eval_results['aggregate_metrics'].get('overall_score_mean', 0.0),
        'answer_accuracy_std': eval_results['aggregate_metrics'].get('overall_score_std', 0.0),
        'exact_match_rate': eval_results['aggregate_metrics'].get('exact_match_rate', 0.0),
        'exact_match_count': eval_results['aggregate_metrics'].get('exact_match_count', 0),
        'total_examples': eval_results['aggregate_metrics'].get('total_problems', 0),
        'prediction_length_mean': np.mean([len(p.split()) for p in predictions]) if predictions else 0.0,
        'prediction_length_std': np.std([len(p.split()) for p in predictions]) if predictions else 0.0,
        
        # Formal proof specific metrics
        'syntax_score_mean': eval_results['aggregate_metrics'].get('syntax_score_mean', 0.0),
        'structure_score_mean': eval_results['aggregate_metrics'].get('structure_score_mean', 0.0),
        'semantic_score_mean': eval_results['aggregate_metrics'].get('semantic_score_mean', 0.0),
        'completeness_score_mean': eval_results['aggregate_metrics'].get('completeness_score_mean', 0.0),
        'target_language': target_language,
    }
    
    # Add individual results to examples for detailed inspection
    for i, example in enumerate(examples):
        if i < len(eval_results['individual_results']):
            individual_result = eval_results['individual_results'][i]
            example['formal_eval'] = individual_result
            example['correct'] = individual_result['overall_score'] > 0.5  # Threshold for "correct"
    
    # Print detailed breakdown if not silent
    if not silent:
        print(f"\n📊 Formal Proof Evaluation Results ({target_language}):")
        print(f"  Overall Score: {metrics['answer_accuracy_mean']:.3f} ± {metrics['answer_accuracy_std']:.3f}")
        print(f"  Exact Matches: {metrics['exact_match_count']}/{metrics['total_examples']} ({metrics['exact_match_rate']:.3f})")
        print(f"  Syntax Score: {metrics['syntax_score_mean']:.3f}")
        print(f"  Structure Score: {metrics['structure_score_mean']:.3f}")
        print(f"  Semantic Score: {metrics['semantic_score_mean']:.3f}")
        print(f"  Completeness Score: {metrics['completeness_score_mean']:.3f}")
    
    # Save results
    if results_file:
        with open(results_file, 'w') as f:
            json.dump({
                'metrics': metrics,
                'examples': examples,
                'formal_eval_details': eval_results,
                'target_language': target_language
            }, f, indent=2)
    
    return {
        'metrics': metrics,
        'examples': examples,
        'formal_eval_details': eval_results
    }


def extract_formal_proof(text: str, language: str) -> str:
    """
    Extract the formal proof portion from generated text.
    
    Args:
        text: Generated text that may contain the proof
        language: Target formal language (lean, isabelle, etc.)
        
    Returns:
        Extracted formal proof text
    """
    if not text:
        return ""
    
    # Language-specific extraction patterns
    if language.lower() == "lean":
        # Look for begin...end blocks or direct proof after :=
        begin_match = re.search(r'begin\s*(.*?)\s*end', text, re.DOTALL)
        if begin_match:
            return f"begin\n  {begin_match.group(1).strip()}\nend"
        
        # Look for assignment-style proofs
        assign_match = re.search(r':=\s*(.*?)(?:\n\n|\Z)', text, re.DOTALL)
        if assign_match:
            return f":= {assign_match.group(1).strip()}"
    
    elif language.lower() == "isabelle":
        # Look for proof...qed or proof...done blocks
        proof_match = re.search(r'proof\s*(.*?)\s*(?:qed|done)', text, re.DOTALL)
        if proof_match:
            return f"proof\n  {proof_match.group(1).strip()}\nqed"
    
    elif language.lower() == "metamath":
        # Look for $= ... $. patterns
        proof_match = re.search(r'\$=\s*(.*?)\s*\$\.', text, re.DOTALL)
        if proof_match:
            return f"$= {proof_match.group(1).strip()} $."
    
    elif language.lower() == "hollight":
        # Look for proof ending with ;;
        proof_match = re.search(r'(.*?);;', text, re.DOTALL)
        if proof_match:
            return f"{proof_match.group(1).strip()};;"
    
    # Fallback: return the entire text, cleaned up
    return text.strip()


def _evaluate_formal_proofs_vllm(
    model_path: str,
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    target_language: str = "lean",
) -> Dict[str, Any]:
    """
    Evaluate formal proofs using vLLM for faster generation.
    """
    try:
        # Generate predictions using vLLM
        vllm_results = evaluate_with_vllm(
            model_path=model_path,
            eval_dataset=eval_dataset,
            eval_config=eval_config,
            results_file=None,  # Don't save vLLM results yet
            silent=silent,
            num_samples=num_samples,
            max_length=max_length
        )
        
        # Extract predictions and references from vLLM results
        predictions, references, problem_ids = [], [], []
        
        for example in vllm_results['examples']:
            # Extract formal proof from prediction
            prediction = extract_formal_proof(example.get('prediction', ''), target_language)
            reference = example.get('solution', example.get('answer', ''))
            problem_id = example.get('problem_id', 'unknown')
            
            predictions.append(prediction)
            references.append(reference)
            problem_ids.append(problem_id)
        
        # Evaluate using formal proof evaluator
        if not silent:
            print(f"📊 Evaluating {len(predictions)} formal proofs with specialized metrics...")
        
        eval_results = evaluate_formal_proofs(
            predictions=predictions,
            references=references,
            language=target_language,
            problem_ids=problem_ids
        )
        
        # Convert to standard format and combine with vLLM results
        formal_metrics = {
            'answer_accuracy_mean': eval_results['aggregate_metrics'].get('overall_score_mean', 0.0),
            'answer_accuracy_std': eval_results['aggregate_metrics'].get('overall_score_std', 0.0),
            'exact_match_rate': eval_results['aggregate_metrics'].get('exact_match_rate', 0.0),
            'exact_match_count': eval_results['aggregate_metrics'].get('exact_match_count', 0),
            'total_examples': eval_results['aggregate_metrics'].get('total_problems', 0),
            'syntax_score_mean': eval_results['aggregate_metrics'].get('syntax_score_mean', 0.0),
            'structure_score_mean': eval_results['aggregate_metrics'].get('structure_score_mean', 0.0),
            'semantic_score_mean': eval_results['aggregate_metrics'].get('semantic_score_mean', 0.0),
            'completeness_score_mean': eval_results['aggregate_metrics'].get('completeness_score_mean', 0.0),
            'target_language': target_language,
        }
        
        # Update vLLM results with formal evaluation metrics
        vllm_results['metrics'].update(formal_metrics)
        
        # Add formal evaluation details to examples
        for i, example in enumerate(vllm_results['examples']):
            if i < len(eval_results['individual_results']):
                individual_result = eval_results['individual_results'][i]
                example['formal_eval'] = individual_result
                example['target_language'] = target_language
        
        # Save final results
        if results_file:
            with open(results_file, 'w') as f:
                json.dump({
                    'metrics': vllm_results['metrics'],
                    'examples': vllm_results['examples'],
                    'formal_eval_details': eval_results,
                    'target_language': target_language
                }, f, indent=2)
        
        return vllm_results
        
    except Exception as e:
        if not silent:
            print(f"⚠️ vLLM evaluation failed: {e}, falling back to HuggingFace")
        # Fallback to HuggingFace evaluation
        return _generate_and_evaluate_original(
            None, eval_dataset, eval_config, max_length, results_file, silent, num_samples
        )


def generate_single_sample_batch(
    model,
    input_ids: torch.Tensor,
    attention_mask: torch.Tensor,
    eval_config: Dict[str, Any],
    silent: bool = False
) -> List[str]:
    """
    Generate single sample per query for a batch using two-phase generation 
    (reasoning + answer) to match vLLM evaluation approach.
    
    Args:
        model: The language model
        input_ids: Input token ids [batch_size, seq_len]
        attention_mask: Attention mask [batch_size, seq_len]
        eval_config: Evaluation configuration
        silent: Whether to suppress output
    
    Returns:
        List of predictions (one per example in the batch)
    """
    start_time = time.time()
    
    # Extract configuration
    reasoning_budget = eval_config.get('reasoning_budget', 0)
    answer_budget = eval_config.get('answer_budget', 512)
    use_time_limit = eval_config.get('use_time_limit_prompt', False)
    time_limit_prompt = eval_config.get('time_limit_prompt', "\n\nOkay, time is up. Let me stop thinking and formulate a final answer:")
    final_answer_tokens = eval_config.get('final_answer_tokens', 64)
    
    # Apply YaRN scaling before generation to avoid exceeding positional limit
    total_needed_len = int(input_ids.shape[1] + reasoning_budget + answer_budget)
    maybe_apply_yarn_to_hf_model(model, needed_total_len=total_needed_len, eval_config=eval_config)
    
    final_prompts, reasoning_texts, answer_texts = [], [], []
    
    # Two-phase generation to match vLLM approach
    if reasoning_budget > 0:
        if not silent:
            print(f"🧠 Phase 1: Generating thinking/reasoning with {reasoning_budget} tokens...")
        
        # Phase 1: Reasoning generation
        reasoning_config = {
            'do_sample': True,  # Use sampling for reasoning like vLLM
            'temperature': 0.6,
            'top_p': 0.95,
            'top_k': 20,
            'use_cache': True,
        }
        
        # Generate reasoning
        reasoning_output_ids = model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_new_tokens=reasoning_budget,
            **reasoning_config
        )
        
        # Decode reasoning outputs
        reasoning_predictions = model.tokenizer.batch_decode(reasoning_output_ids, skip_special_tokens=True)
        
        # Extract just the generated reasoning part
        for i, reasoning_pred in enumerate(reasoning_predictions):
            original_prompt = model.tokenizer.decode(input_ids[i], skip_special_tokens=True)
            if reasoning_pred.startswith(original_prompt):
                reasoning_text = reasoning_pred[len(original_prompt):]
            else:
                reasoning_text = reasoning_pred
            reasoning_texts.append(reasoning_text)
        
        # Create prompts for phase 2 (final answer)
        final_input_ids_list = []
        final_attention_mask_list = []
        
        for i, reasoning_text in enumerate(reasoning_texts):
            original_prompt = model.tokenizer.decode(input_ids[i], skip_special_tokens=True)
            # Construct final prompt like vLLM: original + reasoning + answer prompt
            final_prompt = f"{original_prompt}{reasoning_text}\n\nBased on the reasoning above, the final answer is: /no_think"
            
            # Tokenize the final prompt
            final_tokens = model.tokenizer.encode(final_prompt, return_tensors="pt", truncation=True, max_length=total_needed_len)
            final_input_ids_list.append(final_tokens)
            final_attention_mask_list.append(torch.ones_like(final_tokens))
            
            final_prompts.append(final_prompt)
        
        # Pad sequences to the same length for batching
        max_len = max(seq.shape[1] for seq in final_input_ids_list)
        final_input_ids_batch = torch.zeros((len(final_input_ids_list), max_len), dtype=input_ids.dtype, device=input_ids.device)
        final_attention_mask_batch = torch.zeros((len(final_input_ids_list), max_len), dtype=attention_mask.dtype, device=attention_mask.device)
        
        for i, (ids, mask) in enumerate(zip(final_input_ids_list, final_attention_mask_list)):
            seq_len = ids.shape[1]
            final_input_ids_batch[i, :seq_len] = ids[0]
            final_attention_mask_batch[i, :seq_len] = mask[0]
        
        # Phase 2: Final answer generation (greedy like vLLM)
        if not silent:
            print(f"🧠 Phase 2: Generating final answer with {answer_budget} tokens...")
        
        answer_config = {
            'do_sample': False,  # Greedy for final answer like vLLM
            'use_cache': True,
        }
        
        final_output_ids = model.generate(
            input_ids=final_input_ids_batch,
            attention_mask=final_attention_mask_batch,
            max_new_tokens=answer_budget,
            **answer_config
        )
        
        # Decode final predictions
        final_full_predictions = model.tokenizer.batch_decode(final_output_ids, skip_special_tokens=True)
        
        # Extract just the answer part
        for i, final_pred in enumerate(final_full_predictions):
            final_prompt = model.tokenizer.decode(final_input_ids_batch[i], skip_special_tokens=True)
            if final_pred.startswith(final_prompt):
                answer_text = final_pred[len(final_prompt):]
            else:
                answer_text = final_pred
            
            answer_texts.append(answer_text)
        
        # Clean up intermediate tensors
        del reasoning_output_ids, final_input_ids_batch, final_attention_mask_batch, final_output_ids
    
    else:
        # Single-phase generation (no reasoning budget)
        single_phase_config = {
            'do_sample': False,  # Greedy decoding for consistency
            'use_cache': True,
        }
        
        output_ids = model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_new_tokens=answer_budget,
            **single_phase_config
        )
        
        # Decode single-phase predictions
        single_phase_predictions = model.tokenizer.batch_decode(output_ids, skip_special_tokens=True)
        
        # Extract just the generated part
        for i, pred in enumerate(single_phase_predictions):
            original_prompt = model.tokenizer.decode(input_ids[i], skip_special_tokens=True)
            if pred.startswith(original_prompt):
                generated_text = pred[len(original_prompt):]
            else:
                generated_text = pred
            answer_texts.append(generated_text)
        
        # Clean up
        del output_ids
    
    # Apply time limit prompting if enabled (for both phases)
    if use_time_limit and answer_texts:
        if not silent:
            print(f"🧠 Finally: Generating final answer with {final_answer_tokens} tokens...")
        
        extended_predictions = []
        for i, pred in enumerate(answer_texts):
            # Check if prediction contains clear final answer indicators
            has_final_answer = any(indicator in pred.lower() for indicator in [
                'the answer is', 'final answer', '\\boxed{', 'therefore', 'thus,', 'so the answer'
            ])
            
            if not has_final_answer:
                # Reconstruct the full prompt for this example
                original_prompt = model.tokenizer.decode(input_ids[i], skip_special_tokens=True)
                extended_prompt = original_prompt + pred + time_limit_prompt
                
                # Tokenize the extended prompt
                extended_input_ids = model.tokenizer.encode(extended_prompt, return_tensors="pt").to(input_ids.device)
                extended_attention_mask = torch.ones_like(extended_input_ids).to(input_ids.device)
                
                # Generate final answer continuation
                final_config = {
                    'do_sample': False,
                    'use_cache': True,
                }
                
                final_output_ids = model.generate(
                    input_ids=extended_input_ids,
                    attention_mask=extended_attention_mask,
                    max_new_tokens=final_answer_tokens,
                    **final_config
                )
                
                extended_pred = model.tokenizer.decode(final_output_ids[0], skip_special_tokens=True)
                # Extract just the final answer part
                if extended_pred.startswith(extended_prompt):
                    final_answer_part = extended_pred[len(extended_prompt):]
                    extended_answer = pred + time_limit_prompt + final_answer_part
                else:
                    extended_answer = pred
                
                extended_predictions.append(extended_answer)
                
                # Clean up
                del extended_input_ids, extended_attention_mask, final_output_ids
            else:
                extended_predictions.append(pred)
        
        answer_texts = extended_predictions
    
    if not silent:
        gen_time = time.time() - start_time
        phases = "two-phase" if reasoning_budget > 0 else "single-phase"
        print(f"Generated {input_ids.shape[0]} {phases} samples in {gen_time:.2f}s")
    
    return final_prompts, reasoning_texts, answer_texts


def write_results_batch(results_file: Path, batch_results: List[Dict]) -> None:
    """
    Write a batch of results to file efficiently.
    """
    if results_file is None or not batch_results:
        return
    
    # only store the last 10 results
    batch_results = batch_results[-10:]
    
    with open(results_file, 'a') as f:
        for result in batch_results:
            json.dump(result, f, indent=2)
            f.write('\n')


def _generate_and_evaluate_enhanced_hf(
    model,  # TTTLanguageModel
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Enhanced evaluation using HuggingFace with better math comparison.
    This uses the original model but with enhanced mathematical comparison.
    """
    is_correct_list, length_list = [], []  # Accuracy for each sample
    examples = []
    
    # Track per-level metrics for MATH500
    level_metrics = {}  # level -> {'correct': count, 'total': count}
    
    # Clear/create results file if provided
    if results_file is not None:
        if results_file.exists():
            results_file.unlink()
        results_file.touch()
    
    # Create DataLoader for batched evaluation
    collate_fn_with_args = partial(
        collate_fn, 
        tokenizer=model.tokenizer, 
        max_length=max_length
    )
    
    eval_dataloader = DataLoader(
        eval_dataset,
        batch_size=eval_config['batch_size'],
        shuffle=False,  # Keep order for evaluation
        collate_fn=collate_fn_with_args
    )
    
    # Set model to evaluation mode
    model.model.eval()
    
    # Process batches
    progress_bar = None
    if not silent:
        progress_bar = tqdm(eval_dataloader, desc="Evaluating with enhanced math")
    else:
        progress_bar = eval_dataloader
    
    with torch.no_grad():
        num_samples_so_far = 0
        for batch_idx, batch in enumerate(progress_bar):
            batch_size = batch['input_ids'].shape[0]
            
            # Move batch to device once
            device_for_batch = model.device if not isinstance(model.device, dict) else list(model.device.values())[0]
            input_ids = batch['input_ids'].to(device_for_batch)
            attention_mask = batch['attention_mask'].to(device_for_batch)
            
            # Generate single sample per query (simplified)
            batch_predictions = generate_single_sample_batch(
                model=model,
                input_ids=input_ids,
                attention_mask=attention_mask,
                eval_config=eval_config,
                silent=silent
            )
            
            # Evaluate each example in the batch
            for i in range(batch_size):
                # Get problem data
                problem_idx = num_samples_so_far + i
                if problem_idx < len(eval_dataset.problems):
                    problem = eval_dataset.problems[problem_idx]
                    problem_level = problem.get('level', 'unknown')
                else:
                    problem_level = 'unknown'
                
                # Decode the input prompt for this example
                input_prompt = model.tokenizer.decode(
                    batch['input_ids'][i], 
                    skip_special_tokens=True
                )
                
                question = batch['raw_questions'][i]
                solution = batch['raw_solutions'][i]
                answer = batch['raw_answers'][i]
                prediction = batch_predictions[i]  # Single prediction now

                if prediction.startswith(input_prompt):
                    # Remove the input prompt to get only the generated text
                    prediction = prediction[len(input_prompt):]
                else:
                    # Fallback: use full prediction if prompt removal fails
                    prediction = prediction
                
                # Check if this is a bank transactions dataset
                problem = eval_dataset.problems[i] if i < len(eval_dataset.problems) else {}
                is_bank_transactions = (
                    problem.get('dataset') == 'bank_transactions_easy' or
                    problem.get('is_bank_transactions', False)
                )
                
                # Use appropriate evaluation metric
                if is_bank_transactions:
                    is_correct = bank_transactions_equal(prediction, answer)
                else:
                    is_correct = math_equal_enhanced(prediction, answer)
                is_correct_list.append(is_correct)
                length_list.append(len(prediction.split(' ')))
                
                # Track per-level metrics
                if problem_level not in level_metrics:
                    level_metrics[problem_level] = {'correct': 0, 'total': 0}
                level_metrics[problem_level]['total'] += 1
                if is_correct:
                    level_metrics[problem_level]['correct'] += 1
                
                # Store example for inspection (only for final evaluation)
                if results_file is not None and len(examples) < 100:
                    # Import the enhanced answer extraction function
                    try:
                        extracted_answer = extract_answer_from_prediction(prediction)
                    except ImportError:
                        # Fallback if enhanced eval not available
                        extracted_answer = prediction
                    
                    example_result = {
                        'input_prompt': input_prompt,
                        'question': question,
                        'solution': solution,
                        'answer': answer,
                        'prediction': extracted_answer,
                        'full_prediction': prediction,
                        'correct': is_correct,
                        'prediction_length': len(prediction.split(' ')),
                        'level': problem_level
                    }
                    examples.append(example_result)
            
            num_samples_so_far += batch_size
            if num_samples and num_samples_so_far >= num_samples:
                break
            
            # Clear batch tensors
            del input_ids, attention_mask
            
            # Update progress bar
            if not silent and hasattr(progress_bar, 'set_postfix'):
                current_accuracy = np.mean(is_correct_list) if is_correct_list else 0.0
                progress_bar.set_postfix({'accuracy': f'{current_accuracy:.3f}'})
            
            # Memory management
            if torch.cuda.is_available() and len(is_correct_list) > 20:
                torch.cuda.empty_cache()
    
    if not silent and hasattr(progress_bar, 'close'):
        progress_bar.close()
    
    # Final memory cleanup
    if hasattr(model, '_clear_memory'):
        model._clear_memory()
    
    # Add comprehensive memory cleanup
    cleanup_memory()
    
    # Compute final metrics
    accuracy_mean = np.mean(is_correct_list) if is_correct_list else 0.0
    accuracy_std = np.std(is_correct_list) if is_correct_list else 0.0

    metrics = {
        'answer_accuracy_mean': accuracy_mean,
        'answer_accuracy_std': accuracy_std,
        'total_examples': len(is_correct_list),
        'prediction_length_mean': np.mean(length_list) if length_list else 0.0,
        'prediction_length_std': np.std(length_list) if length_list else 0.0,
    }
    
    # Add per-level metrics
    for level, level_data in level_metrics.items():
        level_accuracy = level_data['correct'] / level_data['total'] if level_data['total'] > 0 else 0.0
        metrics[f'accuracy_level_{level}'] = level_accuracy
        metrics[f'total_level_{level}'] = level_data['total']
        metrics[f'correct_level_{level}'] = level_data['correct']
    
    # Print per-level breakdown if not silent
    if not silent and level_metrics:
        print("\n📊 Per-Level Results (Enhanced Math):")
        for level in sorted(level_metrics.keys()):
            level_data = level_metrics[level]
            level_accuracy = level_data['correct'] / level_data['total'] if level_data['total'] > 0 else 0.0
            print(f"  Level {level}: {level_data['correct']}/{level_data['total']} = {level_accuracy:.3f}")
    
    # Save results
    if results_file:
        with open(results_file, 'w') as f:
            json.dump({
                'metrics': metrics,
                'examples': examples,
                'level_breakdown': level_metrics
            }, f, indent=2)
    
    return {
        'metrics': metrics,
        'examples': examples,
        'level_breakdown': level_metrics
    }


def _generate_and_evaluate_zeroscrolls(
    model,  # TTTLanguageModel
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    dataset_name: str = "gov_report",
    checkpoint_path: str = None,
    use_vllm_for_eval: bool = False,
) -> Dict[str, Any]:
    """
    Generate and evaluate for ZeroSCROLLS datasets with task-specific metrics.
    
    Args:
        model: The language model 
        eval_dataset: Dataset containing evaluation examples
        eval_config: Evaluation configuration
        max_length: Maximum sequence length for tokenization
        results_file: Optional file to save results
        silent: If True, don't show progress bar or print messages
        num_samples: Number of samples to evaluate
        dataset_name: Name of the ZeroSCROLLS sub-dataset
        checkpoint_path: Path to saved model checkpoint for vLLM
        use_vllm_for_eval: If True, use vLLM for generation
    
    Returns:
        Dictionary containing metrics and example results
    """
    # Determine task type based on dataset name (supports both ZeroSCROLLS and LongBench-v2)
    task_type = _get_task_type_for_dataset(dataset_name)
    
    # Use vLLM for evaluation if available and requested
    if use_vllm_for_eval and ENHANCED_EVAL_AVAILABLE:
        if checkpoint_path:
            if not silent:
                print(f"🚀 Using vLLM with ZeroSCROLLS evaluation from checkpoint: {checkpoint_path}")
            model_path = checkpoint_path
        else:
            if not silent:
                print(f"🚀 Using vLLM with ZeroSCROLLS evaluation for model: {model.model_name}")
            model_path = model.model_name
        
        return _evaluate_zeroscrolls_vllm(
            model_path, eval_dataset, eval_config, max_length, results_file,
            silent, num_samples, dataset_name, task_type
        )
    
    # Use HuggingFace with ZeroSCROLLS evaluation
    if not silent:
        print(f"🧮 Using HuggingFace with ZeroSCROLLS evaluation for {dataset_name} ({task_type})")
    
    return _evaluate_zeroscrolls_hf(
        model, eval_dataset, eval_config, max_length, results_file,
        silent, num_samples, dataset_name, task_type
    )


def _evaluate_zeroscrolls_hf(
    model,  # TTTLanguageModel
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    dataset_name: str = "gov_report",
    task_type: str = "summarization",
) -> Dict[str, Any]:
    """
    Evaluate ZeroSCROLLS using HuggingFace with task-specific metrics.
    """
    predictions, references = [], []
    examples = []
    dataset_metrics = {}  # dataset -> {'metric': value}
    
    # Clear/create results file if provided
    if results_file is not None:
        if results_file.exists():
            results_file.unlink()
        results_file.touch()
    
    # Create DataLoader for batched evaluation
    collate_fn_with_args = partial(
        collate_fn, 
        tokenizer=model.tokenizer, 
        max_length=max_length
    )
    
    eval_dataloader = DataLoader(
        eval_dataset,
        batch_size=eval_config['batch_size'],
        shuffle=False,
        collate_fn=collate_fn_with_args
    )
    
    # Set model to evaluation mode
    model.model.eval()
    
    # Process batches to generate predictions
    progress_bar = None
    if not silent:
        progress_bar = tqdm(eval_dataloader, desc=f"Generating {dataset_name} predictions")
    else:
        progress_bar = eval_dataloader
    
    num_samples_so_far = 0
    
    for batch in progress_bar:
        if num_samples and num_samples_so_far >= num_samples:
            break
        
        # Move batch to device before generating predictions (embedding device if sharded)
        try:
            is_sharded = getattr(model.base_model, 'hf_device_map', None) is not None
        except Exception:
            is_sharded = False
        device_for_batch = model._get_embedding_device() if is_sharded else (model.device if not isinstance(model.device, dict) else list(model.device.values())[0])
        input_ids = batch['input_ids'].to(device_for_batch)
        attention_mask = batch['attention_mask'].to(device_for_batch)
        
        # Generate predictions
        batch_predictions = generate_single_sample_batch(
            model, input_ids, attention_mask, eval_config, silent
        )
        
        batch_size = len(batch_predictions)
        
        # Extract predictions and references for each example in the batch
        for i in range(batch_size):
            # Get problem data
            problem_idx = num_samples_so_far + i
            if problem_idx < len(eval_dataset.problems):
                problem = eval_dataset.problems[problem_idx]
                problem_dataset = problem.get('dataset', dataset_name)
            else:
                problem_dataset = dataset_name
            
            # Decode the input prompt for this example
            input_prompt = model.tokenizer.decode(
                input_ids[i], 
                skip_special_tokens=True
            )
            
            question = batch['raw_questions'][i]
            solution = batch['raw_solutions'][i]
            answer = batch['raw_answers'][i]
            prediction = batch_predictions[i]
            
            # Remove input prompt from prediction
            if prediction.startswith(input_prompt):
                prediction = prediction[len(input_prompt):]
            
            # Clean prediction
            prediction = _clean_zeroscrolls_prediction(prediction, task_type)
            
            # Store for batch evaluation
            predictions.append(prediction)
            references.append(answer if answer else solution)
            
            # Track by dataset
            if problem_dataset not in dataset_metrics:
                dataset_metrics[problem_dataset] = {'predictions': [], 'references': []}
            dataset_metrics[problem_dataset]['predictions'].append(prediction)
            dataset_metrics[problem_dataset]['references'].append(answer if answer else solution)
            
            # Store example for inspection
            if results_file is not None and len(examples) < 100:
                examples.append({
                    'input_prompt': input_prompt,
                    'question': question,
                    'reference_solution': solution,
                    'reference_answer': answer,
                    'prediction': prediction,
                    'full_prediction': batch_predictions[i],
                    'dataset': problem_dataset,
                    'task_type': task_type,
                    'prediction_length': len(prediction.split()),
                })
        
        num_samples_so_far += batch_size
        
        # Clear batch tensors
        del batch['input_ids'], batch['attention_mask']
        
        # Memory management
        if torch.cuda.is_available() and len(predictions) > 20:
            torch.cuda.empty_cache()
    
    if not silent and hasattr(progress_bar, 'close'):
        progress_bar.close()
    
    # Final memory cleanup
    if hasattr(model, '_clear_memory'):
        model._clear_memory()
    
    # Evaluate all predictions using ZeroSCROLLS metrics
    if not silent:
        print(f"📊 Evaluating {len(predictions)} predictions for {dataset_name} ({task_type})...")
    
    # compute per example metrics
    metrics = []
    for prediction, reference in zip(predictions, references):
        metrics.append(_compute_single_example_metrics(prediction, reference, task_type))
    
    # average the metrics
    zeroscrolls_metrics = {}
    for metric in metrics:
        for key, value in metric.items():
            if key not in zeroscrolls_metrics:
                zeroscrolls_metrics[key] = []
            zeroscrolls_metrics[key].append(value)
    for key, value in zeroscrolls_metrics.items():
        zeroscrolls_metrics[key] = np.mean(value)
    
    return {
        'metrics': zeroscrolls_metrics,
        'examples': examples,
        'dataset_breakdown': dataset_metrics
    }


def _evaluate_zeroscrolls_vllm(
    model_path: str,
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    dataset_name: str = "gov_report",
    task_type: str = "summarization",
) -> Dict[str, Any]:
    """
    Evaluate ZeroSCROLLS using vLLM for faster generation.
    """
    # Generate predictions using vLLM
    vllm_results = evaluate_with_vllm(
        model_path=model_path,
        eval_dataset=eval_dataset,
        eval_config=eval_config,
        results_file=None,  # Don't save vLLM results yet
        silent=silent,
        num_samples=num_samples,
        max_length=max_length
    )
    
    # Evaluate using ZeroSCROLLS metrics
    if not silent:
        print(f"📊 Evaluating {len(vllm_results['examples'])} predictions with ZeroSCROLLS metrics...")

    # Extract per example metrics
    metrics = []
    for example in vllm_results['examples']:
        # Clean prediction for ZeroSCROLLS
        prediction = _clean_zeroscrolls_prediction(example.get('post-reasoning', ''), task_type)
        reference = example.get('answer', example.get('solution', ''))
        metric = _compute_single_example_metrics(prediction, reference, task_type)
        metrics.append(metric)
        example['prediction'] = prediction
        example['metrics'] = metric

    # average the metrics
    zeroscrolls_metrics = {}
    for metric in metrics:
        for key, value in metric.items():
            if key not in zeroscrolls_metrics:
                zeroscrolls_metrics[key] = []
            zeroscrolls_metrics[key].append(value)
    for key, value in zeroscrolls_metrics.items():
        zeroscrolls_metrics[key] = np.mean(value)
    
    # Update vLLM results with ZeroSCROLLS metrics
    vllm_results['metrics'].update(zeroscrolls_metrics)
    vllm_results['metrics']['task_type'] = task_type
    vllm_results['metrics']['dataset_name'] = dataset_name
    
    # Save final results
    if results_file:
        with open(results_file, 'w') as f:
            json.dump({
                'metrics': vllm_results['metrics'],
                'examples': vllm_results['examples'],
                'dataset_name': dataset_name,
                'task_type': task_type
            }, f, indent=2)
    
    return vllm_results


def _generate_and_evaluate_olmo_bugs(
    model,  # TTTLanguageModel
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    dataset_name: str = "olmo_bugs_5_try",
    checkpoint_path: str = None,
    use_vllm_for_eval: bool = False,
) -> Dict[str, Any]:
    """
    Generate and evaluate for OLMo Bugs datasets with detailed metrics.
    
    Args:
        model: The language model 
        eval_dataset: Dataset containing evaluation examples
        eval_config: Evaluation configuration
        max_length: Maximum sequence length for tokenization
        results_file: Optional file to save results
        silent: If True, don't show progress bar or print messages
        num_samples: Number of samples to evaluate
        dataset_name: Name of the OLMo bugs dataset
        checkpoint_path: Path to saved model checkpoint for vLLM
        use_vllm_for_eval: If True, use vLLM for generation
    
    Returns:
        Dictionary containing metrics and example results
    """
    # Use vLLM for evaluation if available and requested
    if use_vllm_for_eval and ENHANCED_EVAL_AVAILABLE:
        if checkpoint_path:
            if not silent:
                print(f"🚀 Using vLLM with OLMo Bugs evaluation from checkpoint: {checkpoint_path}")
            model_path = checkpoint_path
        else:
            if not silent:
                print(f"🚀 Using vLLM with OLMo Bugs evaluation for model: {model.model_name}")
            model_path = model.model_name
        
        return _evaluate_olmo_bugs_vllm(
            model_path, eval_dataset, eval_config, max_length, results_file,
            silent, num_samples, dataset_name
        )
    
    # Use HuggingFace with OLMo Bugs evaluation
    if not silent:
        print(f"🧮 Using HuggingFace with OLMo Bugs evaluation for {dataset_name}")
    
    return _evaluate_olmo_bugs_hf(
        model, eval_dataset, eval_config, max_length, results_file,
        silent, num_samples, dataset_name
    )


def _evaluate_olmo_bugs_hf(
    model,  # TTTLanguageModel
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    dataset_name: str = "olmo_bugs_5_try",
) -> Dict[str, Any]:
    """
    Evaluate OLMo Bugs using HuggingFace model.
    """
    from ..evaluation.enhanced_eval import compute_olmo_bugs_metrics
    import numpy as np
    
    # Track metrics for each problem
    predictions = []
    references = []
    examples = []
    level_metrics = {}
    
    # Detailed OLMo bugs metrics
    location_correct_list = []
    fix_correct_list = []
    overall_correct_list = []
    
    # Limit number of samples
    eval_count = min(num_samples, len(eval_dataset)) if num_samples else len(eval_dataset)
    
    for i in tqdm(range(eval_count), desc="Evaluating OLMo Bugs", disable=silent):
        try:
            batch = eval_dataset.collate_fn([eval_dataset[i]])
            input_ids = batch['input_ids']
            attention_mask = batch['attention_mask']
            
            # Generate prediction
            batch_predictions = generate_single_sample_batch(
                model, input_ids, attention_mask, eval_config, silent
            )
            
            # Get problem data
            if i < len(eval_dataset.problems):
                problem = eval_dataset.problems[i]
            else:
                problem = {}
            
            # Decode the input prompt
            input_prompt = model.tokenizer.decode(
                input_ids[0], 
                skip_special_tokens=True
            )
            
            question = batch['raw_questions'][0]
            solution = batch['raw_solutions'][0]
            answer = batch['raw_answers'][0]
            prediction = batch_predictions[0]
            
            # Remove input prompt from prediction
            if prediction.startswith(input_prompt):
                prediction = prediction[len(input_prompt):]
            
            # Clean prediction and compute detailed metrics
            full_response = prediction.strip()
            olmo_metrics = compute_olmo_bugs_metrics(full_response, answer if answer else solution)
            
            # Track detailed metrics
            location_correct = olmo_metrics['location_correct']
            fix_correct = olmo_metrics['fix_correct']
            overall_correct = olmo_metrics['overall_correct']
            
            location_correct_list.append(location_correct)
            fix_correct_list.append(fix_correct)
            overall_correct_list.append(overall_correct)
            
            # Store for inspection
            level = problem.get('level', 'unknown')
            if level not in level_metrics:
                level_metrics[level] = {'correct': 0, 'total': 0}
            level_metrics[level]['total'] += 1
            if overall_correct:
                level_metrics[level]['correct'] += 1
            
            # Store example for inspection
            examples.append({
                'input_prompt': input_prompt,
                'question': question,
                'solution': solution,
                'answer': answer,
                'prediction': full_response,
                'location_correct': location_correct,
                'fix_correct': fix_correct,
                'overall_correct': overall_correct,
                'correct': overall_correct,
                'level': level,
                'extracted_json': olmo_metrics.get('extracted_json', {}),
                'pred_location': olmo_metrics.get('pred_location', ''),
                'ref_location': olmo_metrics.get('ref_location', ''),
                'pred_fix': olmo_metrics.get('pred_fix', ''),
                'ref_fix': olmo_metrics.get('ref_fix', '')
            })
            
        except Exception as e:
            if not silent:
                print(f"Error processing example {i}: {e}")
            location_correct_list.append(False)
            fix_correct_list.append(False)
            overall_correct_list.append(False)
    
    # Compute aggregate metrics 
    metrics = {
        'answer_accuracy_mean': np.mean(overall_correct_list),
        'answer_accuracy_std': np.std(overall_correct_list),
        'location_accuracy_mean': np.mean(location_correct_list),
        'location_accuracy_std': np.std(location_correct_list),
        'fix_accuracy_mean': np.mean(fix_correct_list),
        'fix_accuracy_std': np.std(fix_correct_list),
        'overall_accuracy_mean': np.mean(overall_correct_list),
        'overall_accuracy_std': np.std(overall_correct_list),
        'total_examples': len(overall_correct_list),
        'total_location_correct': sum(location_correct_list),
        'total_fix_correct': sum(fix_correct_list),
        'total_overall_correct': sum(overall_correct_list),
        'dataset_name': dataset_name,
    }
    
    # Add per-level metrics
    for level, level_data in level_metrics.items():
        level_accuracy = level_data['correct'] / level_data['total'] if level_data['total'] > 0 else 0.0
        metrics[f'accuracy_level_{level}'] = level_accuracy
        metrics[f'total_level_{level}'] = level_data['total']
    
    # Print results
    if not silent:
        print(f"\n📊 OLMo Bugs HF Evaluation Results:")
        print(f"  Overall Accuracy: {metrics['overall_accuracy_mean']:.3f} ± {metrics['overall_accuracy_std']:.3f}")
        print(f"  Location Accuracy: {metrics['location_accuracy_mean']:.3f} ± {metrics['location_accuracy_std']:.3f}")
        print(f"  Fix Accuracy: {metrics['fix_accuracy_mean']:.3f} ± {metrics['fix_accuracy_std']:.3f}")
        print(f"  Total Examples: {metrics['total_examples']}")
        
        if level_metrics:
            print("\n  Per-Level Results:")
            for level in sorted(level_metrics.keys()):
                level_data = level_metrics[level]
                level_accuracy = level_data['correct'] / level_data['total']
                print(f"    Level {level}: {level_data['correct']}/{level_data['total']} = {level_accuracy:.3f}")
    
    # Save results
    if results_file:
        with open(results_file, 'w') as f:
            json.dump({
                'metrics': metrics,
                'examples': examples,
                'level_breakdown': level_metrics,
                'dataset_name': dataset_name
            }, f, indent=2)
    
    return {
        'metrics': metrics,
        'examples': examples,
        'level_breakdown': level_metrics
    }


def _evaluate_olmo_bugs_vllm(
    model_path: str,
    eval_dataset: LoadDataset,
    eval_config: Dict[str, Any],
    max_length: int,
    results_file: Path = None,
    silent: bool = False,
    num_samples: Optional[int] = None,
    dataset_name: str = "olmo_bugs_5_try",
) -> Dict[str, Any]:
    """
    Evaluate OLMo Bugs using vLLM for faster generation.
    """
    # Generate predictions using vLLM
    vllm_results = evaluate_with_vllm(
        model_path=model_path,
        eval_dataset=eval_dataset,
        eval_config=eval_config,
        results_file=None,  # Don't save vLLM results yet
        silent=silent,
        num_samples=num_samples,
        max_length=max_length
    )
    
    # Evaluate using OLMo Bugs metrics
    if not silent:
        print(f"🐛 Evaluating {len(vllm_results['examples'])} predictions with OLMo Bugs metrics...")

    from ..evaluation.enhanced_eval import compute_olmo_bugs_metrics
    import numpy as np
    
    # Extract per example metrics
    location_correct_list = []
    fix_correct_list = []
    overall_correct_list = []
    
    for example in vllm_results['examples']:
        # Get full model response (reasoning + answer)
        reasoning = example.get('reasoning', '')
        prediction = example.get('post-reasoning', '')
        full_response = f"{reasoning}\n\n{prediction}".strip() if reasoning else prediction
        
        reference = example.get('answer', example.get('solution', ''))
        olmo_metrics = compute_olmo_bugs_metrics(full_response, reference)
        
        # Track detailed metrics
        location_correct = olmo_metrics['location_correct']
        fix_correct = olmo_metrics['fix_correct']
        overall_correct = olmo_metrics['overall_correct']
        
        location_correct_list.append(location_correct)
        fix_correct_list.append(fix_correct)
        overall_correct_list.append(overall_correct)
        
        # Update example with OLMo bugs specific fields
        example.update({
            'location_correct': location_correct,
            'fix_correct': fix_correct,
            'overall_correct': overall_correct,
            'extracted_json': olmo_metrics.get('extracted_json', {}),
            'pred_location': olmo_metrics.get('pred_location', ''),
            'ref_location': olmo_metrics.get('ref_location', ''),
            'pred_fix': olmo_metrics.get('pred_fix', ''),
            'ref_fix': olmo_metrics.get('ref_fix', ''),
            'correct': overall_correct  # Override the basic correct field
        })

    # Add OLMo bugs specific metrics to vLLM results
    olmo_bugs_metrics = {
        'location_accuracy_mean': np.mean(location_correct_list),
        'location_accuracy_std': np.std(location_correct_list),
        'fix_accuracy_mean': np.mean(fix_correct_list),
        'fix_accuracy_std': np.std(fix_correct_list),
        'overall_accuracy_mean': np.mean(overall_correct_list),
        'overall_accuracy_std': np.std(overall_correct_list),
        'total_location_correct': sum(location_correct_list),
        'total_fix_correct': sum(fix_correct_list),
        'total_overall_correct': sum(overall_correct_list),
        'dataset_name': dataset_name,
    }
    
    # Update vLLM results with OLMo Bugs metrics (override basic accuracy with overall accuracy)
    vllm_results['metrics'].update(olmo_bugs_metrics)
    vllm_results['metrics']['answer_accuracy_mean'] = np.mean(overall_correct_list)
    vllm_results['metrics']['answer_accuracy_std'] = np.std(overall_correct_list)
    
    # Print detailed results
    if not silent:
        print(f"\n📊 OLMo Bugs vLLM Evaluation Results:")
        print(f"  Overall Accuracy: {olmo_bugs_metrics['overall_accuracy_mean']:.3f} ± {olmo_bugs_metrics['overall_accuracy_std']:.3f}")
        print(f"  Location Accuracy: {olmo_bugs_metrics['location_accuracy_mean']:.3f} ± {olmo_bugs_metrics['location_accuracy_std']:.3f}")
        print(f"  Fix Accuracy: {olmo_bugs_metrics['fix_accuracy_mean']:.3f} ± {olmo_bugs_metrics['fix_accuracy_std']:.3f}")
        print(f"  Total Examples: {vllm_results['metrics']['total_examples']}")
    
    # Save final results
    if results_file:
        with open(results_file, 'w') as f:
            json.dump({
                'metrics': vllm_results['metrics'],
                'examples': vllm_results['examples'],
                'level_breakdown': vllm_results.get('level_breakdown', {}),
                'dataset_name': dataset_name
            }, f, indent=2)
    
    return vllm_results


def _extract_multiple_choice_answer(prediction: str) -> str:
    """Extract multiple choice answer (A, B, C, D) from model prediction."""
    
    prediction = prediction.strip()
    
    # Common patterns for multiple choice answers
    mc_patterns = [
        # Direct letter answers: "A", "(A)", "A.", "A)", "[A]"
        r'^[(\[]?([ABCD])[)\].]?\s*$',
        # Answer with explanation: "The answer is A" or "Final answer: B"
        r'(?:answer\s*(?:is|:)\s*[(\[]?([ABCD])[)\].]?)',
        # Choice patterns: "Choice A", "Option B"
        r'(?:choice|option)\s*[(\[]?([ABCD])[)\].]?',
        # Boxed answers: \boxed{A}
        r'\\boxed\s*\{\s*([ABCD])\s*\}',
        # Answer at end of sentence: "...therefore A"
        r'(?:therefore|thus|so|hence)[,\s]*[(\[]?([ABCD])[)\].]?\s*[.\s]*$',
        # Letter followed by description: "A: Description" or "A. Description"
        r'^[(\[]?([ABCD])[)\].:].*',
        # Multiple choice in parentheses or brackets anywhere in text
        r'[(\[]([ABCD])[)\]]',
        # Single letter at the end
        r'[^A-Za-z]([ABCD])(?:\s*[.)]?)?\s*$',
    ]
    
    # Try each pattern
    for pattern in mc_patterns:
        matches = re.findall(pattern, prediction, re.IGNORECASE | re.MULTILINE)
        if matches:
            # Take the last match (most likely to be the final answer)
            return matches[-1].upper()
    
    # Look for choice text matching
    # If no letter pattern found, check if the prediction contains choice descriptions
    choice_keywords = {
        'A': ['choice a', 'option a', 'first option', 'first choice'],
        'B': ['choice b', 'option b', 'second option', 'second choice'], 
        'C': ['choice c', 'option c', 'third option', 'third choice'],
        'D': ['choice d', 'option d', 'fourth option', 'fourth choice', 'last option', 'last choice']
    }
    
    prediction_lower = prediction.lower()
    for letter, keywords in choice_keywords.items():
        for keyword in keywords:
            if keyword in prediction_lower:
                return letter
    
    # If still no match, check for single letter anywhere in the prediction
    letters_found = re.findall(r'\b([ABCD])\b', prediction.upper())
    if letters_found:
        return letters_found[-1]  # Return the last occurrence
    
    # Return the first character if it's A, B, C, or D
    if prediction and prediction[0].upper() in 'ABCD':
        return prediction[0].upper()
    
    # Fallback: return original prediction
    return prediction.strip()


def _clean_zeroscrolls_prediction(prediction: str, task_type: str) -> str:
    """Clean and format prediction for ZeroSCROLLS and LongBench-v2 evaluation."""
    # Remove common prefixes
    prediction = prediction.strip()
    
    # Remove "Solution:" prefix if present
    if prediction.startswith("Solution:"):
        prediction = prediction[9:].strip()
    
    # Remove "Answer:" prefix if present
    if prediction.startswith("Answer:"):
        prediction = prediction[7:].strip()
    
    # For multiple choice QA, extract the choice letter
    if task_type == "mc_qa":
        return _extract_multiple_choice_answer(prediction)
    
    # For summarization tasks, keep the entire response
    if task_type == "summarization" or task_type == "qb_summarization":
        return prediction
    
    # For QA tasks, try to extract the final answer
    # Look for boxed answers first
    prediction_lines = prediction.split('\n')
    first_line = prediction_lines[0].strip()
    
    boxed_pattern = r'\\boxed\{([^}]+)\}'
    boxed_match = re.search(boxed_pattern, prediction)
    if boxed_match:
        return boxed_match.group(1).strip()
    
    # Look for final answer patterns
    answer_patterns = [
        r'(?:the answer is|final answer is|answer:|final answer:)\s*([^\n\.]+)',
        r'(?:therefore|thus|so),?\s*([^\n\.]+)',
    ]
    
    for pattern in answer_patterns:
        match = re.search(pattern, prediction, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    
    # For short responses, return the first line
    if len(first_line) < 50:
        return first_line
    
    return prediction


def _compute_single_example_metrics(
    prediction: str, 
    reference: str, 
    task_type: str
) -> Dict[str, float]:
    """Compute metrics for a single example."""
    if task_type == "summarization" or task_type == "qb_summarization":
        return _compute_rouge_score(prediction, reference)
    elif task_type == "qa":
        return _compute_qa_metrics(prediction, reference)
    elif task_type == "mc_qa":
        return _compute_mc_qa_metrics(prediction, reference)
    elif task_type == "aggregation":
        return {"es": np.exp(-np.linalg.norm(np.array(prediction.split()) - np.array(reference.split())))}


def _compute_rouge_score(prediction: str, reference: str) -> Dict[str, float]:
    """Compute ROUGE scores for summarization evaluation."""
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    return {
        'rouge1_f1': scorer.score(reference, prediction)['rouge1'].fmeasure,
        'rouge2_f1': scorer.score(reference, prediction)['rouge2'].fmeasure,
        'rougeL_f1': scorer.score(reference, prediction)['rougeL'].fmeasure,
        'rouge': (scorer.score(reference, prediction)['rouge1'].fmeasure * scorer.score(reference, prediction)['rouge2'].fmeasure * scorer.score(reference, prediction)['rougeL'].fmeasure) ** (1/3),
    }


def _compute_mc_qa_metrics(prediction: str, reference: str) -> Dict[str, float]:
    """Compute metrics for multiple choice QA with robust answer matching."""
    # Normalize both prediction and reference
    pred_normalized = _normalize_mc_answer(prediction)
    ref_normalized = _normalize_mc_answer(reference)
    
    # Check for exact match
    exact_match = pred_normalized == ref_normalized
    
    accuracy = 1.0 if exact_match else 0.0
    
    return {
        'accuracy': accuracy,
        'exact_match': 1.0 if exact_match else 0.0
    }


def _normalize_mc_answer(answer: str) -> str:
    """Normalize multiple choice answer for comparison."""
    if not answer:
        return ""
    
    # Extract just the letter if it's a valid choice
    answer = answer.strip().upper()
    
    # If it's already a single letter A, B, C, or D, return it
    if len(answer) == 1 and answer in 'ABCD':
        return answer
    
    # Try to extract the choice letter
    extracted = _extract_multiple_choice_answer(answer)
    if len(extracted) == 1 and extracted in 'ABCD':
        return extracted
    
    # Return the original if no extraction worked
    return answer


def _compute_qa_metrics(prediction: str, reference: str) -> Dict[str, float]:
    """Compute Exact Match and F1 scores for QA evaluation."""
    def f1_score(reference: str, prediction: str) -> float:
        # F1 Score (token-level)
        pred_tokens = prediction.split()
        ref_tokens = reference.split()
        
        if not pred_tokens or not ref_tokens:
            return 0.0
        
        common_tokens = set(pred_tokens) & set(ref_tokens)
        
        if not common_tokens:
            return 0.0
        else:
            precision = len(common_tokens) / len(pred_tokens)
            recall = len(common_tokens) / len(ref_tokens)
            f1 = 2 * precision * recall / (precision + recall)
            return f1

    reference, prediction = _normalize_text(reference), _normalize_text(prediction)
    return {
        'exact_match': 1.0 if prediction == reference else 0.0,
        'f1_score': f1_score(reference, prediction),
    }

def _normalize_text(text: str) -> str:
    """Normalize text for evaluation."""
    import string
    
    # Convert to lowercase
    text = text.lower()
    
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    
    # Remove extra whitespace
    text = ' '.join(text.split())
    
    return text