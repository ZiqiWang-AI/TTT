"""
OLMo Bugs dataset loader for code bug detection experiments.

This dataset contains prompts with bug descriptions, code contexts, and task descriptions.
Each prompt contains a problem description and code context, where TTT should train only
on the code context. The expected output is a JSON with bug_location and bug_fix fields.
"""

import os
import logging
import json
import re
from typing import List, Dict, Optional
# [OFFLINE MODE] 改为使用本地加载
from datasets import load_from_disk
# from datasets import load_dataset  # 原始联网下载方式
import random

logger = logging.getLogger(__name__)

# ========== [OFFLINE MODE] 本地数据路径配置 ==========
LOCAL_OLMO_BUGS_PATH = "/fs/scratch/rb_bd_dlp_rng-dl01_cr_AIQ_employees/hkz1sgh/Self_distillation/dataset/OLMo-Bugs"
# =====================================================

class OLMoBugsDataLoader:
    """Data loader for OLMo Bugs datasets with different context sizes."""
    
    def __init__(self, context_size: Optional[int] = None):
        """Initialize the OLMo Bugs data loader.
        
        Args:
            context_size: Number of context lines (e.g., 20, 70, 120, etc.)
                         If None, uses the original sjelassi/olmo_bugs_5_try dataset
        """
        self.context_size = context_size
        self.dataset = None
        self.loaded = False
        
        # Determine dataset name based on context size
        if context_size is not None:
            self.dataset_name = f"olmo_bugs_context_{context_size}"
            # 原始: f"rachitbansal-harvard/olmo_bugs_context_{context_size}"
        else:
            self.dataset_name = "olmo_bugs_5_try"
            # 原始: "sjelassi/olmo_bugs_5_try"
    
    def load_data(
        self,
        split: str = 'train',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load OLMo Bugs problems for the specified split.
        
        Args:
            split: Dataset split (usually 'train' as this is a small dataset)
            num_problems: Maximum number of problems to load
            random_seed: Random seed for reproducible sampling
            
        Returns:
            List of problems formatted for the existing pipeline
        """
        # Set up random generator for reproducible sampling
        rng = random.Random(random_seed)
        
        logger.info(f"Loading OLMo Bugs dataset: split={split}")
        
        try:
            # Load dataset if not already loaded
            if not self.loaded:
                # [OFFLINE MODE] 从本地加载数据集
                local_path = os.path.join(LOCAL_OLMO_BUGS_PATH, self.dataset_name)
                if not os.path.exists(local_path):
                    raise FileNotFoundError(f"[OFFLINE MODE] 本地数据集不存在: {local_path}，请先下载数据集到本地")
                logger.info(f"[OFFLINE MODE] 从本地加载: {local_path}")
                self.dataset = load_from_disk(local_path)
                # 确保返回格式正确
                if not isinstance(self.dataset, dict) and not hasattr(self.dataset, 'keys'):
                    self.dataset = {'train': self.dataset}
                # 原始联网下载方式（已注释）:
                # self.dataset = load_dataset(self.dataset_name)
                self.loaded = True
            
            # Get the specified split
            if split not in self.dataset:
                logger.warning(f"Split '{split}' not found in olmo_bugs_5_try, using 'train'")
                split = 'train'
            
            split_data = self.dataset[split]
            
            # Process problems from this dataset
            problems = []
            for idx, item in enumerate(split_data):
                if num_problems and len(problems) >= num_problems:
                    break
                
                # Format problem for the existing pipeline
                problem = self._format_problem(item, idx)
                if problem:
                    problems.append(problem)
            
            # Sample if requested
            if num_problems and len(problems) > num_problems:
                problems = rng.sample(problems, num_problems)
            
            logger.info(f"Loaded {len(problems)} problems from {self.dataset_name}")
            return problems
            
        except Exception as e:
            logger.error(f"Error loading {self.dataset_name} dataset: {e}")
            raise
    
    def _format_problem(self, item: Dict, idx: int) -> Optional[Dict]:
        """
        Format an OLMo Bugs problem for the existing pipeline.
        
        Args:
            item: Raw dataset item with columns like 'prompt', 'bug_location', 'bug_fix', etc.
            idx: Index of the item for generating unique IDs
            
        Returns:
            Formatted problem dict or None if invalid
        """
        try:
            # Extract the main components
            prompt = item.get('prompt', '')
            bug_location = item.get('bug_location', '')  # Expected format: "filename:line_number"
            bug_fix = item.get('bug_fix', '')
            context_mode = item.get('context_mode', '')
            
            if not prompt:
                logger.warning(f"No prompt found in OLMo Bugs item {idx}: {item}")
                return None
            
            # Parse the prompt to extract question and code context
            question, code_context = self._parse_olmo_bugs_prompt(prompt)
            
            if not question or not code_context:
                logger.warning(f"Could not parse question/code context from prompt {idx}: {prompt[:200]}...")
                return None
            
            # Create the expected answer as JSON
            expected_answer = {
                "bug_location": bug_location,
                "bug_fix": bug_fix
            }
            expected_answer_json = json.dumps(expected_answer)
            
            return {
                'id': f"olmo_bugs_{idx}",
                'level': context_mode,
                'question': question,
                'solution': expected_answer_json,  # The expected JSON response
                'answer': expected_answer_json,    # Same as solution for consistency
                'context': code_context,           # Store the code context for TTT
                'dataset': self.dataset_name.split('/')[-1],  # Extract dataset name without org
                'bug_location': bug_location,      # For evaluation
                'bug_fix': bug_fix,               # For evaluation
                'raw_prompt': prompt,             # Keep original prompt for debugging
                'raw_item': item                  # Keep original item for debugging
            }
            
        except Exception as e:
            logger.warning(f"Error formatting OLMo Bugs problem {idx}: {e}")
            return None
    
    def _parse_olmo_bugs_prompt(self, prompt: str) -> tuple[str, str]:
        """
        Parse OLMo Bugs prompt to extract task description and code context.
        
        The prompt format is:
        1. Bug Description: [description of the bug]
        2. Code Context:\n\nFile: [filename]\nL[num]: [code line]...
        3. Task instruction: "Given the above code context, please identify..."
        
        Args:
            prompt: The full prompt text containing bug description, code context, and task
            
        Returns:
            Tuple of (question/task_description, code_context)
        """
        try:
            # Split prompt into sections based on the known format
            lines = prompt.split('\n')
            
            # Find key section markers
            bug_desc_start = -1
            code_context_start = -1
            task_instruction_start = -1
            
            for i, line in enumerate(lines):
                line_stripped = line.strip()
                
                # Look for "Bug Description:" at the start
                if line_stripped.startswith("Bug Description:"):
                    bug_desc_start = i
                
                # Look for "Code Context:" section
                elif line_stripped == "Code Context:":
                    code_context_start = i
                
                # Look for task instruction section (starts with "Given the above code context")
                elif line_stripped.startswith("Given the above code context"):
                    task_instruction_start = i
                    break
            
            # Extract sections based on markers
            bug_description = ""
            code_context = ""
            task_instruction = ""
            
            if bug_desc_start != -1:
                # Extract bug description
                if code_context_start != -1:
                    bug_desc_lines = lines[bug_desc_start:code_context_start]
                else:
                    bug_desc_lines = lines[bug_desc_start:bug_desc_start+3]  # Fallback
                
                bug_description = '\n'.join(bug_desc_lines).strip()
                # Remove "Bug Description:" prefix
                bug_description = re.sub(r'^Bug Description:\s*', '', bug_description)
            
            if code_context_start != -1:
                # Extract code context
                if task_instruction_start != -1:
                    code_context_lines = lines[code_context_start+1:task_instruction_start]
                else:
                    code_context_lines = lines[code_context_start+1:]
                
                code_context = '\n'.join(code_context_lines).strip()
                
                # Clean up code context - remove empty lines at start/end
                code_context = code_context.strip()
            
            if task_instruction_start != -1:
                # Extract task instruction
                task_instruction_lines = lines[task_instruction_start:]
                task_instruction = '\n'.join(task_instruction_lines).strip()
            
            # Construct the question from bug description and task instruction
            question_parts = []
            if bug_description:
                question_parts.append(f"Bug Description: {bug_description}")
            if task_instruction:
                question_parts.append(task_instruction)
            
            question = '\n\n'.join(question_parts).strip()
            
            # Fallback parsing if the structured approach didn't work
            if not code_context or not question:
                logger.warning("Structured parsing failed, using fallback method")
                
                # Look for "File:" markers to identify code sections
                file_pattern = r'^File:\s+[^\n]+$'
                line_pattern = r'^L\d+:'
                
                code_lines = []
                other_lines = []
                in_code_section = False
                
                for line in lines:
                    if re.match(file_pattern, line.strip()):
                        in_code_section = True
                        code_lines.append(line)
                    elif re.match(line_pattern, line.strip()):
                        in_code_section = True
                        code_lines.append(line)
                    elif in_code_section and line.strip() == "":
                        # Empty line might still be part of code context
                        code_lines.append(line)
                    elif in_code_section and any(keyword in line.lower() for keyword in 
                                               ['given the above', 'identify the bug', 'output your answer']):
                        # End of code section
                        in_code_section = False
                        other_lines.append(line)
                    elif in_code_section:
                        code_lines.append(line)
                    else:
                        other_lines.append(line)
                
                if code_lines:
                    code_context = '\n'.join(code_lines).strip()
                if other_lines:
                    question = '\n'.join(other_lines).strip()
            
            # Final validation and cleanup
            if not question:
                question = ("Given the above code context, please identify the exact location of the bug "
                          "and provide a fix. Output your answer in JSON format with 'bug_location' "
                          "and 'bug_fix' fields.")
            
            if not code_context:
                logger.warning("Could not extract code context, using entire prompt")
                code_context = prompt
                question = ("Analyze the following code for bugs. Identify the bug location (filename:line_number) "
                           "and provide a simple code modification to fix it. "
                           "Respond with JSON format: {\"bug_location\": \"filename:line_number\", \"bug_fix\": \"fix\"}.")
            
            # Remove excessive whitespace
            question = re.sub(r'\n\s*\n\s*\n+', '\n\n', question.strip())
            code_context = re.sub(r'\n\s*\n\s*\n+', '\n\n', code_context.strip())
            
            return question, code_context
            
        except Exception as e:
            logger.warning(f"Error parsing OLMo Bugs prompt: {e}")
            # Fallback: try to split on "Code Context:" if present
            if "Code Context:" in prompt:
                parts = prompt.split("Code Context:", 1)
                if len(parts) == 2:
                    before_code = parts[0].strip()
                    after_code = parts[1].strip()
                    
                    # Look for task instruction in after_code
                    if "Given the above code context" in after_code:
                        code_and_task = after_code.split("Given the above code context", 1)
                        code_context = code_and_task[0].strip()
                        task_part = "Given the above code context" + code_and_task[1]
                        question = f"{before_code}\n\n{task_part}".strip()
                    else:
                        code_context = after_code
                        question = before_code
                    
                    return question, code_context
            
            # Last resort: split roughly in half
            mid_point = len(prompt) // 2
            return prompt[:mid_point].strip(), prompt[mid_point:].strip()
    
    def get_available_splits(self) -> List[str]:
        """Get available dataset splits."""
        try:
            if not self.loaded:
                dataset = load_dataset(self.dataset_name)
                return list(dataset.keys())
            return list(self.dataset.keys())
        except Exception as e:
            logger.warning(f"Could not get splits for {self.dataset_name}: {e}")
            return ['train']  # Default assumption
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about the dataset."""
        try:
            if not self.loaded:
                dataset = load_dataset(self.dataset_name)
            else:
                dataset = self.dataset
            
            dataset_key = self.dataset_name.split('/')[-1]
            info = {
                dataset_key: {
                    'splits': list(dataset.keys()),
                    'features': list(dataset['train'].features.keys()) if 'train' in dataset else [],
                    'description': f'OLMo code bug detection dataset with bug location and fix annotations (context size: {self.context_size or "original"})',
                    'task_type': 'code_bug_detection',
                    'response_format': 'json',
                    'context_type': 'code',
                    'context_size': self.context_size
                }
            }
            
            # Add split sizes
            for split in dataset.keys():
                info[dataset_key][f'{split}_size'] = len(dataset[split])
            
            return info
            
        except Exception as e:
            dataset_key = self.dataset_name.split('/')[-1]
            logger.warning(f"Could not get info for {self.dataset_name}: {e}")
            return {
                dataset_key: {
                    'error': str(e),
                    'splits': ['train'],
                    'description': 'OLMo code bug detection dataset',
                    'context_size': self.context_size
                }
            }
    
    def get_bug_types(self) -> List[str]:
        """Get all unique bug types or patterns in the dataset (if available)."""
        try:
            if not self.loaded:
                self.dataset = load_dataset(self.dataset_name)
                self.loaded = True
            
            bug_locations = set()
            for item in self.dataset['train']:
                bug_location = item.get('bug_location', '')
                if bug_location and ':' in bug_location:
                    # Extract filename to see patterns
                    filename = bug_location.split(':')[0]
                    bug_locations.add(filename)
            
            return sorted(list(bug_locations))
            
        except Exception as e:
            logger.warning(f"Could not get bug types: {e}")
            return []


