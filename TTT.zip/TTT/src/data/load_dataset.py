"""
Dataset loading utilities for test-time training experiments.
"""

import os
# Disable tokenizer parallelism to avoid forking warnings
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from typing import List, Dict, Optional
import torch
from torch.utils.data import Dataset
from transformers import PreTrainedTokenizer
import random

class LoadDataset(Dataset):
    def __init__(
        self,
        model_name: str,
        problems: List[Dict],
        tokenizer: PreTrainedTokenizer,
        max_context_examples: int = 3,
        max_context_length: Optional[int] = 8192,
        max_question_length: Optional[int] = 1024,
        max_solution_length: Optional[int] = 1024,
        context_problems: Optional[List[Dict]] = None,
        mask_question_in_loss: bool = True,
        eval_mode: bool = False,
        reasoning_mode: bool = False,
        random_seed: int = 42,  # Add random seed for reproducible context selection
        # New parameters for long context training
        create_long_context_sequence: bool = False,
        target_sequence_length: int = 16384,
        # For evaluation with long context training
        training_sequence_tokens: Optional[torch.Tensor] = None,
        # New parameter for long context masking
        mask_question_in_long_sequence: bool = False,
    ):
        """
        Args:
            problems: List of problem dictionaries containing 'question' and 'solution'
            tokenizer: HuggingFace tokenizer
            max_context_length: Maximum length for context (None = use batch max)
            max_question_length: Maximum length for questions (None = use batch max)
            max_solution_length: Maximum length for solutions (None = use batch max)
            context_problems: Optional list of problems to use as context
            mask_question_in_loss: If True, only compute loss on solution tokens
            eval_mode: If True, only include question in input_ids (for evaluation)
            random_seed: Random seed for reproducible context example selection
            create_long_context_sequence: If True, concatenate multiple problems into single sequences
            target_sequence_length: Target length for concatenated sequences (e.g., 16384 tokens)
            training_sequence_tokens: Pre-computed training sequence tokens for evaluation
            mask_question_in_long_sequence: If True, only compute loss on solution tokens in long sequences
        """
        self.model_name = model_name
        self.problems = problems
        self.tokenizer = tokenizer
        self.max_context_examples = max_context_examples
        self.max_context_length = max_context_length
        self.max_question_length = max_question_length
        self.max_solution_length = max_solution_length
        self.context_problems = context_problems
        self.mask_question_in_loss = mask_question_in_loss
        self.eval_mode = eval_mode
        self.reasoning_mode = reasoning_mode
        self.random_seed = random_seed
        self.create_long_context_sequence = create_long_context_sequence
        self.target_sequence_length = target_sequence_length
        self.training_sequence_tokens = training_sequence_tokens
        self.mask_question_in_long_sequence = mask_question_in_long_sequence
        
        # Pre-compute context string and tokens for efficiency
        # Use training sequence tokens if provided (for evaluation), otherwise use regular context
        if self.training_sequence_tokens is not None and self.eval_mode:
            self.context_tokens = self.training_sequence_tokens
            self.context_str = self.tokenizer.decode(self.training_sequence_tokens, skip_special_tokens=True)
        else:
            self.context_str = self._create_context()
            self.context_tokens = None
            if self.context_str:
                self.context_tokens = self.tokenizer(
                    self.context_str,
                    add_special_tokens=False,
                    return_tensors="pt"
                ).input_ids.squeeze(0)
        
        # Pre-compute long context sequences if enabled
        if self.create_long_context_sequence and not self.eval_mode:
            self.long_sequences = self._create_long_context_sequences()
        else:
            self.long_sequences = None

    def __len__(self) -> int:
        if self.long_sequences is not None:
            # SIMPLIFIED: For long sequences, just return 1 since we train on the full sequence
            # No more cycling through different solution spans
            return 1 if len(self.long_sequences) > 0 else 0
        return len(self.problems)

    def _format_problem(self, problem: Dict) -> str:
        return f"Problem: {problem['question']}\nSolution: {problem['solution']}"

    def _create_context(self) -> str:
        if not self.context_problems or self.max_context_examples == 0:
            return ""
        
        # BUGFIX: Select only a small number of context examples instead of all training problems
        # Use fixed random seed for reproducible context selection
        rng = random.Random(self.random_seed)
        selected_problems = rng.sample(
            self.context_problems, 
            min(self.max_context_examples, len(self.context_problems))
        )
        
        context = "Consider the following context:\n\n"
        for i, prob in enumerate(selected_problems, 1):
            context += f"Example {i}:\n{self._format_problem(prob)}\n\n"
        
        context += "\n\nNow, let's solve the following problem:"
        return context.strip()

    def _create_minif2f_context(self, problem: Dict) -> str:
        """Create context string for miniF2F problems that have embedded context."""
        if 'context_problems' not in problem or not problem['context_problems']:
            return ""
        
        context_problems = problem['context_problems']
        if self.max_context_examples > 0:
            # Limit the number of context examples
            context_problems = context_problems[:self.max_context_examples]
        
        context = "Consider the following context:\n\n"
        context_setting = problem.get('context_setting', 'unknown')
        
        if context_setting == 'cross_language':
            context += "Here are solutions to the same problem in other formal languages:\n\n"
        elif context_setting == 'same_language':
            context += f"Here are other problems solved in {problem.get('target_language', 'the target language')}:\n\n"
        elif context_setting == 'unrelated':
            context += "Here are other problems solved in different formal languages:\n\n"
        
        for i, ctx_prob in enumerate(context_problems, 1):
            lang_info = f" ({ctx_prob.get('language', 'unknown')})" if ctx_prob.get('language') else ""
            context += f"Example {i}{lang_info}:\n{self._format_problem(ctx_prob)}\n\n"
        
        context += f"\nNow, solve the following problem in {problem.get('target_language', 'the target language')}:"
        return context.strip()

    def _create_zeroscrolls_context(self, problem: Dict) -> str:
        """Create context string for ZeroSCROLLS problems that have embedded context."""
        if 'context' not in problem or not problem['context']:
            return ""
        
        # For ZeroSCROLLS, the context is the long document/text that was parsed from input
        context_text = problem['context']
        context_text = context_text.replace('\n\nAnswer:', '')
        return context_text.strip()

    def _create_bank_transactions_context(self, problem: Dict) -> str:
        """Create context string for Bank Transactions problems that have embedded context."""
        if 'context' not in problem or not problem['context']:
            return ""
        
        # For Bank Transactions, the context is the transaction log that was parsed from prompt
        context_text = problem['context']
        return context_text.strip()

    def _create_olmo_bugs_context(self, problem: Dict) -> str:
        """Create context string for OLMo Bugs problems that have embedded code context."""
        if 'context' not in problem or not problem['context']:
            return ""
        
        # For OLMo Bugs, the context is the code context that was parsed from the original prompt
        context_text = problem['context']
        return context_text.strip()

    def _truncate_tokens(self, tokens: torch.Tensor, max_length: Optional[int]) -> torch.Tensor:
        """Truncate tokens to max_length if specified."""
        if max_length is None or len(tokens) <= max_length:
            return tokens
        return tokens[:max_length]

    def _format_problem_for_sequence(self, problem: Dict) -> tuple[str, str]:
        """Format problem into question and solution parts for sequence concatenation.
        
        Uses clean formatting:
        Problem: <question>
        Solution: <solution>
        """
        question_text = f"Problem: {problem['question']}\n"
        solution_text = f"Solution: {problem['solution']}\n"
        
        return question_text, solution_text

    def __getitem__(self, idx: int) -> Dict[str, any]:
        # Handle long context sequences
        if self.long_sequences is not None:
            return self._get_long_sequence_item(idx)
        
        # Regular single problem handling
        problem = self.problems[idx]
        
        # Check if this is a miniF2F problem with embedded context
        is_minif2f = 'context_problems' in problem and 'target_language' in problem
        
        # Check if this is a ZeroSCROLLS or LongBench-v2 problem with embedded context
        is_zeroscrolls = 'context' in problem and 'dataset' in problem and problem.get('dataset') in [
            'gov_report', 'summ_screen_fd', 'qmsum', 'squality', 'qasper', 
            'narrative_qa', 'quality', 'musique', 'space_digest', 'book_sum_sort'
        ]
        is_longbench_v2 = 'context' in problem and 'dataset' in problem and problem.get('dataset', '').startswith('longbench_v2_')
        
        # Check if this is a Bank Transactions problem with embedded context
        is_bank_transactions = 'context' in problem and 'dataset' in problem and problem.get('dataset') == 'bank_transactions_easy'
        
        # Check if this is an OLMo Bugs problem with embedded code context
        is_olmo_bugs = 'context' in problem and 'dataset' in problem and problem.get('dataset', '').startswith('olmo_bugs')
        
        # For evaluation with training sequence context, use clean formatting
        if self.eval_mode and self.training_sequence_tokens is not None:
            question_text = "Now, solve the following problem and put your final answer within \\boxed{}" + f".\nProblem: {problem['question']}\n"
            solution_text = f"Solution: {problem['solution']}\n"
        else:
            question_text, solution_text = self._format_problem_for_sequence(problem)
        
        # Tokenize components separately
        context_tokens = torch.tensor([], dtype=torch.long)
        context_text = ""
        
        # Handle context based on data type
        if is_minif2f and not self.eval_mode:
            # For miniF2F training, use embedded context
            context_text = self._create_minif2f_context(problem)
            if context_text:
                context_tokens = self.tokenizer(
                    context_text,
                    add_special_tokens=False,
                    return_tensors="pt"
                ).input_ids.squeeze(0)
                context_tokens = self._truncate_tokens(context_tokens, self.max_context_length)
        elif is_minif2f and self.eval_mode:
            # For miniF2F evaluation, use embedded context if no training sequence provided
            if self.training_sequence_tokens is not None:
                context_tokens = self._truncate_tokens(self.training_sequence_tokens, self.max_context_length)
                context_text = ""
            else:
                context_text = self._create_minif2f_context(problem)
                if context_text:
                    context_tokens = self.tokenizer(
                        context_text,
                        add_special_tokens=False,
                        return_tensors="pt"
                    ).input_ids.squeeze(0)
                    context_tokens = self._truncate_tokens(context_tokens, self.max_context_length)
        elif (is_zeroscrolls or is_longbench_v2 or is_bank_transactions or is_olmo_bugs) and not self.eval_mode:
            # For ZeroSCROLLS/LongBench-v2/Bank Transactions/OLMo Bugs training, use embedded context
            if is_bank_transactions:
                context_text = self._create_bank_transactions_context(problem)
            elif is_olmo_bugs:
                context_text = self._create_olmo_bugs_context(problem)
            else:
                context_text = self._create_zeroscrolls_context(problem)
            if context_text:
                context_tokens = self.tokenizer(
                    context_text,
                    add_special_tokens=False,
                    return_tensors="pt"
                ).input_ids.squeeze(0)
                context_tokens = self._truncate_tokens(context_tokens, self.max_context_length)
        elif (is_zeroscrolls or is_longbench_v2 or is_bank_transactions or is_olmo_bugs) and self.eval_mode:
            # For ZeroSCROLLS/LongBench-v2/Bank Transactions/OLMo Bugs evaluation, use embedded context if no training sequence provided
            if self.training_sequence_tokens is not None:
                context_tokens = self._truncate_tokens(self.training_sequence_tokens, self.max_context_length)
                context_text = ""
            else:
                if is_bank_transactions:
                    context_text = self._create_bank_transactions_context(problem)
                elif is_olmo_bugs:
                    context_text = self._create_olmo_bugs_context(problem)
                else:
                    context_text = self._create_zeroscrolls_context(problem)
                if context_text:
                    context_tokens = self.tokenizer(
                        context_text,
                        add_special_tokens=False,
                        return_tensors="pt"
                    ).input_ids.squeeze(0)
                    context_tokens = self._truncate_tokens(context_tokens, self.max_context_length)
        else:
            # Regular AIME/MATH500 handling
            if self.context_tokens is not None:
                # For training sequence tokens, use them directly without additional formatting
                if self.training_sequence_tokens is not None and self.eval_mode:
                    context_tokens = self._truncate_tokens(self.context_tokens, self.max_context_length)
                    context_text = ""  # Don't add extra formatting for training sequences
                else:
                    context_tokens = self._truncate_tokens(self.context_tokens, self.max_context_length)
                    if "Qwen" in self.model_name:
                        # context_text = f"<|im_start|>system\n{self.tokenizer.decode(context_tokens)}\n<|im_end|>\n"
                        context_text = f"{self.tokenizer.decode(context_tokens)}\n"
                    else:
                        context_text = f"{self.tokenizer.decode(context_tokens)}\n"
        
        # Tokenize question 
        question_tokens = torch.tensor([], dtype=torch.long)
        if not (is_zeroscrolls or is_longbench_v2 or is_bank_transactions or is_olmo_bugs):
            # For regular datasets, format as "Question: ..."
            question_text = f"Question: {problem['question']}\n"
            question_tokens = self.tokenizer(
                question_text,
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0)
            question_tokens = self._truncate_tokens(question_tokens, self.max_question_length)
            question_text = self.tokenizer.decode(question_tokens)
        else:
            # For ZeroSCROLLS/LongBench-v2/Bank Transactions/OLMo Bugs, the question is the instruction part
            question_text = f"{problem['question']}\n"
            question_tokens = self.tokenizer(
                question_text,
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0)
            question_tokens = self._truncate_tokens(question_tokens, self.max_question_length)
            question_text = self.tokenizer.decode(question_tokens)
        
        if self.eval_mode:
            # For evaluation, only include question (no solution)
            # Use clean "Solution:" prefix for consistent formatting
            solution_prefix = self.tokenizer(
                "\n\n",
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0)
            
            # Combine tokens: [context] + [question] + [solution_prefix]
            all_tokens = []
            if len(context_tokens) > 0:
                all_tokens.append(context_tokens)
                # For training sequence context, don't add separator (it's already formatted)
                # For regular context, add separator between context and question  
                if self.training_sequence_tokens is None:
                    separator = self.tokenizer("\n\n", add_special_tokens=False, return_tensors="pt").input_ids.squeeze(0)
                    all_tokens.append(separator)
            all_tokens.extend([question_tokens, solution_prefix])
            
            combined_tokens = torch.cat(all_tokens)
            solution_start_token = len(combined_tokens) - len(solution_prefix)
            
            # Debug: print context usage for long context mode
            if self.training_sequence_tokens is not None and len(context_tokens) > 0:
                print(f"Evaluation using clean formatted training context: {len(context_tokens)} tokens + question: {len(question_tokens)} tokens")
            elif is_minif2f and len(context_tokens) > 0:
                print(f"MiniF2F evaluation using {problem.get('context_setting', 'unknown')} context: {len(context_tokens)} tokens + question: {len(question_tokens)} tokens")
            elif is_zeroscrolls and len(context_tokens) > 0:
                print(f"ZeroSCROLLS evaluation using {problem.get('dataset', 'unknown')} context: {len(context_tokens)} tokens + question: {len(question_tokens)} tokens")
            elif is_longbench_v2 and len(context_tokens) > 0:
                print(f"LongBench-v2 evaluation using {problem.get('dataset', 'unknown')} context: {len(context_tokens)} tokens + question: {len(question_tokens)} tokens")
            elif is_bank_transactions and len(context_tokens) > 0:
                print(f"Bank Transactions evaluation using context: {len(context_tokens)} tokens + question: {len(question_tokens)} tokens")
        else:
            # For training, include both question and solution
            solution_tokens = self.tokenizer(
                solution_text,
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0)
            solution_tokens = self._truncate_tokens(solution_tokens, self.max_solution_length)
            solution_text = self.tokenizer.decode(solution_tokens)
            
            # Combine tokens: [context] + [question] + [newline] + [solution]
            all_tokens = []
            solution_start_token = 0
            
            if len(context_tokens) > 0:
                all_tokens.append(context_tokens)
                solution_start_token += len(context_tokens)
                # Add separator between context and question
                separator = self.tokenizer("\n\n", add_special_tokens=False, return_tensors="pt").input_ids.squeeze(0)
                all_tokens.append(separator)
                solution_start_token += len(separator)
            
            all_tokens.append(question_tokens)
            solution_start_token += len(question_tokens)
            
            # Add newline before solution
            newline = self.tokenizer("\n", add_special_tokens=False, return_tensors="pt").input_ids.squeeze(0)
            all_tokens.append(newline)
            solution_start_token += len(newline)
            
            all_tokens.append(solution_tokens)
            
            combined_tokens = torch.cat(all_tokens)
        
        return {
            'input_ids': combined_tokens,
            'solution_start_token': solution_start_token,
            'raw_context': context_text,
            'raw_question': question_text,
            'raw_solution': solution_text,
            'raw_answer': problem.get('answer', ''),
            'mask_question_in_loss': self.mask_question_in_loss and not self.eval_mode,
            'context_length': len(context_tokens),
            'question_length': len(question_tokens),
            'solution_length': len(solution_tokens) if not self.eval_mode else 0,
            'uses_training_sequence': self.training_sequence_tokens is not None and self.eval_mode,
            'is_minif2f': is_minif2f,
            'minif2f_setting': problem.get('context_setting', '') if is_minif2f else '',
            'target_language': problem.get('target_language', '') if is_minif2f else '',
            'is_zeroscrolls': is_zeroscrolls,
            'zeroscrolls_dataset': problem.get('dataset', '') if is_zeroscrolls else '',
            'is_longbench_v2': is_longbench_v2,
            'longbench_v2_dataset': problem.get('dataset', '') if is_longbench_v2 else '',
            'is_bank_transactions': is_bank_transactions,
            'bank_transactions_bug_type': problem.get('bug_type', '') if is_bank_transactions else '',
        }

    def _get_long_sequence_item(self, idx: int) -> Dict[str, any]:
        """Get item from pre-computed long context sequences.
        
        Now supports selective masking: can train on full sequence OR just solution parts.
        """
        sequence_data = self.long_sequences[0]  # We only have one long sequence
        input_ids = sequence_data['input_ids']
        solution_ranges = sequence_data['solution_ranges']
        problems_info = sequence_data['problems_info']
        
        return {
            'input_ids': input_ids,
            'raw_context': "",  # No additional context in long sequences
            'raw_question': "Full long context sequence",  # Simplified
            'raw_solution': "Multiple solutions in sequence",  # Simplified 
            'raw_answer': "Multiple answers",  # Simplified
            'mask_question_in_loss': self.mask_question_in_long_sequence,  # Use parameter to control masking
            'context_length': len(input_ids),
            'question_length': 0,  # Not applicable for full sequence
            'solution_length': len(input_ids),  # Entire sequence
            'is_long_sequence': True,  # Flag to identify long sequences
            'num_problems': len(problems_info),
            'solution_ranges': solution_ranges,  # Return solution ranges for masking
        }

    def _create_long_context_sequences(self) -> List[Dict]:
        """Create a single long context sequence by concatenating problems up to target_sequence_length.
        
        Format:
        Consider the following context:
        
        Example 1:
        Problem: <problem>
        Solution: <solution>
        
        Example 2:
        Problem: <problem>
        Solution: <solution>
        """
        if self.max_context_examples == 0:
            return []

        if not self.problems:
            return []
        
        # Shuffle problems for random selection
        rng = random.Random(self.random_seed)
        shuffled_problems = self.problems.copy()
        rng.shuffle(shuffled_problems)
        
        sequence_tokens = []
        solution_ranges = []  # List of (start, end) tuples for each solution
        problems_info = []  # Keep track of original problems
        current_length = 0
        
        # Add header
        header_text = "Consider the following context:\n\n"
        header_tokens = self.tokenizer(
            header_text,
            add_special_tokens=False,
            return_tensors="pt"
        ).input_ids.squeeze(0)
        sequence_tokens.append(header_tokens)
        current_length += len(header_tokens)
        
        # Keep adding problems until we reach target_sequence_length
        problem_count = 0
        for problem in shuffled_problems:
            # Stop if we've reached max_context_examples (if specified)
            # Handle the case where max_context_examples=0 (means no context examples)
            if self.max_context_examples == 0:
                break
            if self.max_context_examples > 0 and problem_count >= self.max_context_examples:
                break
            
            question_text, solution_text = self._format_problem_for_sequence(problem)
            
            # Format as "Example N:"
            example_header = f"Example {problem_count + 1}:\n"
            example_header_tokens = self.tokenizer(
                example_header,
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0)
            
            # Tokenize question and solution
            question_tokens = self.tokenizer(
                question_text,
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0)
            
            solution_tokens = self.tokenizer(
                solution_text,
                add_special_tokens=False,
                return_tensors="pt"
            ).input_ids.squeeze(0)
            
            # Calculate tokens needed for this problem
            tokens_for_this_problem = len(example_header_tokens) + len(question_tokens) + len(solution_tokens)
            
            # Add separator tokens if not the first problem
            separator_tokens_len = 0
            if problem_count > 0:
                separator_tokens_len = len(self.tokenizer(
                    "\n",
                    add_special_tokens=False,
                    return_tensors="pt"
                ).input_ids.squeeze(0))
                tokens_for_this_problem += separator_tokens_len
            
            # Check if adding this problem would exceed target_sequence_length
            if current_length + tokens_for_this_problem > self.target_sequence_length:
                print(f"Stopping at {problem_count} problems to stay within target length of {self.target_sequence_length} tokens")
                break
            
            # Add separator after previous example (if this isn't the first)
            if problem_count > 0:
                separator_tokens = self.tokenizer(
                    "\n",
                    add_special_tokens=False,
                    return_tensors="pt"
                ).input_ids.squeeze(0)
                sequence_tokens.append(separator_tokens)
                current_length += len(separator_tokens)
            
            # Add example header
            sequence_tokens.append(example_header_tokens)
            current_length += len(example_header_tokens)
            
            # Add question tokens
            sequence_tokens.append(question_tokens)
            solution_start = current_length + len(question_tokens)
            current_length += len(question_tokens)
            
            # Add solution tokens
            sequence_tokens.append(solution_tokens)
            solution_end = current_length + len(solution_tokens)
            current_length += len(solution_tokens)
            
            # Record solution range
            solution_ranges.append((solution_start, solution_end))
            problems_info.append({
                'question': question_text,
                'solution': solution_text,
                'answer': problem.get('answer', ''),
                'original_problem': problem
            })
            
            problem_count += 1
        
        # Create single long sequence
        if sequence_tokens:
            combined_tokens = torch.cat(sequence_tokens)
            long_sequence = {
                'input_ids': combined_tokens,
                'solution_ranges': solution_ranges,
                'problems_info': problems_info,
                'sequence_length': len(combined_tokens)
            }
            
            print(f"Created 1 long context sequence: {len(combined_tokens)} tokens (target: {self.target_sequence_length}), {problem_count}problems")
            
            # Print the formatted sequence for verification
            formatted_text = self.tokenizer.decode(combined_tokens, skip_special_tokens=True)
            print("\n" + "="*80)
            print("LONG CONTEXT TRAINING SEQUENCE:")
            print("="*80)
            print(formatted_text)
            print("="*80)
            print(f"Actual length: {len(combined_tokens)} tokens (target: {self.target_sequence_length})")
            print(f"Length utilization: {len(combined_tokens)/self.target_sequence_length*100:.1f}%")
            print(f"Solution ranges: {solution_ranges}")
            print("="*80 + "\n")
            
            return [long_sequence]  # Return as list with single element
        
        return []

def collate_fn(batch: List[Dict], tokenizer: PreTrainedTokenizer, max_length: int = 4096) -> Dict[str, torch.Tensor]:
    """
    Custom collate function to handle variable-length sequences with proper padding.
    Now supports both regular sequences and long context sequences.
    
    Args:
        batch: List of examples from dataset
        tokenizer: Tokenizer to use
        max_length: Maximum sequence length (hard cap to prevent OOM)
    
    Returns:
        Batched and padded tensors
    """
    # Extract tokenized sequences
    input_ids_list = [item['input_ids'] for item in batch]
    
    # Find the maximum length in the batch, but cap it at max_length
    max_batch_length = max(len(seq) for seq in input_ids_list)
    target_length = min(max_batch_length, max_length)  # Actually enforce max_length cap
    
    # Warn if sequences are being truncated
    if max_batch_length > max_length:
        print(f"⚠️ Truncating sequences from {max_batch_length} to {max_length} tokens (max_length limit)")
    
    # Pad sequences to target length
    padded_input_ids = []
    attention_masks = []
    
    max_seq_len = min(max([len(seq) for seq in input_ids_list]), max_length)
    print(f"Max sequence length after truncation: {max_seq_len}")
    
    for i, seq in enumerate(input_ids_list):
        # Truncate if necessary to enforce max_length
        if len(seq) > target_length:
            # CRITICAL FIX: Smart truncation that preserves the question for long contexts
            item = batch[i]
            context_length = item.get('context_length', 0)
            question_length = item.get('question_length', 0)
            is_eval_mode = not item.get('mask_question_in_loss', True)  # eval mode when we don't mask question
            
            if is_eval_mode and context_length > 0 and question_length > 0:
                # For evaluation with long context, truncate the context but preserve the question
                # Calculate how much we need to cut from context
                total_non_context_length = len(seq) - context_length
                max_context_for_target = target_length - total_non_context_length
                
                if max_context_for_target > 0:
                    # Truncate context but keep question and formatting
                    truncated_context_length = min(context_length, max_context_for_target)
                    
                    # Reconstruct sequence: truncated_context + question + solution_prefix
                    seq = torch.cat([
                        seq[:truncated_context_length],  # Truncated context
                        seq[context_length:]  # Question + solution prefix (preserved)
                    ])
                    
                    if len(seq) > target_length:
                        seq = seq[:target_length]  # Final safety truncation
                    
                    if max_batch_length > max_length:
                        print(f"🧊 Smart truncation: context {context_length}→{truncated_context_length}, question preserved ({question_length} tokens)")
                else:
                    # If even the question is too long, do regular truncation
                    seq = seq[:target_length]
                    if max_batch_length > max_length:
                        print(f"⚠️ Question too long for target length, using regular truncation")
            else:
                # Regular truncation for training or short sequences
                seq = seq[:target_length]
        
        # Create attention mask (1 for real tokens, 0 for padding)
        attention_mask = torch.ones(len(seq), dtype=torch.long)
        
        # Pad sequence
        padding_length = min(target_length, max_seq_len) - len(seq)
        if padding_length > 0:
            padding = torch.full((padding_length,), tokenizer.pad_token_id, dtype=torch.long)
            seq = torch.cat([padding, seq])
            
            # Extend attention mask with zeros for padding
            padding_mask = torch.zeros(padding_length, dtype=torch.long)
            attention_mask = torch.cat([padding_mask, attention_mask])
        
        padded_input_ids.append(seq)
        attention_masks.append(attention_mask)
    
    # Stack into tensors
    input_ids = torch.stack(padded_input_ids)
    attention_mask = torch.stack(attention_masks)
    
    # For causal LM, labels are the same as input_ids
    # The model will internally shift them for next-token prediction
    labels = input_ids.clone()
    
    # Handle loss masking
    for i, item in enumerate(batch):
        if item.get('mask_question_in_loss', False):
            seq_len = (input_ids[i] != tokenizer.pad_token_id).sum().item()
            
            if item.get('is_long_sequence', False):
                # Long sequences: Apply selective masking based on solution ranges
                solution_ranges = item.get('solution_ranges', [])
                if solution_ranges:
                    # First, mask all tokens (set to -100)
                    labels[i] = torch.full_like(labels[i], -100)
                    
                    # Then, unmask only the solution tokens
                    padding_offset = len(input_ids[i]) - seq_len
                    for solution_start, solution_end in solution_ranges:
                        # Adjust for padding
                        adj_start = solution_start + padding_offset
                        adj_end = solution_end + padding_offset
                        
                        # Make sure indices are within bounds
                        adj_start = max(0, min(adj_start, len(input_ids[i]) - 1))
                        adj_end = max(0, min(adj_end, len(input_ids[i])))
                        
                        if adj_start < adj_end:
                            # Restore original token IDs for solution tokens
                            labels[i, adj_start:adj_end] = input_ids[i, adj_start:adj_end]
                    
                    print(f"Long sequence masking: Training on {len(solution_ranges)} solution segments out of {seq_len} total tokens")
                else:
                    # Fallback: Just mask padding tokens if no solution ranges
                    labels[i][input_ids[i] == tokenizer.pad_token_id] = -100
                    print("Warning: No solution ranges found for long sequence, training on full sequence")
            else:
                # Regular single problem handling (unchanged)
                solution_start_token = item.get('solution_start_token', 0)
                solution_start_token = min(solution_start_token, seq_len - 1)
                
                # Set labels to -100 for tokens before solution (question part)
                if solution_start_token > 0:
                    padding_offset = len(input_ids[i]) - seq_len
                    adj_start = solution_start_token + padding_offset
                    labels[i, :adj_start] = -100
    
    return {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'labels': labels,
        'raw_questions': [item['raw_question'] for item in batch],
        'raw_solutions': [item['raw_solution'] for item in batch],
        'raw_answers': [item['raw_answer'] for item in batch],
        'context_lengths': [item['context_length'] for item in batch],
        'question_lengths': [item['question_length'] for item in batch],
        'solution_lengths': [item['solution_length'] for item in batch],
        'is_long_sequences': [item.get('is_long_sequence', False) for item in batch],
        'num_problems': [item.get('num_problems', 1) for item in batch],
        # Removed target_solution_indices since we're not using them anymore
    }