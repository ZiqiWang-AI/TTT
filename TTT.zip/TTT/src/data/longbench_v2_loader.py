"""
LongBench-v2 dataset loader for long-context question answering experiments.

LongBench-v2 is a benchmark designed to assess the ability of LLMs to handle 
long-context problems requiring deep understanding and reasoning across real-world multitasks.
The benchmark consists of 503 challenging multiple-choice questions, with contexts ranging 
from 8k to 2M words, across six major task categories.
"""

import os
import logging
from typing import List, Dict, Optional
from datasets import load_from_disk
import random

logger = logging.getLogger(__name__)

# ========== 本地数据路径配置 ==========
LOCAL_LONGBENCH_V2_PATH = "/fs/scratch/rb_bd_dlp_rng-dl01_cr_AIQ_employees/hkz1sgh/Self_distillation/dataset/LongBench-v2"
# =====================================

def _is_main_process():
    """Check if this is the main process to avoid duplicate logging in multi-GPU setups."""
    local_rank = os.environ.get('LOCAL_RANK', '0')
    rank = os.environ.get('RANK', '0')
    return local_rank == '0' and rank == '0'

class LongBenchV2DataLoader:
    """Data loader for LongBench-v2 dataset."""
    
    # Available LongBench-v2 domains
    LONGBENCH_V2_DOMAINS = [
        "Single-Document QA", 
        "Multi-Document QA", 
        "Long In-context Learning", 
        "Long-dialogue History Understanding", 
        "Code Repository Understanding", 
        "Long Structured Data Understanding"
    ]
    
    def __init__(self):
        """Initialize the LongBench-v2 data loader."""
        self.data = {}
        self.loaded_datasets = {}
    
    def load_data(
        self,
        domains: List[str] = None,
        split: str = 'train',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load LongBench-v2 problems for specified domains.
        
        Args:
            domains: List of domain names to load (from LONGBENCH_V2_DOMAINS). If None, loads all domains.
            split: Dataset split ('train' - LongBench-v2 only has train split)
            num_problems: Maximum number of problems to load total
            random_seed: Random seed for reproducible sampling
            
        Returns:
            List of problems formatted for the existing pipeline
        """
        # If no domains specified, use all domains
        if domains is None:
            domains = self.LONGBENCH_V2_DOMAINS
        
        # Validate domain names
        invalid_domains = [domain for domain in domains if domain not in self.LONGBENCH_V2_DOMAINS]
        if invalid_domains:
            raise ValueError(f"Invalid domain names: {invalid_domains}. Available: {self.LONGBENCH_V2_DOMAINS}")
        
        # Set up random generator for reproducible sampling
        rng = random.Random(random_seed)
        
        all_problems = []
        
        try:
            # Load the main LongBench-v2 dataset
            if 'main' not in self.loaded_datasets:
                # Only log on main process to avoid duplicate logs in multi-GPU setup
                if _is_main_process():
                    logger.info("Loading LongBench-v2 main dataset...")
                
                # 仅从本地加载数据集
                if not os.path.exists(LOCAL_LONGBENCH_V2_PATH):
                    raise FileNotFoundError(f"本地数据集不存在: {LOCAL_LONGBENCH_V2_PATH}，请先下载数据集到本地")
                
                if _is_main_process():
                    logger.info(f"从本地加载数据集: {LOCAL_LONGBENCH_V2_PATH}")
                dataset = load_from_disk(LOCAL_LONGBENCH_V2_PATH)
                # load_from_disk 返回的可能是 Dataset 而不是 DatasetDict
                if not isinstance(dataset, dict) and not hasattr(dataset, 'keys'):
                    dataset = {'train': dataset}
                self.loaded_datasets['main'] = dataset
            else:
                dataset = self.loaded_datasets['main']
            
            # LongBench-v2 only has 'train' split
            if split not in dataset:
                logger.warning(f"Split '{split}' not found, using 'train'")
                split = 'train'
            
            split_data = dataset[split]
            
            # Filter by domains and process problems
            for idx, item in enumerate(split_data):
                item_domain = item.get('domain', '')
                
                # Skip if domain not in requested domains
                if item_domain not in domains:
                    continue
                
                # Format problem for the existing pipeline
                problem = self._format_problem(item, item_domain)
                if problem:
                    all_problems.append(problem)
            
            # Only log on main process to avoid duplicate logs in multi-GPU setup
            if _is_main_process():
                logger.info(f"Loaded {len(all_problems)} problems from domains: {domains}")
            
            # Sample if requested
            if num_problems and len(all_problems) > num_problems:
                all_problems = rng.sample(all_problems, num_problems)
                if _is_main_process():
                    logger.info(f"Sampled down to {len(all_problems)} problems")
            
        except Exception as e:
            logger.error(f"Error loading LongBench-v2 dataset: {e}")
        
        if _is_main_process():
            logger.info(f"Total loaded problems: {len(all_problems)}")
        return all_problems
    
    def _format_problem(self, item: Dict, domain_name: str) -> Optional[Dict]:
        """
        Format a LongBench-v2 problem for the existing pipeline.
        
        Args:
            item: Raw dataset item
            domain_name: Name of the domain
            
        Returns:
            Formatted problem dict or None if invalid
        """
        try:
            # LongBench-v2 format: question, context, 'choice_A', 'choice_B', 'choice_C', 'choice_D', 'answer', length, domain, language, _id
            question_text = item.get('question', '')
            context_text = item.get('context', '')
            choice_A = item.get('choice_A', '')
            choice_B = item.get('choice_B', '')
            choice_C = item.get('choice_C', '')
            choice_D = item.get('choice_D', '')
            answer = item.get('answer', '')
            question = f"{question_text}\nPick from the following options:\n(A) {choice_A}\n(B) {choice_B}\n(C) {choice_C}\n(D) {choice_D}"
            
            # Get the correct answer (first answer from the list)
            correct_answer = answer
            
            return {
                'question': question,
                'solution': correct_answer,  
                'answer': correct_answer,
                'context': context_text,  # Store the long document for TTT
                'dataset': f"longbench_v2_{domain_name.lower().replace(' ', '_').replace('-', '_')}",  # Create a clean dataset identifier
                'domain': domain_name,  # Store the original domain name
                'language': item.get('language', 'en'),
                'length': item.get('length', 0),
                'raw_item': item  # Keep original item for debugging
            }
            
        except Exception as e:
            logger.warning(f"Error formatting problem from {domain_name}: {e}")
            return None
    
    def get_available_domains(self) -> List[str]:
        """Get available LongBench-v2 domains."""
        return self.LONGBENCH_V2_DOMAINS.copy()
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about the dataset."""
        info = {}
        try:
            # 仅从本地加载
            if not os.path.exists(LOCAL_LONGBENCH_V2_PATH):
                raise FileNotFoundError(f"本地数据集不存在: {LOCAL_LONGBENCH_V2_PATH}")
            
            dataset = load_from_disk(LOCAL_LONGBENCH_V2_PATH)
            if not isinstance(dataset, dict) and not hasattr(dataset, 'keys'):
                dataset = {'train': dataset}
            info['longbench_v2'] = {
                'splits': list(dataset.keys()) if hasattr(dataset, 'keys') else ['train'],
                'features': list(dataset['train'].features.keys()) if 'train' in dataset else [],
                'domains': self.LONGBENCH_V2_DOMAINS
            }
        except Exception as e:
            logger.warning(f"Could not get info for LongBench-v2: {e}")
            info['longbench_v2'] = {'error': str(e)}
        
        return info 