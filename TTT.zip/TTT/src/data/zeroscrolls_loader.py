"""
ZeroSCROLLS dataset loader for long-context question answering experiments.

ZeroSCROLLS is a suite of datasets that require synthesizing information over long texts.
The benchmark includes ten natural language tasks across multiple domains, including 
summarization, question answering, aggregated sentiment classification and information reordering.
"""

import os
import logging
from typing import List, Dict, Optional
# [OFFLINE MODE] 改为使用本地加载
from datasets import load_from_disk
# from datasets import load_dataset  # 原始联网下载方式
import random

logger = logging.getLogger(__name__)

# ========== [OFFLINE MODE] 本地数据路径配置 ==========
LOCAL_ZEROSCROLLS_PATH = "/fs/scratch/rb_bd_dlp_rng-dl01_cr_AIQ_employees/hkz1sgh/Self_distillation/dataset/ZeroSCROLLS"
# =====================================================

class ZeroSCROLLSDataLoader:
    """Data loader for ZeroSCROLLS dataset."""
    
    # Available ZeroSCROLLS datasets
    ZERO_SCROLLS_DATASETS = [
        "gov_report", "summ_screen_fd", "qmsum", "squality", "qasper", 
        "narrative_qa", "quality", "musique", "space_digest", "book_sum_sort"
    ]
    
    def __init__(self):
        """Initialize the ZeroSCROLLS data loader."""
        self.data = {}
        self.loaded_datasets = {}
    
    def load_data(
        self,
        datasets: List[str],
        split: str = 'test',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load ZeroSCROLLS problems for specified datasets.
        
        Args:
            datasets: List of dataset names to load (from ZERO_SCROLLS_DATASETS)
            split: Dataset split ('train', 'validation', 'test')
            num_problems: Maximum number of problems to load per dataset
            random_seed: Random seed for reproducible sampling
            
        Returns:
            List of problems formatted for the existing pipeline
        """
        # Validate dataset names
        invalid_datasets = [ds for ds in datasets if ds not in self.ZERO_SCROLLS_DATASETS]
        if invalid_datasets:
            raise ValueError(f"Invalid dataset names: {invalid_datasets}. Available: {self.ZERO_SCROLLS_DATASETS}")
        
        # Set up random generator for reproducible sampling
        rng = random.Random(random_seed)
        
        all_problems = []
        
        for dataset_name in datasets:
            logger.info(f"Loading ZeroSCROLLS dataset: {dataset_name}")
            
            try:
                # Load dataset if not already loaded
                if dataset_name not in self.loaded_datasets:
                    # [OFFLINE MODE] 从本地加载数据集
                    local_path = os.path.join(LOCAL_ZEROSCROLLS_PATH, dataset_name)
                    if not os.path.exists(local_path):
                        raise FileNotFoundError(f"[OFFLINE MODE] 本地数据集不存在: {local_path}，请先下载数据集到本地")
                    logger.info(f"[OFFLINE MODE] 从本地加载: {local_path}")
                    dataset = load_from_disk(local_path)
                    # 确保返回格式正确
                    if not isinstance(dataset, dict) and not hasattr(dataset, 'keys'):
                        dataset = {'test': dataset}
                    # 原始联网下载方式（已注释）:
                    # dataset = load_dataset("tau/zero_scrolls", dataset_name, trust_remote_code=True)
                    self.loaded_datasets[dataset_name] = dataset
                else:
                    dataset = self.loaded_datasets[dataset_name]
                
                # Get the specified split
                if split not in dataset:
                    logger.warning(f"Split '{split}' not found in {dataset_name}, using 'test'")
                    split = 'test'
                
                split_data = dataset[split]
                
                # Process problems from this dataset
                dataset_problems = []
                for idx, item in enumerate(split_data):
                    if num_problems and len(dataset_problems) >= num_problems:
                        break
                    
                    # Format problem for the existing pipeline
                    problem = self._format_problem(item, dataset_name)
                    if problem:
                        dataset_problems.append(problem)
                
                # Sample if requested
                if num_problems and len(dataset_problems) > num_problems:
                    dataset_problems = rng.sample(dataset_problems, num_problems)
                
                all_problems.extend(dataset_problems)
                logger.info(f"Loaded {len(dataset_problems)} problems from {dataset_name}")
                
            except Exception as e:
                logger.error(f"Error loading ZeroSCROLLS dataset {dataset_name}: {e}")
                continue
        
        logger.info(f"Total loaded problems: {len(all_problems)}")
        return all_problems
    
    def _format_problem(self, item: Dict, dataset_name: str) -> Optional[Dict]:
        """
        Format a ZeroSCROLLS problem for the existing pipeline.
        
        Args:
            item: Raw dataset item
            dataset_name: Name of the dataset
            
        Returns:
            Formatted problem dict or None if invalid
        """
        try:
            # For ZeroSCROLLS, input contains both instruction and context
            # output contains the answer
            input_text = item.get('input', '')
            output_text = item.get('output', '')
            
            if not input_text:
                logger.warning(f"No input found in {dataset_name} item: {item}")
                return None
            
            # Parse instruction and context from input
            question, context = self._parse_zeroscrolls_input(input_text, dataset_name)
            
            if not question or not context:
                logger.warning(f"Could not parse question/context from {dataset_name} input: {input_text[:100]}...")
                return None
            
            return {
                'question': question,
                'solution': output_text if output_text else "No answer provided.",
                'answer': output_text if output_text else "",
                'context': context,  # Store the long document for TTT
                'dataset': dataset_name,
                'raw_item': item  # Keep original item for debugging
            }
            
        except Exception as e:
            logger.warning(f"Error formatting problem from {dataset_name}: {e}")
            return None
    
    def _parse_zeroscrolls_input(self, input_text: str, dataset_name: str) -> tuple[str, str]:
        """
        Parse ZeroSCROLLS input to extract instruction and context.
        
        The input typically has format:
        "You are given [instruction]. [Task description].\n\n[Document Type]:\n[LONG DOCUMENT]"
        
        Args:
            input_text: The full input text containing both instruction and context
            dataset_name: Name of the dataset for better error handling
            
        Returns:
            Tuple of (question/instruction, context/document)
        """
        try:
            # Common patterns to split instruction from document
            # Look for patterns like "Report:", "Document:", "Article:", etc.
            split_patterns = [
                r'\n\n(?:Report|Document|Article|Text|Passage|Paper|Summary|Email|Story|Book|Chapter|Script):\n',
                r'\n\n(?:Given document|Given text|Given article|Given paper):\n',
                r'\n\n(?:Here is the|The following is the) (?:report|document|article|text|passage|paper):\n',
                r'\n\n(?:Below is the|Below you will find the) (?:report|document|article|text|passage|paper):\n'
            ]
            
            question = ""
            context = ""
            
            # Try each pattern to find the split point
            for pattern in split_patterns:
                import re
                match = re.search(pattern, input_text, re.IGNORECASE)
                if match:
                    # Split at the pattern
                    question = input_text[:match.start()].strip()
                    context = input_text[match.end():].strip()
                    break
            
            # If no pattern matched, try to find a double newline and see if it makes sense
            if not question or not context:
                parts = input_text.split('\n\n', 1)
                if len(parts) == 2:
                    potential_question = parts[0].strip()
                    potential_context = parts[1].strip()
                    
                    # Heuristic: if first part is relatively short and second part is much longer
                    if len(potential_question) < 500 and len(potential_context) > len(potential_question) * 2:
                        question = potential_question
                        context = potential_context
            
            # Fallback: if still nothing, use first 200 chars as question, rest as context
            if not question or not context:
                if len(input_text) > 200:
                    question = input_text[:200].strip()
                    context = input_text[200:].strip()
                else:
                    question = input_text
                    context = ""
            
            return question, context
            
        except Exception as e:
            logger.warning(f"Error parsing ZeroSCROLLS input for {dataset_name}: {e}")
            # Fallback: return first 200 chars as question, rest as context
            if len(input_text) > 200:
                return input_text[:200].strip(), input_text[200:].strip()
            else:
                return input_text, ""
    
    def get_available_datasets(self) -> List[str]:
        """Get available ZeroSCROLLS datasets."""
        return self.ZERO_SCROLLS_DATASETS.copy()
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about each dataset."""
        info = {}
        for dataset_name in self.ZERO_SCROLLS_DATASETS:
            try:
                # [OFFLINE MODE] 从本地加载数据集
                local_path = os.path.join(LOCAL_ZEROSCROLLS_PATH, dataset_name)
                if not os.path.exists(local_path):
                    info[dataset_name] = {'error': f'本地数据集不存在: {local_path}'}
                    continue
                dataset = load_from_disk(local_path)
                if not isinstance(dataset, dict) and not hasattr(dataset, 'keys'):
                    dataset = {'test': dataset}
                # 原始联网下载方式（已注释）:
                # dataset = load_dataset("tau/zero_scrolls", dataset_name)
                info[dataset_name] = {
                    'splits': list(dataset.keys()) if hasattr(dataset, 'keys') else ['test'],
                    'features': list(dataset['test'].features.keys()) if 'test' in dataset else []
                }
            except Exception as e:
                logger.warning(f"Could not get info for {dataset_name}: {e}")
                info[dataset_name] = {'error': str(e)}
        
        return info 