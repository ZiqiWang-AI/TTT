import os
# Disable tokenizer parallelism to avoid forking warnings
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from typing import List, Dict, Optional
import logging

# Import the data loaders for supported datasets
from .zeroscrolls_loader import ZeroSCROLLSDataLoader
from .longbench_v2_loader import LongBenchV2DataLoader
from .bank_transactions_loader import BankTransactionsDataLoader
from .olmo_bugs_loader import OLMoBugsDataLoader

logger = logging.getLogger(__name__)

class BaseDataLoader:
    """Base class for dataset loading."""
    
    def __init__(self, dataset_name: str):
        self.dataset_name = dataset_name
    
    def load_data(self, split: str) -> List[Dict]:
        """Load data for a specific split."""
        raise NotImplementedError

class ZeroSCROLLSDataLoaderWrapper(BaseDataLoader):
    """Wrapper for ZeroSCROLLS data loader to match the existing interface."""
    
    def __init__(self):
        super().__init__("tau/zero_scrolls")
        self.loader = ZeroSCROLLSDataLoader()
    
    def load_data(
        self,
        datasets: List[str],
        split: str = 'validation',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load ZeroSCROLLS problems for specified datasets.
        
        Args:
            datasets: List of dataset names to load
            split: Dataset split ('validation', 'test')
            num_problems: Maximum number of problems to load per dataset
            random_seed: Random seed for reproducible sampling
        
        Returns:
            List of problems formatted for existing pipeline
        """
        return self.loader.load_data(
            datasets=datasets,
            split=split,
            num_problems=num_problems,
            random_seed=random_seed
        )
    
    def get_available_datasets(self) -> List[str]:
        """Get available ZeroSCROLLS datasets."""
        return self.loader.get_available_datasets()
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about each dataset."""
        return self.loader.get_dataset_info()

class LongBenchV2DataLoaderWrapper(BaseDataLoader):
    """Wrapper for LongBench-v2 data loader to match the existing interface."""
    
    def __init__(self):
        super().__init__("zai-org/LongBench")
        self.loader = LongBenchV2DataLoader()
    
    def load_data(
        self,
        domains: List[str] = None,
        split: str = 'train',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load LongBench-v2 problems for specified domains.
        
        Args:
            domains: List of domain names to load (from available domains). If None, loads all domains.
            split: Dataset split ('train' - LongBench-v2 only has train split)
            num_problems: Maximum number of problems to load total
            random_seed: Random seed for reproducible sampling
        
        Returns:
            List of problems formatted for existing pipeline
        """
        return self.loader.load_data(
            domains=domains,
            split=split,
            num_problems=num_problems,
            random_seed=random_seed
        )
    
    def get_available_domains(self) -> List[str]:
        """Get available LongBench-v2 domains."""
        return self.loader.get_available_domains()
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about the dataset."""
        return self.loader.get_dataset_info()

class BankTransactionsDataLoaderWrapper(BaseDataLoader):
    """Wrapper for Bank Transactions data loader to match the existing interface."""
    
    def __init__(self):
        super().__init__("sjelassi/bank_transactions_hard")
        self.loader = BankTransactionsDataLoader()
    
    def load_data(
        self,
        dataset_type: str = 'easy',
        split: str = 'train',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load Bank Transactions problems for the specified split.
        
        Args:
            dataset_type: Dataset type ('easy' - only easy dataset available)
            split: Dataset split ('train' - only split available)
            num_problems: Maximum number of problems to load
            random_seed: Random seed for reproducible sampling
        
        Returns:
            List of problems formatted for existing pipeline
        """
        return self.loader.load_data(
            dataset_type=dataset_type,
            split=split,
            num_problems=num_problems,
            random_seed=random_seed
        )
    
    def get_available_splits(self) -> List[str]:
        """Get available dataset splits."""
        return self.loader.get_available_splits()
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about the dataset."""
        return self.loader.get_dataset_info()
    
    def get_bug_types(self) -> List[str]:
        """Get all possible bug types in the dataset."""
        return self.loader.get_bug_types()

class OLMoBugsDataLoaderWrapper(BaseDataLoader):
    """Wrapper for OLMo Bugs data loader to match the existing interface."""
    
    def __init__(self, context_size: Optional[int] = None):
        dataset_name = f"rachitbansal-harvard/olmo_bugs_context_{context_size}" if context_size else "sjelassi/olmo_bugs_5_try"
        super().__init__(dataset_name)
        self.loader = OLMoBugsDataLoader(context_size=context_size)
        self.context_size = context_size
    
    def load_data(
        self,
        split: str = 'train',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load OLMo Bugs problems for the specified split.
        
        Args:
            split: Dataset split ('train' - OLMo Bugs only has train split)
            num_problems: Maximum number of problems to load
            random_seed: Random seed for reproducible sampling
        
        Returns:
            List of problems formatted for existing pipeline
        """
        return self.loader.load_data(
            split=split,
            num_problems=num_problems,
            random_seed=random_seed
        )
    
    def get_available_splits(self) -> List[str]:
        """Get available dataset splits."""
        return self.loader.get_available_splits()
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about the dataset."""
        return self.loader.get_dataset_info()
    
    def get_bug_types(self) -> List[str]:
        """Get all bug types/patterns in the dataset."""
        return self.loader.get_bug_types()

def get_data_loader(dataset_type: str) -> BaseDataLoader:
    """Factory function to get appropriate data loader."""
    # Define available OLMo bugs context sizes
    olmo_bugs_context_sizes = [20, 70, 120, 170, 220, 270, 320, 370, 420, 470, 520, 570, 620, 670, 720, 770, 820, 870, 920, 970]
    
    loaders = {
        'zeroscrolls': ZeroSCROLLSDataLoaderWrapper,
        'longbench-v2': LongBenchV2DataLoaderWrapper,
        'bank-transactions-nop_95': BankTransactionsDataLoaderWrapper,
        'bank-transactions-nop_55': BankTransactionsDataLoaderWrapper,
        'bank-transactions-nop_5': BankTransactionsDataLoaderWrapper,
        'bank-transactions-nop_25': BankTransactionsDataLoaderWrapper,
        'bank-transactions-nop_75': BankTransactionsDataLoaderWrapper,
        'bank-transactions-nop_250': BankTransactionsDataLoaderWrapper,
        'bank-transactions-nop_500': BankTransactionsDataLoaderWrapper,
        'olmo-bugs': OLMoBugsDataLoaderWrapper,
    }
    
    # Add OLMo bugs datasets with different context sizes
    for context_size in olmo_bugs_context_sizes:
        loaders[f'olmo-bugs-{context_size}'] = lambda cs=context_size: OLMoBugsDataLoaderWrapper(context_size=cs)
    
    if dataset_type not in loaders:
        raise ValueError(f"Unknown dataset type: {dataset_type}. Available types: {list(loaders.keys())}")
    
    return loaders[dataset_type]()


