"""
Bank Transactions Easy dataset loader for test-time training experiments.

This dataset contains prompts with bank transaction logs and bugs to detect.
Each prompt contains instructions and a sequence of bank transactions which is the main context,
and the full_label contains a dictionary with bug_type, bug_location, and explanation.
"""

import os
import logging
import json
from typing import List, Dict, Optional
# [OFFLINE MODE] 改为使用本地加载
from datasets import load_from_disk
# from datasets import load_dataset  # 原始联网下载方式
import random

logger = logging.getLogger(__name__)

# ========== [OFFLINE MODE] 本地数据路径配置 ==========
LOCAL_BANK_TRANSACTIONS_PATH = "/fs/scratch/rb_bd_dlp_rng-dl01_cr_AIQ_employees/hkz1sgh/Self_distillation/dataset/BankTransactions"
# =====================================================

class BankTransactionsDataLoader:
    """Data loader for sjelassi/bank_transactions_easy dataset."""
    
    def __init__(self):
        """Initialize the Bank Transactions data loader."""
        self.dataset = None
        self.loaded = False
    
    def load_data(
        self,
        split: str = 'train',
        dataset_type: str = 'easy',
        num_problems: Optional[int] = None,
        random_seed: int = 42
    ) -> List[Dict]:
        """
        Load Bank Transactions problems for the specified split.
        
        Args:
            split: Dataset split ('train' - only split available)
            dataset_type: Dataset type ('easy' - only easy dataset available)
            num_problems: Maximum number of problems to load
            random_seed: Random seed for reproducible sampling
            
        Returns:
            List of problems formatted for the existing pipeline
        """
        # Set up random generator for reproducible sampling
        rng = random.Random(random_seed)
        
        logger.info(f"Loading Bank Transactions dataset: split={split}")
        
        try:
            # Load dataset if not already loaded
            if not self.loaded:
                # [OFFLINE MODE] 从本地加载数据集
                local_path = os.path.join(LOCAL_BANK_TRANSACTIONS_PATH, f"bank_transactions_{dataset_type}")
                if not os.path.exists(local_path):
                    raise FileNotFoundError(f"[OFFLINE MODE] 本地数据集不存在: {local_path}，请先下载数据集到本地")
                logger.info(f"[OFFLINE MODE] 从本地加载: {local_path}")
                self.dataset = load_from_disk(local_path)
                # 确保返回格式正确
                if not isinstance(self.dataset, dict) and not hasattr(self.dataset, 'keys'):
                    self.dataset = {'train': self.dataset}
                # 原始联网下载方式（已注释）:
                # self.dataset = load_dataset(f"sjelassi/bank_transactions_{dataset_type}", trust_remote_code=True)
                self.loaded = True
            
            # Get the specified split
            if split not in self.dataset:
                logger.warning(f"Split '{split}' not found in bank_transactions_{dataset_type}, using 'train'")
                split = 'train'
            
            split_data = self.dataset[split]
            
            # Process problems from this dataset
            problems = []
            for idx, item in enumerate(split_data):
                if num_problems and len(problems) >= num_problems:
                    break
                
                # Format problem for the existing pipeline
                problem = self._format_problem(item)
                if problem:
                    problems.append(problem)
            
            # Sample if requested
            if num_problems and len(problems) > num_problems:
                problems = rng.sample(problems, num_problems)
            
            logger.info(f"Loaded {len(problems)} problems from bank_transactions_{dataset_type}")
            return problems
            
        except Exception as e:
            logger.error(f"Error loading bank_transactions_{dataset_type} dataset: {e}")
            raise
    
    def _format_problem(self, item: Dict) -> Optional[Dict]:
        """
        Format a Bank Transactions problem for the existing pipeline.
        
        Args:
            item: Raw dataset item with columns like 'prompt', 'full_label', etc.
            
        Returns:
            Formatted problem dict or None if invalid
        """
        try:
            # Extract the main components
            prompt = item.get('prompt', '')
            full_label = item.get('full_label', '')
            
            if not prompt:
                logger.warning(f"No prompt found in bank transactions item: {item}")
                return None
            
            # Parse full_label if it's a string
            if isinstance(full_label, str):
                try:
                    full_label_dict = json.loads(full_label)
                except json.JSONDecodeError:
                    logger.warning(f"Could not parse full_label as JSON: {full_label}")
                    full_label_dict = {"bug_type": "UNKNOWN", "bug_location": "", "explanation": ""}
            else:
                full_label_dict = full_label
            
            # Parse instruction and transaction context from prompt
            question, context = self._parse_bank_transactions_prompt(prompt)
            
            if not question or not context:
                logger.warning(f"Could not parse question/context from prompt: {prompt[:100]}...")
                return None
            
            # Format the expected answer based on full_label
            expected_answer = json.dumps(full_label_dict)
            
            return {
                'question': question,
                'solution': expected_answer,  # The expected JSON response
                'answer': expected_answer,    # Same as solution for consistency
                'context': context,           # Store the transaction log for TTT
                'dataset': 'bank_transactions_easy',
                'bug_type': full_label_dict.get('bug_type', ''),
                'bug_location': full_label_dict.get('bug_location', ''),
                'explanation': full_label_dict.get('explanation', ''),
                'raw_item': item             # Keep original item for debugging
            }
            
        except Exception as e:
            logger.warning(f"Error formatting bank transactions problem: {e}")
            return None
    
    def _parse_bank_transactions_prompt(self, prompt: str) -> tuple[str, str]:
        """
        Parse Bank Transactions prompt to extract instruction and transaction context.
        
        The prompt typically has format:
        "Analyze this banking transaction log for bugs. Each operation shows...\n\n
        INITIAL STATE: {...}\n\n
        RULES: ...\n\n
        TRANSACTION LOG:\n[TX001] ...\n[TX002] ...\n\n
        POSSIBLE BUG TYPES: ...\n\n
        Identify the SINGLE bug...\n\n
        Your response:"
        
        Args:
            prompt: The full prompt text containing both instruction and transaction context
            
        Returns:
            Tuple of (question/instruction, context/transaction_log)
        """
        try:
            # Split the prompt into sections
            sections = prompt.split('\n\n')
            
            # Find the transaction log section
            transaction_log_start = -1
            instruction_parts = []
            transaction_parts = []
            
            for i, section in enumerate(sections):
                if 'TRANSACTION LOG:' in section:
                    transaction_log_start = i
                    break
                instruction_parts.append(section)
            
            if transaction_log_start == -1:
                # Fallback: try to find transaction patterns
                for i, section in enumerate(sections):
                    if '[TX' in section and ']' in section:
                        transaction_log_start = i
                        break
            
            if transaction_log_start != -1:
                # Everything from transaction log onwards is context
                transaction_parts = sections[transaction_log_start:]
                # Remove any trailing instruction parts after transaction log
                # Look for "POSSIBLE BUG TYPES" or "Identify the SINGLE bug"
                for i, section in enumerate(transaction_parts):
                    if 'POSSIBLE BUG TYPES' in section or 'Identify the SINGLE bug' in section:
                        # This and following sections are part of instruction
                        instruction_parts.extend(transaction_parts[i:])
                        transaction_parts = transaction_parts[:i]
                        break
            
            # Construct question (instruction) and context (transaction log)
            question = '\n\n'.join(instruction_parts).strip()
            context = '\n\n'.join(transaction_parts).strip()
            
            # If we couldn't split properly, use heuristics
            if not context or len(context) < 50:
                # Look for transaction patterns in the full prompt
                import re
                tx_pattern = r'\[TX\d+\].*?(?=\[TX\d+\]|$)'
                tx_matches = re.findall(tx_pattern, prompt, re.DOTALL)
                
                if tx_matches:
                    # Found transaction log entries
                    context = '\n'.join(tx_matches).strip()
                    # Question is everything before the first transaction
                    first_tx_pos = prompt.find('[TX')
                    if first_tx_pos > 0:
                        question = prompt[:first_tx_pos].strip()
                        # Also include instructions after transaction log
                        last_tx_pos = prompt.rfind('[TX')
                        if last_tx_pos > first_tx_pos:
                            # Find end of last transaction
                            after_last_tx = prompt[last_tx_pos:]
                            next_section_pos = after_last_tx.find('\n\nPOSSIBLE BUG TYPES')
                            if next_section_pos > 0:
                                instruction_suffix = prompt[last_tx_pos + next_section_pos:]
                                question += '\n\n' + instruction_suffix
            
            # Ensure we have both parts
            if not question:
                question = "Analyze this banking transaction log for bugs and identify any issues."
            
            if not context:
                # Last resort: use entire prompt as context
                context = prompt
                question = "Analyze the following banking transaction log for bugs:"
            
            return question, context
            
        except Exception as e:
            logger.warning(f"Error parsing bank transactions prompt: {e}")
            # Fallback: split roughly in half
            mid_point = len(prompt) // 2
            return prompt[:mid_point].strip(), prompt[mid_point:].strip()
    
    def get_available_splits(self) -> List[str]:
        """Get available dataset splits."""
        try:
            if not self.loaded:
                dataset = load_dataset("sjelassi/bank_transactions_easy")
                return list(dataset.keys())
            return list(self.dataset.keys())
        except Exception as e:
            logger.warning(f"Could not get splits for bank_transactions_easy: {e}")
            return ['train']  # Default assumption
    
    def get_dataset_info(self) -> Dict[str, Dict]:
        """Get information about the dataset."""
        try:
            if not self.loaded:
                dataset = load_dataset("sjelassi/bank_transactions_easy")
            else:
                dataset = self.dataset
            
            info = {
                'bank_transactions_easy': {
                    'splits': list(dataset.keys()),
                    'features': list(dataset['train'].features.keys()) if 'train' in dataset else [],
                    'description': 'Bank transaction bug detection dataset with 500 examples',
                    'task_type': 'bug_detection',
                    'response_format': 'json'
                }
            }
            
            # Add split sizes
            for split in dataset.keys():
                info['bank_transactions_easy'][f'{split}_size'] = len(dataset[split])
            
            return info
            
        except Exception as e:
            logger.warning(f"Could not get info for bank_transactions_easy: {e}")
            return {
                'bank_transactions_easy': {
                    'error': str(e),
                    'splits': ['train'],
                    'description': 'Bank transaction bug detection dataset'
                }
            }
    
    def get_bug_types(self) -> List[str]:
        """Get all possible bug types in the dataset."""
        try:
            if not self.loaded:
                self.dataset = load_dataset("sjelassi/bank_transactions_easy")
                self.loaded = True
            
            bug_types = set()
            for item in self.dataset['train']:
                full_label = item.get('full_label', '')
                if isinstance(full_label, str):
                    try:
                        full_label_dict = json.loads(full_label)
                        bug_type = full_label_dict.get('bug_type', '')
                        if bug_type:
                            bug_types.add(bug_type)
                    except json.JSONDecodeError:
                        continue
                elif isinstance(full_label, dict):
                    bug_type = full_label.get('bug_type', '')
                    if bug_type:
                        bug_types.add(bug_type)
            
            return sorted(list(bug_types))
            
        except Exception as e:
            logger.warning(f"Could not get bug types: {e}")
            return ['CALC_ERROR', 'NEGATIVE_BAL', 'LOST_UPDATE', 'DUPLICATE_TXN', 'MONEY_LEAK', 'NONE']
