#!/usr/bin/env python3
"""
Environment setup for test-time training experiments.
Import this module at the beginning of your scripts to set up the environment properly.
"""

import os
import warnings

# Disable tokenizer parallelism to avoid forking warnings
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# Suppress other common warnings
warnings.filterwarnings("ignore", message=".*does not have many workers.*")
warnings.filterwarnings("ignore", message=".*Setting pad_token_id.*")

# Set other useful environment variables for better performance
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:512"

# Only print on main process to avoid duplicate logs in multi-GPU setup
# Check if we're in a distributed setting by looking at environment variables
local_rank = os.environ.get('LOCAL_RANK', '0')
rank = os.environ.get('RANK', '0')

# Only print if this is the main process (rank 0) or if not in distributed mode
if local_rank == '0' and rank == '0':
    print("Environment setup complete:")
    print(f"  TOKENIZERS_PARALLELISM: {os.environ.get('TOKENIZERS_PARALLELISM', 'not set')}")
    print(f"  PYTORCH_CUDA_ALLOC_CONF: {os.environ.get('PYTORCH_CUDA_ALLOC_CONF', 'not set')}")