# Release Notes - Test-Time Training for Long-Context Language Models

## 🎉 Release Summary

This is the cleaned, publication-ready version of the test-time training codebase. The code has been streamlined to focus on the four main benchmarks presented in the paper while maintaining full functionality and reproducibility.

## ✅ What's Included

### Supported Datasets (4)
1. **ZeroSCROLLS** - 10 long document tasks (gov_report, qmsum, narrative_qa, etc.)
2. **LongBench-v2** - 6 domains of long-context understanding
3. **Bank Transactions** - 7 difficulty variants (nop_5 to nop_500)
4. **OLMo Bugs** - 20 context length variants (20KB to 970KB)

### Core Features
- ✅ Per-problem test-time training with LoRA or full fine-tuning
- ✅ Frozen KV cache optimization for memory efficiency
- ✅ Context batchification for very long sequences
- ✅ Multi-checkpoint evaluation during training
- ✅ vLLM integration for faster inference
- ✅ Model sharding for handling extreme context lengths
- ✅ Comprehensive evaluation metrics

### Documentation
- ✅ Detailed README with installation, usage, and examples
- ✅ Quick start examples in `examples/quickstart.sh`
- ✅ CHANGELOG documenting all changes from development version
- ✅ Inline code comments and docstrings

### Scripts
- ✅ Main experiment runner: `scripts/run_experiment.py`
- ✅ Hyperparameter sweep scripts for all 4 datasets
- ✅ Frozen KV cache example scripts
- ✅ All scripts are executable and ready to run

## 🗑️ What Was Removed

### Datasets (4)
- AIME (math competition problems)
- MATH500 (math problem solving)
- MiniF2F (formal proof verification)
- TutorEval (educational QA)

### Training Modes
- GRPO (policy optimization - not used in paper)
- Reasoning TTT (not the main focus)

### Cleanup Details
- Removed 200+ lines from `run_experiment.py`
- Simplified `data_loader.py` to only support 4 datasets
- Removed 7 sweep scripts for unsupported datasets
- Cleaned up imports and dead code paths

## 📁 Directory Structure

```
test-time-training-release/
├── README.md              # Comprehensive documentation
├── LICENSE               # MIT license
├── CHANGELOG.md          # Detailed changelog
├── RELEASE_NOTES.md      # This file
├── requirements.txt      # Dependencies
├── setup_env.py         # Environment setup
│
├── examples/
│   └── quickstart.sh    # Quick start examples
│
├── scripts/
│   ├── run_experiment.py          # Main entry point (CLEANED)
│   ├── sweep_zeroscrolls_*.sh     # ZeroSCROLLS experiments
│   ├── sweep_longbench_v2_*.sh    # LongBench-v2 experiments
│   ├── sweep_bank_transactions_*.sh # Bank Transactions experiments
│   ├── sweep_olmo_bugs_*.sh       # OLMo Bugs experiments
│   └── run_frozen_kv_*.sh         # Frozen KV examples
│
└── src/
    ├── data/
    │   ├── data_loader.py (CLEANED)
    │   ├── zeroscrolls_loader.py
    │   ├── longbench_v2_loader.py
    │   ├── bank_transactions_loader.py
    │   └── olmo_bugs_loader.py
    │
    ├── models/
    │   ├── ttt_llm.py      # Complete TTT implementation
    │   └── adaptation.py    # LoRA/full fine-tuning
    │
    ├── evaluation/
    │   ├── enhanced_eval.py # Enhanced answer matching
    │   └── metrics.py       # Evaluation metrics
    │
    └── utils/
        ├── evaluation_utils.py  # Evaluation pipeline
        ├── logging_utils.py     # W&B logging
        ├── rope_utils.py        # RoPE/YaRN
        └── gpu_utils.py         # GPU utilities
```

## 🚀 Quick Start

### Installation
```bash
cd test-time-training-release
pip install -r requirements.txt
python setup_env.py
```

### Run Baseline
```bash
python scripts/run_experiment.py \
  --mode context_only \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --output-dir results/baseline
```

### Run Test-Time Training
```bash
python scripts/run_experiment.py \
  --mode ttt \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --num-epochs 4 \
  --learning-rate 3e-4 \
  --output-dir results/ttt
```

### Run Frozen KV (Memory Efficient)
```bash
python scripts/run_experiment.py \
  --mode ttt \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --use-frozen-kv \
  --frozen-kv-sample-m 64 \
  --frozen-kv-num-steps 8 \
  --output-dir results/frozen_kv
```

## ✨ Key Improvements

### Code Quality
- **Cleaner**: Removed 500+ lines of unused code
- **Focused**: Only 4 datasets, all paper-relevant
- **Documented**: Comprehensive README and examples
- **Tested**: All main paths verified to work

### Usability
- **Quick Start**: Get running in <5 minutes
- **Examples**: Real working examples provided
- **Scripts**: All sweep scripts retained and executable
- **Help**: Detailed troubleshooting guide

### Reproducibility
- **Complete**: All paper experiments reproducible
- **Versioned**: Clear dependencies in requirements.txt
- **Documented**: Every hyperparameter explained
- **Tested**: Verified on multiple GPUs and models

## 🔬 Reproducing Paper Results

Run the full experimental sweeps:

```bash
# ZeroSCROLLS (all 10 datasets)
bash scripts/sweep_zeroscrolls_ttt.sh

# LongBench-v2 (all 6 domains)
bash scripts/sweep_longbench_v2_ttt.sh

# Bank Transactions (all 7 variants)
bash scripts/sweep_bank_transactions_ttt.sh

# OLMo Bugs (all 20 context sizes)
bash scripts/sweep_olmo_bugs_ttt.sh
```

Each sweep script runs experiments with multiple:
- Models (Qwen-1.5B, Qwen-3B, Llama-3B, etc.)
- Hyperparameters (learning rate, LoRA rank, epochs)
- Training methods (standard TTT, frozen KV)

## 📊 Expected Results

After running experiments, you'll find:
- `results/*/config.json` - Full configuration
- `results/*/results.json` - Evaluation metrics
- `results/*/checkpoints/` - Model checkpoints (if saved)
- W&B logs (if enabled) - Training curves and metrics

## 🐛 Known Issues & Solutions

### Out of Memory
- Solution: Use `--use-frozen-kv` flag
- Or: Reduce `--max-context-length`
- Or: Use `--context-parallel` for model sharding

### Slow Training
- Solution: Reduce `--num-epochs` or `--frozen-kv-num-steps`
- Or: Use `--use-context-batchification`

### Import Errors
- Solution: Run `python setup_env.py` first
- Check: All dependencies in `requirements.txt` installed

## 📝 Citation

```bibtex
@article{yourpaper2025,
  title={Test-Time Training for Long-Context Language Models},
  author={Your Authors},
  journal={arXiv preprint arXiv:XXXX.XXXXX},
  year={2025}
}
```

## 🤝 Contributing

This is a research release. For bugs or questions:
1. Check README.md and this file
2. Check CHANGELOG.md for known changes
3. Open a GitHub issue with details

## 📜 License

MIT License - See LICENSE file for details.

## 🙏 Acknowledgments

Built on:
- HuggingFace Transformers & Accelerate
- PEFT for LoRA
- vLLM for fast inference
- Datasets from tau/zero_scrolls, zai-org/LongBench, and others

---

**Version**: 1.0.0 (Release)  
**Date**: 2025-01-XX  
**Status**: ✅ Ready for publication


