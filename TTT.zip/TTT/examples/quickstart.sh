#!/bin/bash
# Quick Start Examples for Test-Time Training

# Example 1: Baseline evaluation (no training)
echo "Running baseline evaluation on ZeroSCROLLS..."
python scripts/run_experiment.py \
  --mode context_only \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --zeroscrolls-num-problems 5 \
  --max-context-length 32768 \
  --output-dir results/quickstart_baseline

# Example 2: Test-time training with LoRA
echo "Running test-time training with LoRA..."
python scripts/run_experiment.py \
  --mode ttt \
  --adapter lora \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --zeroscrolls-num-problems 5 \
  --num-epochs 4 \
  --learning-rate 3e-4 \
  --lora-r 16 \
  --max-context-length 32768 \
  --output-dir results/quickstart_ttt

# Example 3: Frozen KV cache TTT (memory efficient)
echo "Running frozen KV cache TTT..."
python scripts/run_experiment.py \
  --mode ttt \
  --adapter lora \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --zeroscrolls-num-problems 5 \
  --use-frozen-kv \
  --frozen-kv-sample-m 64 \
  --frozen-kv-lora-rank 16 \
  --frozen-kv-num-steps 8 \
  --frozen-kv-lr 3e-4 \
  --max-context-length 32768 \
  --output-dir results/quickstart_frozen_kv

echo "Quick start complete! Check results in the results/ directory."


