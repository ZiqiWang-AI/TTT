# Test-Time Training for Long-Context Language Models

Official implementation of query-only test-time training (qTTT) for long-context LLMs.

## Overview

This repository provides efficient test-time training for adapting language models to long-context tasks. We support:

- **Per-problem adaptation**: Train a separate adapter for each evaluation instance
- **Frozen KV cache**: Memory-efficient TTT using cached key-value states
- **Context batchification**: Break long contexts into manageable chunks for training

## Supported Datasets

We provide evaluation on four long-context benchmarks:

1. **ZeroSCROLLS** - Long document summarization and QA (10 datasets)
2. **LongBench-v2** - Multi-domain long-context understanding (6 domains)
3. **Bank Transactions** - Transaction log bug detection (7 difficulty variants)
4. **OLMo Bugs** - Code repository bug localization (20 context length variants)

## Installation

### Requirements

- Python 3.8+
- CUDA 11.8+ (for GPU acceleration)
- 40GB+ GPU memory recommended for long contexts

### Setup

```bash
# Clone the repository
git clone https://github.com/your-org/test-time-training.git
cd test-time-training

# Install dependencies
pip install -r requirements.txt

# Set up environment
python setup_env.py
```

### Dependencies

Key packages:
- `torch>=2.0.0`
- `transformers>=4.40.0`
- `accelerate>=0.27.0`
- `peft>=0.10.0` (for LoRA adaptation)
- `vllm>=0.4.0` (optional, for faster evaluation)
- `datasets`, `numpy`, `tqdm`

## Quick Start

### Context-Only Baseline (No Training)

Evaluate a model without any adaptation:

```bash
python scripts/run_experiment.py \
  --mode context_only \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --output-dir results/zeroscrolls_baseline \
  --max-context-length 32768
```

### Test-Time Training with LoRA

Train a LoRA adapter per problem:

```bash
python scripts/run_experiment.py \
  --mode ttt \
  --adapter lora \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --num-epochs 4 \
  --learning-rate 3e-4 \
  --lora-r 16 \
  --output-dir results/zeroscrolls_ttt
```

### Frozen KV Cache TTT (Memory Efficient)

Use frozen KV cache for very long contexts:

```bash
python scripts/run_experiment.py \
  --mode ttt \
  --adapter lora \
  --model-name Qwen/Qwen2.5-1.5B-Instruct \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report \
  --use-frozen-kv \
  --frozen-kv-sample-m 64 \
  --frozen-kv-lora-rank 16 \
  --frozen-kv-num-steps 8 \
  --frozen-kv-lr 3e-4 \
  --output-dir results/zeroscrolls_frozen_kv
```

## Dataset-Specific Usage

### ZeroSCROLLS

Available datasets: `gov_report`, `summ_screen_fd`, `qmsum`, `squality`, `qasper`, `narrative_qa`, `quality`, `musique`, `space_digest`, `book_sum_sort`

```bash
# Run on all ZeroSCROLLS datasets
python scripts/run_experiment.py \
  --mode ttt \
  --dataset-type zeroscrolls \
  --zeroscrolls-datasets gov_report,qmsum,narrative_qa \
  --num-epochs 4 \
  --output-dir results/zeroscrolls_multi
```

See `scripts/sweep_zeroscrolls_ttt.sh` for comprehensive hyperparameter sweeps.

### LongBench-v2

Available domains: `Single-Document QA`, `Multi-Document QA`, `Long In-context Learning`, `Long-dialogue History Understanding`, `Code Repository Understanding`, `Long Structured Data Understanding`

```bash
# Run on specific domains
python scripts/run_experiment.py \
  --mode ttt \
  --dataset-type longbench-v2 \
  --longbench-v2-domains "Single-Document QA,Multi-Document QA" \
  --num-epochs 4 \
  --output-dir results/longbench_v2_qa
```

See `scripts/sweep_longbench_v2_ttt.sh` for examples.

### Bank Transactions

Available difficulty levels: `nop_5`, `nop_25`, `nop_55`, `nop_75`, `nop_95`, `nop_250`, `nop_500`

```bash
# Run on hard variant (nop_95 = 95% no-op transactions)
python scripts/run_experiment.py \
  --mode ttt \
  --dataset-type bank-transactions-nop_95 \
  --num-epochs 4 \
  --use-frozen-kv \
  --output-dir results/bank_tx_hard
```

See `scripts/sweep_bank_transactions_ttt.sh` for examples.

### OLMo Bugs

Available context sizes: 20, 70, 120, ..., 970 (KB of context)

```bash
# Run with 220KB context
python scripts/run_experiment.py \
  --mode ttt \
  --dataset-type olmo-bugs-220 \
  --num-epochs 4 \
  --use-frozen-kv \
  --output-dir results/olmo_bugs_220
```

See `scripts/sweep_olmo_bugs_ttt.sh` for examples.

## Advanced Features

### Context Batchification

For very long contexts, split into chunks for training:

```bash
python scripts/run_experiment.py \
  --mode ttt \
  --dataset-type zeroscrolls \
  --use-context-batchification \
  --context-batch-size 128 \
  --min-chunk-length 256 \
  --output-dir results/zeroscrolls_batched
```

### Multi-Checkpoint Evaluation

Evaluate at multiple epochs during training:

```bash
python scripts/run_experiment.py \
  --mode ttt \
  --num-epochs 8 \
  --epoch-checkpoints "1,2,4,8" \
  --output-dir results/zeroscrolls_checkpoints
```

### vLLM Acceleration

Use vLLM for faster evaluation (requires separate model saving):

```bash
python scripts/run_experiment.py \
  --mode context_only \
  --use-vllm-for-eval \
  --vllm-tensor-parallel-size 2 \
  --output-dir results/zeroscrolls_vllm
```

### Model Sharding for Long Contexts

Shard model across GPUs for very long sequences:

```bash
python scripts/run_experiment.py \
  --mode ttt \
  --context-parallel \
  --hf-device-map auto \
  --hf-max-memory-gib 40 \
  --output-dir results/zeroscrolls_sharded
```

## Command-Line Arguments

### Core Arguments

- `--mode`: Experiment mode (`context_only` for baseline, `ttt` for test-time training)
- `--model-name`: HuggingFace model name (e.g., `Qwen/Qwen2.5-1.5B-Instruct`)
- `--dataset-type`: Dataset to use (see supported datasets above)
- `--output-dir`: Directory for results and checkpoints

### Training Arguments

- `--adapter`: Adaptation method (`lora` or `full_ft`)
- `--num-epochs`: Number of training epochs (default: 4)
- `--learning-rate`: Learning rate for training (default: 5e-4)
- `--batch-size`: Training batch size (default: 1)
- `--gradient-accumulation-steps`: Gradient accumulation (default: 4)

### LoRA Arguments

- `--lora-r`: LoRA rank (default: 16)
- `--lora-alpha`: LoRA alpha scaling (default: 32)
- `--lora-dropout`: LoRA dropout rate (default: 0.1)
- `--lora-target-modules`: Modules to apply LoRA to (default: `q_proj,v_proj,k_proj,o_proj`)

### Frozen KV Arguments

- `--use-frozen-kv`: Enable frozen KV cache TTT
- `--frozen-kv-sample-m`: Number of positions to sample per step (default: 64)
- `--frozen-kv-lora-rank`: LoRA rank for frozen KV (default: 16)
- `--frozen-kv-num-steps`: Number of SGD steps (default: 8)
- `--frozen-kv-lr`: Learning rate for frozen KV (default: 3e-4)
- `--frozen-kv-dtype`: Data type for cached KV (`fp16` or `bf16`)

### Context Arguments

- `--max-context-length`: Maximum context length in tokens (default: 16384)
- `--max-question-length`: Maximum question length in tokens (default: 1024)
- `--reasoning-budget`: Maximum reasoning tokens (default: 512)
- `--answer-budget`: Maximum answer tokens (default: 512)

### Memory Optimization

- `--use-context-batchification`: Split context into chunks
- `--context-batch-size`: Number of chunks (default: 128)
- `--min-chunk-length`: Minimum tokens per chunk (default: 256)

## Reproducing Paper Results

We provide sweep scripts for reproducing all experiments:

```bash
# ZeroSCROLLS experiments
bash scripts/sweep_zeroscrolls_ttt.sh

# LongBench-v2 experiments
bash scripts/sweep_longbench_v2_ttt.sh

# Bank Transactions experiments
bash scripts/sweep_bank_transactions_ttt.sh

# OLMo Bugs experiments
bash scripts/sweep_olmo_bugs_ttt.sh
```

Each script runs experiments across multiple hyperparameter settings and models.

## Project Structure

```
test-time-training/
├── src/
│   ├── data/                    # Dataset loaders
│   │   ├── zeroscrolls_loader.py
│   │   ├── longbench_v2_loader.py
│   │   ├── bank_transactions_loader.py
│   │   └── olmo_bugs_loader.py
│   ├── models/                  # Model and adaptation code
│   │   ├── ttt_llm.py          # Main TTT implementation
│   │   └── adaptation.py        # LoRA and full fine-tuning
│   ├── evaluation/              # Evaluation utilities
│   │   ├── enhanced_eval.py     # Enhanced answer matching
│   │   └── metrics.py           # Evaluation metrics
│   └── utils/                   # Utility functions
│       ├── evaluation_utils.py
│       ├── logging_utils.py
│       └── rope_utils.py
├── scripts/                     # Experiment scripts
│   ├── run_experiment.py       # Main entry point
│   ├── sweep_*.sh              # Hyperparameter sweeps
│   └── run_frozen_kv_*.sh      # Frozen KV examples
├── requirements.txt
└── README.md
```

## Tips and Best Practices

### Memory Management

1. **For contexts >32K tokens**: Use `--use-frozen-kv` to avoid OOM
2. **For contexts >64K tokens**: Add `--use-context-batchification`
3. **Limited GPU memory**: Reduce `--lora-r` to 8 or use `--frozen-kv-lora-rank 8`

### Hyperparameter Tuning

- **Learning rate**: Start with `3e-4`, try `1e-4` to `1e-3`
- **LoRA rank**: 16 works well for most tasks, try 8 or 32
- **Number of epochs**: 4-8 epochs usually sufficient
- **Frozen KV steps**: 8 steps is a good default, try 4-16

### Performance Optimization

- Use `--dtype bfloat16` for better numerical stability
- Enable `--use-vllm-for-eval` for faster evaluation (when available)
- Use multiple GPUs with `--context-parallel` for very long contexts

## Troubleshooting

### Out of Memory Errors

1. Enable frozen KV cache: `--use-frozen-kv`
2. Reduce batch size: `--batch-size 1`
3. Increase gradient accumulation: `--gradient-accumulation-steps 8`
4. Reduce context length: `--max-context-length 16384`

### Slow Training

1. Reduce number of epochs: `--num-epochs 2`
2. Reduce frozen KV steps: `--frozen-kv-num-steps 4`
3. Enable context batchification: `--use-context-batchification`

### Installation Issues

- For vLLM issues, it's optional - you can skip it
- Make sure CUDA version matches PyTorch CUDA version
- Try `pip install --upgrade pip setuptools wheel` before installing

## Citation

If you use this code in your research, please cite:

```bibtex
@article{yourpaper2025,
  title={Test-Time Training for Long-Context Language Models},
  author={Your Authors},
  journal={arXiv preprint arXiv:XXXX.XXXXX},
  year={2025}
}
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Built on HuggingFace Transformers and Accelerate
- Uses PEFT for efficient LoRA implementation
- vLLM for fast inference (optional)
- Datasets from ZeroSCROLLS, LongBench-v2, and other benchmarks

## Contact

For questions or issues, please open a GitHub issue or contact the authors.


