#!/bin/bash

# LongBench-v2 Context-Only Evaluation Sweep
# Evaluates models on LongBench-v2 datasets without any test-time training

# LongBench-v2 domains to test
# LONGBENCH_V2_DOMAINS=("Single-Document QA")
# LONGBENCH_V2_DOMAINS=("Single-Document QA" "Multi-Document QA" "Long In-context Learning")
# LONGBENCH_V2_DOMAINS=("Long-dialogue History Understanding" "Code Repository Understanding" "Long Structured Data Understanding")

# Generation parameters
REASONING_BUDGETS=(512 1024 4096 8192 16384)  # Limited reasoning for faster evaluation
# REASONING_BUDGETS=(512 1024 4096 8192 16384 24576 32768)  # Limited reasoning for faster evaluation
ANSWER_BUDGETS=(512)  # Reasonable answer lengths
EVAL_BATCH_SIZE=1  # Very small eval batch due to long contexts

# Model configuration
# MODELS=("Qwen/Qwen3-8B")
MODELS=("Qwen/Qwen3-1.7B")
# MODELS=("Qwen/Qwen3-4B")
# MODELS=("meta-llama/Llama-3.1-8B-Instruct")
# MODELS=("Qwen/Qwen3-1.7B" "meta-llama/Llama-3.2-3B-Instruct" "Qwen/Qwen3-4B" "meta-llama/Llama-3.1-8B-Instruct")
# MODELS=("meta-llama/Llama-3.2-3B-Instruct")
CONTEXT_LENGTH=96768  # Long context for LongBench-v2
QUESTION_LENGTH=512  # Longer questions due to instructions

# Fixed parameters
MODE="context_only"
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
NUM_PROBLEMS=50  # Limit number of problems for faster evaluation

echo "Starting LongBench-v2 Context-Only Evaluation Sweep"
echo "Domains: ${LONGBENCH_V2_DOMAINS[*]}"
echo "Models: ${MODELS[*]}"

for model_name in "${MODELS[@]}"; do
    for domain in "${LONGBENCH_V2_DOMAINS[@]}"; do
        for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
            for answer_budget in "${ANSWER_BUDGETS[@]}"; do
                echo ""
                echo "=========================================="
                echo "Submitting LongBench-v2 Context-Only Job:"
                echo "  Domain: $domain"
                echo "  Model: $model_name"
                echo "  Reasoning Budget: $reasoning_budget"
                echo "  Answer Budget: $answer_budget"
                echo "=========================================="
                
                # Create output directory name (replace spaces and special chars)
                domain_clean=$(echo "$domain" | tr ' ' '_' | tr '-' '_' | tr '[:upper:]' '[:lower:]')
                output_dir="results/longbench_v2_context_${domain_clean}_$(basename $model_name)_r${reasoning_budget}_a${answer_budget}"
                mkdir -p $output_dir

                export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
                export VLLM_ALLOW_LONG_MAX_MODEL_LEN=1
                python scripts/run_experiment.py \
                    --mode "$MODE" \
                    --dataset-type longbench-v2 \
                    --longbench-v2-domains "$domain" \
                    --longbench-v2-num-problems "$NUM_PROBLEMS" \
                    --model-name "$model_name" \
                    --eval-batch-size "$EVAL_BATCH_SIZE" \
                    --max-context-examples 0 \
                    --max-context-length "$CONTEXT_LENGTH" \
                    --max-question-length "$QUESTION_LENGTH" \
                    --max-solution-length "$answer_budget" \
                    --reasoning-budget "$reasoning_budget" \
                    --answer-budget "$answer_budget" \
                    --num-samples "$NUM_SAMPLES" \
                    --wandb-mode "$WANDB_MODE" \
                    --wandb-project "ttt-longbench-v2-context-only-new" \
                    --output-dir "$output_dir" \
                    --use-enhanced-eval \
                    --use-vllm-for-eval \
                    --vllm-tensor-parallel-size 8 \
                    --context-parallel \
                    --seed 42 \
                    2>&1 | tee "$output_dir/log.txt"
                sleep 2  # Short pause between jobs
            done
        done
    done
done

echo ""
echo "🎯 All LongBench-v2 context-only jobs submitted!"
echo "Results will be saved in results/longbench_v2_context_* directories"
echo ""
echo "📊 Expected results structure:"
echo "  - Results: results/*/results.json"
echo ""
echo "💡 Key features of LongBench-v2 Context-Only:"
echo "  - Evaluates base model performance without any training"
echo "  - Uses in-context learning with long documents"
echo "  - Multiple choice QA with accuracy metrics" 
