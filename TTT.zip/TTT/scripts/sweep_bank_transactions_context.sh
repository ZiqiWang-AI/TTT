#!/bin/bash

# Bank Transactions Context-Only Evaluation Sweep
# Evaluates models on Bank Transactions dataset without any test-time training

# Generation parameters
# REASONING_BUDGETS=(32 64 128 256 512 768 1024)  # Multiple reasoning budgets for analysis
REASONING_BUDGETS=(65536)  # Multiple reasoning budgets for analysis
# REASONING_BUDGETS=(1536 2048 4096)  # Multiple reasoning budgets for analysis
# REASONING_BUDGETS=(1536 2048 4096)  # Multiple reasoning budgets for analysis
# REASONING_BUDGETS=(512)  # Multiple reasoning budgets for analysis
ANSWER_BUDGETS=(128)  # JSON responses should be relatively short
EVAL_BATCH_SIZE=1  # Conservative batch size for context evaluation

# DATASET_TYPE="bank-transactions-nop_95"
# DATASET_TYPE="bank-transactions-nop_75"
# DATASET_TYPES=("bank-transactions-nop_55")
# DATASET_TYPE="bank-transactions-nop_25"
# DATASET_TYPE="bank-transactions-nop_5"
# DATASET_TYPE="bank-transactions-nop_250"
# DATASET_TYPE="bank-transactions-nop_500"
# DATASET_TYPES=("bank-transactions-nop_25" "bank-transactions-nop_5" "bank-transactions-nop_55")
# DATASET_TYPES=("bank-transactions-nop_95" "bank-transactions-nop_75")
# DATASET_TYPES=("bank-transactions-nop_250")
# DATASET_TYPES=("bank-transactions-nop_500")
DATASET_TYPES=("bank-transactions-nop_5" "bank-transactions-nop_25" "bank-transactions-nop_75" "bank-transactions-nop_95" "bank-transactions-nop_250" "bank-transactions-nop_500")

# Model configuration
MODELS=("Qwen/Qwen3-1.7B")
# MODELS=("Qwen/Qwen3-4B")
# MODELS=("Qwen/Qwen3-8B")
# MODELS=("Qwen/Qwen3-14B")
# MODELS=("Qwen/Qwen3-32B")

CONTEXT_LENGTH=24576   # Context length for transaction logs
QUESTION_LENGTH=512   # Instructions and task description

# Fixed parameters
MODE="context_only"
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
NUM_PROBLEMS=100  # Use a good subset for evaluation (out of 500 total)


echo "Starting Bank Transactions Context-Only Evaluation Sweep"
echo "Models: ${MODELS[*]}"
echo "Reasoning Budgets: ${REASONING_BUDGETS[*]}"
echo "Answer Budgets: ${ANSWER_BUDGETS[*]}"

for dataset_type in "${DATASET_TYPES[@]}"; do
    for model_name in "${MODELS[@]}"; do
        for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
            for answer_budget in "${ANSWER_BUDGETS[@]}"; do
                echo ""
                echo "=========================================="
                echo "Submitting Bank Transactions Context-Only Job:"
                echo "  Model: $model_name"
                echo "  Reasoning Budget: $reasoning_budget"
                echo "  Answer Budget: $answer_budget"
                echo "=========================================="
                
                # Create output directory name
                model_clean=$(basename $model_name | tr '[:upper:]' '[:lower:]' | tr '.' '_')
                output_dir="results/${dataset_type}_context_${model_clean}_r${reasoning_budget}_a${answer_budget}"
                mkdir -p $output_dir

                export CUDA_VISIBLE_DEVICES=0,1,2,3
                export VLLM_ALLOW_LONG_MAX_MODEL_LEN=1
                python scripts/run_experiment.py \
                    --mode "$MODE" \
                    --dataset-type "$dataset_type" \
                    --bank-transactions-num-problems "$NUM_PROBLEMS" \
                    --model-name "$model_name" \
                    --eval-batch-size "$EVAL_BATCH_SIZE" \
                    --max-context-examples 1 \
                    --max-context-length "$CONTEXT_LENGTH" \
                    --max-question-length "$QUESTION_LENGTH" \
                    --max-solution-length "$answer_budget" \
                    --reasoning-budget "$reasoning_budget" \
                    --answer-budget "$answer_budget" \
                    --num-samples "$NUM_SAMPLES" \
                    --wandb-mode "$WANDB_MODE" \
                    --wandb-project "ttt-bank-transactions-context-only" \
                    --output-dir "$output_dir" \
                    --use-enhanced-eval \
                    --use-vllm-for-eval \
                    --vllm-tensor-parallel-size 4 \
                    --context-parallel \
                    --seed 42 \
                    2>&1 | tee "$output_dir/log.txt"
                sleep 2  # Short pause between jobs
            done
        done
    done
done

echo ""
echo "🎯 All Bank Transactions context-only jobs submitted!"
echo "Results will be saved in results/bank_transactions_context_* directories"
echo ""
echo "📊 Expected results structure:"
echo "  - Results: results/*/results.json"
echo "  - Logs: results/*/log.txt"
echo ""
echo "💡 Key features of Bank Transactions Context-Only:"
echo "  - Evaluates base model performance without any training"
echo "  - Uses transaction log context for bug detection"
echo "  - JSON output format: {\"bug_type\": \"...\", \"bug_location\": \"...\", \"explanation\": \"...\"}"
echo "  - Bug types: CALC_ERROR, NEGATIVE_BAL, LOST_UPDATE, DUPLICATE_TXN, MONEY_LEAK, NONE"
