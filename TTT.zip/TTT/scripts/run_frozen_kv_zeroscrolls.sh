#!/bin/bash

# Example script for running frozen KV TTT on ZeroSCROLLS datasets
# This demonstrates the new efficient frozen KV cache approach

set -e

# Configuration
MODEL="Qwen/Qwen3-1.7B"
DATASET="zeroscrolls"
ZEROSCROLLS_DATASET="gov_report"
MODE="ttt"
OUTPUT_DIR="results/frozen_kv_zeroscrolls_${ZEROSCROLLS_DATASET}_$(date +%Y%m%d_%H%M%S)"

# Frozen KV specific parameters
USE_FROZEN_KV=true
FROZEN_KV_SAMPLE_M=64          # Number of token positions to sample per step
FROZEN_KV_LORA_RANK=16         # LoRA rank for query/output projections
FROZEN_KV_NUM_STEPS=8          # Number of SGD steps
FROZEN_KV_DTYPE="bf16"         # Data type for cached KV (fp16 or bf16)
FROZEN_KV_LR=3e-4              # Learning rate for frozen KV training

# Model and training parameters
ADAPTER="lora"
BATCH_SIZE=1
EVAL_BATCH_SIZE=1
CONTEXT_LENGTH=8192            # Long context for ZeroSCROLLS
QUESTION_LENGTH=1024
REASONING_BUDGET=0             # No reasoning for efficiency
ANSWER_BUDGET=512
MAX_TRAIN_EXAMPLES=5           # Number of problems to process

# Output configuration
WANDB_PROJECT="frozen_kv_ttt"
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网

echo "🧊 Starting Frozen KV TTT experiment"
echo "Model: ${MODEL}"
echo "Dataset: ${ZEROSCROLLS_DATASET}"
echo "Output: ${OUTPUT_DIR}"
echo "Frozen KV Config: M=${FROZEN_KV_SAMPLE_M}, rank=${FROZEN_KV_LORA_RANK}, steps=${FROZEN_KV_NUM_STEPS}, dtype=${FROZEN_KV_DTYPE}"

# Run the experiment
python scripts/run_experiment.py \
    --mode ${MODE} \
    --adapter ${ADAPTER} \
    --model-name ${MODEL} \
    --device cuda \
    --dtype bfloat16 \
    \
    --dataset-type ${DATASET} \
    --zeroscrolls-datasets ${ZEROSCROLLS_DATASET} \
    --max-train-examples ${MAX_TRAIN_EXAMPLES} \
    --max-context-length ${CONTEXT_LENGTH} \
    --max-question-length ${QUESTION_LENGTH} \
    \
    --batch-size ${BATCH_SIZE} \
    --eval-batch-size ${EVAL_BATCH_SIZE} \
    --reasoning-budget ${REASONING_BUDGET} \
    --answer-budget ${ANSWER_BUDGET} \
    \
    --use-frozen-kv \
    --frozen-kv-sample-m ${FROZEN_KV_SAMPLE_M} \
    --frozen-kv-lora-rank ${FROZEN_KV_LORA_RANK} \
    --frozen-kv-num-steps ${FROZEN_KV_NUM_STEPS} \
    --frozen-kv-dtype ${FROZEN_KV_DTYPE} \
    --frozen-kv-lr ${FROZEN_KV_LR} \
    \
    --output-dir ${OUTPUT_DIR} \
    --wandb-project ${WANDB_PROJECT} \
    --wandb-mode ${WANDB_MODE} \
    --seed 42

echo "✅ Frozen KV TTT experiment completed!"
echo "Results saved to: ${OUTPUT_DIR}"

