#!/bin/bash

#SBATCH --job-name=zeroscrolls_ttt
#SBATCH --output=logs/zeroscrolls_ttt_%A_%a.out
#SBATCH --error=logs/zeroscrolls_ttt_%A_%a.err
#SBATCH --time=24:00:00
#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --array=0-7

# ZeroSCROLLS Per-Problem Test-Time Training Sweep
# Uses the new per-problem TTT method for ZeroSCROLLS datasets
# Usage: sbatch scripts/sweep_zeroscrolls_ttt.sh

# ZeroSCROLLS datasets to test - optimized for 6-GPU parallel processing
# Each dataset will run on a separate GPU for maximum parallelization
ZEROSCROLLS_DATASETS=("gov_report" "qmsum" "qasper" "narrative_qa" "quality" "musique" "summ_screen_fd" "squality")
# Additional datasets available: "space_digest" "book_sum_sort"

# TTT-specific parameters
LEARNING_RATES=(3e-4 1e-5 3e-5 1e-6)  # Higher LRs for short per-problem training
MAX_EPOCHS=32  # Maximum epochs to train - evaluations will be done at checkpoints
EPOCH_CHECKPOINTS="1,4,8,16,32"  # Epochs to evaluate at (replaces multiple runs)
ADAPTERS=("full_ft")  # Test both adaptation methods
LORA_RANKS=(0)  # Different LoRA ranks

# Training parameters
BATCH_SIZES=(1)  # Small batch size for memory efficiency with long contexts
GRADIENT_ACCUMULATION_STEPS=(1)  # Simulate larger batch sizes
MAX_TRAIN_EXAMPLES=(1)  # Number of problems to process with TTT

# Generation parameters
REASONING_BUDGETS=(0)  # Limited reasoning for faster training
ANSWER_BUDGETS=(512)  # Reasonable answer lengths
EVAL_BATCH_SIZE=1  # Very small eval batch due to long contexts

# Model configuration
# MODELS=("Qwen/Qwen3-4B")
MODELS=("Qwen/Qwen3-1.7B")
# MODELS=("meta-llama/Llama-3.1-8B-Instruct")
# MODELS=("meta-llama/Llama-3.2-3B-Instruct")
CONTEXT_LENGTH=16384  # Long context for ZeroSCROLLS
QUESTION_LENGTH=1024  # Longer questions due to instructions

# Fixed parameters
MODE="ttt"
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
LR_SCHEDULE="constant"  # Cosine schedule for short training
WEIGHT_DECAY=0.01
MAX_GRAD_NORM=1.0
# Available GPUs (indices 2-7)
AVAILABLE_GPUS=(2 3 4 5 6 7)
WARMUP_STEPS=0  # Few warmup steps for short training
NUM_PROBLEMS=50  # Limit number of problems for faster evaluation

# Create logs directory if it doesn't exist
mkdir -p logs

# Map SLURM_ARRAY_TASK_ID to configuration
# Each array task runs one dataset
DATASET_INDEX=$SLURM_ARRAY_TASK_ID
DATASET="${ZEROSCROLLS_DATASETS[$DATASET_INDEX]}"

echo "=========================================="
echo "SLURM Array Job: ZeroSCROLLS TTT"
echo "Task ID: $SLURM_ARRAY_TASK_ID"
echo "Dataset: $DATASET"
echo "Hostname: $(hostname)"
echo "GPU: $CUDA_VISIBLE_DEVICES"
echo "=========================================="

# Run experiment for the assigned dataset with all parameter combinations
for model_name in "${MODELS[@]}"; do
    for adapter in "${ADAPTERS[@]}"; do
        for lr in "${LEARNING_RATES[@]}"; do
            for max_train_examples in "${MAX_TRAIN_EXAMPLES[@]}"; do
                for batch_size in "${BATCH_SIZES[@]}"; do
                    for grad_accum in "${GRADIENT_ACCUMULATION_STEPS[@]}"; do
                        for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
                            for answer_budget in "${ANSWER_BUDGETS[@]}"; do
                                    
                                    # Set LoRA rank (only used if adapter is lora)
                                    if [ "$adapter" == "lora" ]; then
                                        lora_ranks_to_test=(8 16)
                                    else
                                        lora_ranks_to_test=(16)  # Default value, not used
                                    fi
                                    
                                    for lora_r in "${lora_ranks_to_test[@]}"; do
                                        echo ""
                                        echo "----------------------------------------"
                                        echo "Running configuration:"
                                        echo "  Dataset: $DATASET"
                                        echo "  Model: $model_name"
                                        echo "  Adapter: $adapter"
                                        echo "  Learning Rate: $lr"
                                        echo "  Max Epochs: $MAX_EPOCHS"
                                        echo "  Epoch Checkpoints: $EPOCH_CHECKPOINTS"
                                        echo "  Problems to Process: $max_train_examples"
                                        echo "  Batch Size: $batch_size"
                                        echo "  Grad Accumulation: $grad_accum"
                                        echo "  LoRA Rank: $lora_r"
                                        echo "  Reasoning Budget: $reasoning_budget"
                                        echo "  Answer Budget: $answer_budget"
                                        echo "----------------------------------------"
                                        
                                        # Create output directory name
                                        output_dir="results/zeroscrolls_ttt_${DATASET}_$(basename $model_name)_${adapter}_lr${lr}_${LR_SCHEDULE}_maxe${MAX_EPOCHS}_n${max_train_examples}_bs${batch_size}_ga${grad_accum}_r${lora_r}"
                                        mkdir -p $output_dir

                                        python scripts/run_experiment.py \
                                            --mode "$MODE" \
                                            --dataset-type zeroscrolls \
                                            --zeroscrolls-datasets "$DATASET" \
                                            --zeroscrolls-num-problems "$NUM_PROBLEMS" \
                                            --model-name "$model_name" \
                                            --adapter "$adapter" \
                                            --learning-rate "$lr" \
                                            --num-epochs "$MAX_EPOCHS" \
                                            --epoch-checkpoints "$EPOCH_CHECKPOINTS" \
                                            --batch-size "$batch_size" \
                                            --gradient-accumulation-steps "$grad_accum" \
                                            --eval-batch-size "$EVAL_BATCH_SIZE" \
                                            --lora-r "$lora_r" \
                                            --lora-alpha $((lora_r * 2)) \
                                            --lora-dropout 0.1 \
                                            --lora-target-modules "q_proj,v_proj,k_proj,o_proj" \
                                            --max-context-examples 0 \
                                            --max-context-length "$CONTEXT_LENGTH" \
                                            --max-question-length "$QUESTION_LENGTH" \
                                            --max-solution-length "$answer_budget" \
                                            --reasoning-budget "$reasoning_budget" \
                                            --answer-budget "$answer_budget" \
                                            --lr-schedule "$LR_SCHEDULE" \
                                            --warmup-steps "$WARMUP_STEPS" \
                                            --weight-decay "$WEIGHT_DECAY" \
                                            --max-grad-norm "$MAX_GRAD_NORM" \
                                            --max-train-examples "$max_train_examples" \
                                            --num-samples "$NUM_SAMPLES" \
                                            --wandb-mode "$WANDB_MODE" \
                                            --wandb-project "ttt-zeroscrolls" \
                                            --output-dir "$output_dir" \
                                            --use-enhanced-eval \
                                            --use-vllm-for-eval \
                                            --seed 42 \
                                            2>&1 | tee "$output_dir/log.txt"
                                    done
                                done
                            done
                        done
                    done
                done
            done
        done
    done
done

rm -r $output_dir/step_*

echo ""
echo "🎯 All ZeroSCROLLS per-problem TTT jobs submitted!"
echo "Results will be saved in results/zeroscrolls_ttt_* directories"
echo ""
echo "📊 Expected results structure:"
echo "  - Individual problem results: results/*/zeroscrolls_per_problem/problem_*_results.json"
echo "  - Aggregated results: results/*/zeroscrolls_per_problem/aggregated_results.json"
echo ""
echo "💡 Key features of ZeroSCROLLS TTT:"
echo "  - Each problem trains individually on its own context"
echo "  - Model resets between problems for isolation"
echo "  - Comprehensive per-problem and aggregate metrics" 