#!/usr/bin/env bash

#SBATCH --job-name=longbench_frozen_kv
#SBATCH --output=/dev/null
#SBATCH --error=/dev/null
#SBATCH --time=72:00:00
#SBATCH --partition=genai_interns
#SBATCH --account=genai_interns
#SBATCH --qos=genai_interns
#SBATCH --gpus-per-node=1
#SBATCH --nodes=1
#SBATCH --array=0-7

set -euo pipefail

# LongBench-v2 Frozen-KV Query-Only TTT runner
# Usage: sbatch scripts/run_frozen_kv_longbench_v2.sh

# DOMAIN_INDEX=${0:-0}

# Models to evaluate
MODELS=(
  "Qwen/Qwen3-1.7B"
  # "meta-llama/Llama-3.2-3B-Instruct"
)

# LongBench-v2 domains (use the exact strings expected by run_experiment.py)
# All domains enabled for parallel GPU execution
LONGBENCH_V2_DOMAINS=(
  "Single-Document QA"
  "Multi-Document QA"
  "Long In-context Learning"
  "Long-dialogue History Understanding"
  "Code Repository Understanding"
  "Long Structured Data Understanding"
)

# Frozen-KV knobs - optimized for 8x H100 GPUs with Accelerate
SAMPLE_M_LIST=(64)    # Increased for better GPU utilization across 8 GPUs
LORA_RANK_LIST=(16)    # Increased rank for better performance
NUM_STEPS_LIST=(4 8 16 32)    # Increased steps for better convergence
KV_DTYPES=(bf16)       # use bf16 to save VRAM
LR_FROZEN_KV_LIST=(3e-5 1e-5 1e-6)  # Higher LR for larger effective batch

# Dataset/problem sizing
NUM_PROBLEMS=50
CONTEXT_LENGTH=16384
QUESTION_LENGTH=512
ANSWER_BUDGET=512

# General settings - optimized for 8x H100 with Accelerate
MODE="ttt"
WANDB_MODE="disabled"
EVAL_BATCH_SIZE=8   # Increased for better H100 utilization (8 per GPU = 64 total)
BATCH_SIZE=4        # Increased for better throughput (4 per GPU = 32 total)
GRAD_ACCUM=1        # Reduced since we have higher per-GPU batch
SEED=42

# Optimized CUDA memory settings for H100 multi-GPU setup
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:1024,expandable_segments:True,backend:cudaMallocAsync
export CUDA_LAUNCH_BLOCKING=0  # Enable async CUDA operations

# Optional: Set to true if you have vLLM enabled for faster eval
USE_VLLM=true

# Create logs directory if it doesn't exist
mkdir -p logs

# Map SLURM_ARRAY_TASK_ID to configuration
# Each array task runs one domain
DOMAIN_INDEX=$SLURM_ARRAY_TASK_ID

DOMAIN="${LONGBENCH_V2_DOMAINS[$DOMAIN_INDEX]}"
CUDA_VISIBLE_DEVICES=0

echo "=========================================="
echo "SLURM Array Job: LongBench-v2 Frozen-KV TTT"
echo "Task ID: $DOMAIN_INDEX"
echo "Domain: $DOMAIN"
echo "Hostname: $(hostname)"
echo "GPU: $CUDA_VISIBLE_DEVICES"
echo "=========================================="

# Run experiment for the assigned domain with all parameter combinations
for model_name in "${MODELS[@]}"; do
  for sample_m in "${SAMPLE_M_LIST[@]}"; do
    for lora_rank in "${LORA_RANK_LIST[@]}"; do
      for steps in "${NUM_STEPS_LIST[@]}"; do
        for kv_dtype in "${KV_DTYPES[@]}"; do
          for lr_fk in "${LR_FROZEN_KV_LIST[@]}"; do
            domain_clean=$(echo "$DOMAIN" | tr ' ' '_' | tr '-' '_' | tr '[:upper:]' '[:lower:]')
            out_dir="results/longbench_v2/frozen_kv/${domain_clean}/$(basename "$model_name")_M${sample_m}_r${lora_rank}_s${steps}_${kv_dtype}_lr${lr_fk}"
            mkdir -p "$out_dir"

            echo "----------------------------------------"
            echo "Running configuration:"
            echo "  Model: $model_name"
            echo "  Domain: $DOMAIN"
            echo "  M: $sample_m  Rank: $lora_rank  Steps: $steps  DType: $kv_dtype  LR: $lr_fk"
            echo "  Output: $out_dir"
            echo "----------------------------------------"

            CMD=(
              python scripts/run_experiment.py
              --mode "$MODE"
              --dataset-type longbench-v2
              --longbench-v2-domains "$DOMAIN"
              --longbench-v2-num-problems "$NUM_PROBLEMS"
              --model-name "$model_name"
              --adapter lora
              --batch-size "$BATCH_SIZE"
              --gradient-accumulation-steps "$GRAD_ACCUM"
              --eval-batch-size "$EVAL_BATCH_SIZE"
              --max-context-examples 0
              --max-context-length "$CONTEXT_LENGTH"
              --max-question-length "$QUESTION_LENGTH"
              --max-solution-length "$ANSWER_BUDGET"
              --answer-budget "$ANSWER_BUDGET"
              --use-enhanced-eval
              --seed "$SEED"
              --wandb-mode "$WANDB_MODE"
              --wandb-project "ttt-longbench-v2-fkv"
              --output-dir "$out_dir"
              --use-frozen-kv
              --sample-M "$sample_m"
              --lora-rank "$lora_rank"
              --num-epochs "$steps"
              --kv-dtype "$kv_dtype"
              --learning-rate-frozen-kv "$lr_fk"
            )

            if [ "$USE_VLLM" = true ]; then
              CMD+=(--use-vllm-for-eval)
            fi

            "${CMD[@]}" 2>&1 | tee "$out_dir/log.txt"
          done
        done
      done
    done
  done
done

echo "All LongBench-v2 Frozen-KV TTT runs finished."


