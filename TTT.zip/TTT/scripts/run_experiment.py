import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Dict, Any

# Add src to path
sys.path.append(str(Path(__file__).parent.parent))

# Set up environment before importing other modules
import setup_env

from src.models.ttt_llm import TTTLanguageModel
from src.data.load_dataset import LoadDataset
from src.data.data_loader import get_data_loader
from src.utils.logging_utils import WandBLogger
from src.utils.evaluation_utils import generate_and_evaluate
from src.utils.rope_utils import maybe_apply_yarn_to_hf_model

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_config_from_args(args) -> Dict[str, Any]:
    """Create configuration dictionary from command-line arguments."""
    if args.dataset_type == 'zeroscrolls':
        # ZeroSCROLLS specific configuration
        datasets = args.zeroscrolls_datasets.split(',') if args.zeroscrolls_datasets else ['gov_report']
        
        base_zeroscrolls_config = {
            'datasets': datasets,
            'num_problems': args.zeroscrolls_num_problems if args.zeroscrolls_num_problems > 0 else None,
            'random_seed': args.seed
        }
        
        # Use 'validation' split for both training/context and evaluation
        train_split = base_zeroscrolls_config.copy()
        train_split['split'] = 'validation'
        
        eval_split = base_zeroscrolls_config.copy()
        eval_split['split'] = 'validation'
        
    elif args.dataset_type == 'longbench-v2':
        # LongBench-v2 specific configuration
        domains = args.longbench_v2_domains.split(',') if args.longbench_v2_domains else None
        
        base_longbench_v2_config = {
            'domains': domains,
            'num_problems': args.longbench_v2_num_problems if args.longbench_v2_num_problems > 0 else None,
            'random_seed': args.seed
        }
        
        # LongBench-v2 only has 'train' split
        train_split = base_longbench_v2_config.copy()
        train_split['split'] = 'train'
        
        eval_split = base_longbench_v2_config.copy()
        eval_split['split'] = 'train'
        
    elif args.dataset_type.startswith('bank-transactions'):
        # Bank Transactions specific configuration
        base_bank_transactions_config = {
            'dataset_type': args.dataset_type.split('-')[-1],
            'num_problems': args.bank_transactions_num_problems if args.bank_transactions_num_problems > 0 else None,
            'random_seed': args.seed
        }
        
        # Bank Transactions only has 'train' split
        train_split = base_bank_transactions_config.copy()
        train_split['split'] = 'train'
        
        eval_split = base_bank_transactions_config.copy()
        eval_split['split'] = 'train'
        
    elif args.dataset_type == 'olmo-bugs' or args.dataset_type.startswith('olmo-bugs-'):
        # OLMo Bugs specific configuration (original or with context size)
        base_olmo_bugs_config = {
            'num_problems': args.olmo_bugs_num_problems if args.olmo_bugs_num_problems > 0 else None,
            'random_seed': args.seed
        }
        
        # OLMo Bugs only has 'train' split
        train_split = base_olmo_bugs_config.copy()
        train_split['split'] = 'train'
        
        eval_split = base_olmo_bugs_config.copy()
        eval_split['split'] = 'train'
    else:
        raise ValueError(f"Unknown dataset type: {args.dataset_type}")
    
    config = {
        'mode': args.mode,
        'model': {
            'name': args.model_name,
            'device': args.device,
            'dtype': args.dtype,
            'context_parallel': args.context_parallel,
            'hf_device_map': args.hf_device_map,
            'hf_max_memory_gib': args.hf_max_memory_gib,
            'generation_config': {
                'do_sample': False,
            }
        },
        'eval': {
            'batch_size': args.eval_batch_size,
            'reasoning_budget': args.reasoning_budget,
            'answer_budget': args.answer_budget,
            'generation_config': {
                'do_sample': False,
            },
            'use_enhanced': args.use_enhanced_eval,
            'use_vllm_for_eval': args.use_vllm_for_eval,
            'tensor_parallel_size': args.vllm_tensor_parallel_size,
        },
        'ttt': {
            'learning_rate': args.learning_rate,
            'num_epochs': args.num_epochs,
            'batch_size': args.batch_size,
            'gradient_accumulation_steps': args.gradient_accumulation_steps,
            'max_grad_norm': args.max_grad_norm,
            'lr_schedule': args.lr_schedule,
            'warmup_steps': args.warmup_steps,
            'weight_decay': args.weight_decay,
            'betas': (args.beta1, args.beta2),
            'epoch_checkpoints': [int(e.strip()) for e in args.epoch_checkpoints.split(',')] if args.epoch_checkpoints else None,
            'adaptation': {
                'method': args.adapter,
                'lora_r': args.lora_r,
                'lora_alpha': args.lora_alpha,
                'lora_dropout': args.lora_dropout,
                'lora_target_modules': args.lora_target_modules.split(',') if args.lora_target_modules else ["q_proj", "v_proj"]
            },
            # Context batchification parameters
            'use_context_batchification': args.use_context_batchification,
            'context_batch_size': args.context_batch_size,
            'min_chunk_length': args.min_chunk_length,
            # Frozen KV parameters
            'use_frozen_kv': args.use_frozen_kv,
            'frozen_kv_sample_m': args.frozen_kv_sample_m,
            'frozen_kv_lora_rank': args.frozen_kv_lora_rank,
            'frozen_kv_num_steps': args.frozen_kv_num_steps,
            'frozen_kv_dtype': args.frozen_kv_dtype,
            'frozen_kv_lr': args.frozen_kv_lr,
        },
        'data': {
            'dataset_type': args.dataset_type,
            'train_split': train_split,
            'eval_split': eval_split,
            'max_context_examples': args.max_context_examples,
            'max_train_examples': args.max_train_examples,
            'max_context_length': args.max_context_length,
            'max_question_length': args.max_question_length,
            'max_solution_length': args.max_solution_length,
            'max_length': args.max_context_length + args.max_question_length + args.reasoning_budget,
        },
        'generation': {
            'reasoning_budget': args.reasoning_budget,
            'answer_budget': args.answer_budget,
            'num_samples': args.num_samples
        },
        'seed': args.seed,
        'output_dir': args.output_dir,
        'wandb': {
            'project': args.wandb_project,
            'mode': args.wandb_mode
        },
        'checkpoint_path': args.checkpoint_path,
    }

    # Add new concise knobs only if provided to avoid overriding defaults
    if getattr(args, 'sample_M', None) is not None:
        config['ttt']['sample_M'] = args.sample_M
    if getattr(args, 'lora_rank_kv', None) is not None:
        config['ttt']['lora_rank'] = args.lora_rank_kv
    if getattr(args, 'num_steps_kv', None) is not None:
        config['ttt']['num_steps'] = args.num_steps_kv
    if getattr(args, 'kv_dtype_alias', None) is not None:
        config['ttt']['dtype'] = args.kv_dtype_alias
    if getattr(args, 'learning_rate_frozen_kv', None) is not None:
        config['ttt']['learning_rate_frozen_kv'] = args.learning_rate_frozen_kv
    
    return config

def run_experiment(config: Dict[str, Any]):
    """Run the experiment with the given configuration."""
    # Initialize model with Accelerate
    model = TTTLanguageModel(
        model_name=config['model']['name'],
        dtype=config['model']['dtype'],
        context_parallel=config['model'].get('context_parallel', False),
        hf_device_map=config['model'].get('hf_device_map', None),
        hf_max_memory_gib=config['model'].get('hf_max_memory_gib', None),
    )
    
    if model.is_main_process:
        logger.info(f"Initializing model: {config['model']['name']} with dtype: {config['model']['dtype']}")
    
    # Initialize wandb logger only on main process
    wandb_logger = None
    if model.is_main_process:
        wandb_logger = WandBLogger(
            project=config['wandb']['project'],
            config=config,
            mode=config['wandb']['mode'],
            name=config['output_dir'].split('/')[-1],
            group=f"{config['data']['dataset_type']}"
        )
    
    # Load data
    data_loader = get_data_loader(config['data']['dataset_type'])
    
    # All datasets use per-problem TTT approach
    train_problems = data_loader.load_data(**config['data']['train_split'])
    context_problems = data_loader.load_data(**config['data']['train_split'])
    eval_problems = data_loader.load_data(**config['data']['eval_split'])
    
    if model.is_main_process:
        logger.info(f"Loaded {len(train_problems)} training problems and {len(eval_problems)} evaluation problems")
    
    # Output directories  
    output_dir = Path(config['output_dir'])
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save config only on main process
    if model.is_main_process:
        with open(output_dir / 'config.json', 'w') as f:
            json.dump(config, f, indent=2)
    
    # Create evaluation dataset
    eval_dataset = LoadDataset(
        model_name=config['model']['name'],
        problems=eval_problems,
        tokenizer=model.tokenizer,
        max_context_examples=0,
        max_context_length=config['data']['max_context_length'],
        max_question_length=config['data']['max_question_length'],
        max_solution_length=config['data']['max_solution_length'],
        context_problems=None,
        eval_mode=True,
        reasoning_mode=config['eval']['reasoning_budget'] > 0,
        create_long_context_sequence=False,
    )
    if model.is_main_process:
        print(f"Eval dataset length: {len(eval_dataset)}")
    
    step = None
    if config['mode'] == 'ttt' and not config['checkpoint_path']:
        # Check dataset type for appropriate TTT method
        if not hasattr(eval_dataset, 'problems') or not eval_dataset.problems:
            raise ValueError("Dataset requires problems for per-problem TTT")
            
        sample_problem = eval_dataset.problems[0]
        dataset_name = sample_problem.get('dataset', 'unknown')
        
        # Determine dataset type
        is_zeroscrolls = dataset_name in [
            'gov_report', 'summ_screen_fd', 'qmsum', 'squality', 'qasper', 
            'narrative_qa', 'quality', 'musique', 'space_digest', 'book_sum_sort'
        ]
        is_longbench_v2 = dataset_name.startswith('longbench_v2_')
        is_olmo_bugs = dataset_name.startswith('olmo_bugs')
        is_bank_transactions = dataset_name.startswith('bank_transactions')
        
        if is_zeroscrolls or is_longbench_v2 or is_olmo_bugs:
            if is_zeroscrolls:
                dataset_type = "ZeroSCROLLS"
            elif is_longbench_v2:
                dataset_type = "LongBench-v2"
            else:
                dataset_type = "OLMo Bugs"
            
            logger.info(f"Starting {dataset_type} per-problem test-time training")
            model.test_time_train_zeroscrolls(
                eval_dataset=eval_dataset,
                config=config['ttt'],
                logger=wandb_logger,
                max_length=config['data']['max_length'],
                eval_config=config['eval'],
                output_dir=output_dir,
                use_enhanced_eval=config['eval']['use_enhanced'],
                use_vllm_for_eval=config['eval']['use_vllm_for_eval'],
                num_problems=None,
                use_context_batchification=config['ttt'].get('use_context_batchification', False),
                context_batch_size=config['ttt'].get('context_batch_size', 128),
                min_chunk_length=config['ttt'].get('min_chunk_length', 256),
            )
        elif is_bank_transactions:
            logger.info("Starting Bank Transactions per-problem test-time training")
            model.test_time_train_bank_transactions(
                eval_dataset=eval_dataset,
                config=config['ttt'],
                logger=wandb_logger,
                max_length=config['data']['max_length'],
                eval_config=config['eval'],
                output_dir=output_dir,
                use_enhanced_eval=config['eval']['use_enhanced'],
                use_vllm_for_eval=config['eval']['use_vllm_for_eval'],
                num_problems=config['data'].get('max_train_examples', None),
            )
        else:
            raise ValueError(f"Unsupported dataset type: {dataset_name}")
            
    elif config['checkpoint_path']:
        model.load_checkpoint(config['checkpoint_path'])
        step = int(config['checkpoint_path'].split('step_')[-1])
        print(f"Loaded checkpoint: {config['checkpoint_path']}")
 
    # Generate solutions for evaluation problems (context_only mode or checkpoint evaluation)
    if config['mode'] == 'context_only' or config['checkpoint_path']:
        logger.info("Generating solutions for evaluation problems")
        
        # Hint YaRN scaling before evaluation generation to avoid warnings
        maybe_apply_yarn_to_hf_model(model, needed_total_len=config['data']['max_length'], eval_config=config['eval'])

        results = generate_and_evaluate(
            model=model,
            eval_dataset=eval_dataset,
            eval_config=config['eval'],
            max_length=config['data']['max_length'],
            results_file=output_dir / 'results.json',
            use_vllm_for_eval=config['eval']['use_vllm_for_eval'],
            checkpoint_path=config['checkpoint_path'],
            use_enhanced=config['eval']['use_enhanced']
        )

        # Log to wandb
        if wandb_logger is not None:
            dataset_name = config['data']['dataset_type']
            if dataset_name == 'zeroscrolls':
                dataset_name = config['data']['eval_split']['datasets'][-1]
            elif dataset_name == 'longbench-v2':
                domain_name = config['data']['eval_split']['domains'][-1]
                dataset_name = f"longbench_v2_{domain_name.lower().replace(' ', '_').replace('-', '_')}"
            
            for metric, value in results["metrics"].items():
                wandb_logger.log_metric(f"eval/{dataset_name}/{metric}", value, step=step)

def main():
    parser = argparse.ArgumentParser(description='Run TTT experiments')
    
    # Mode and adapter
    parser.add_argument('--mode', choices=['context_only', 'ttt'], required=True,
                       help='Experiment mode: context_only (baseline) or ttt (test-time training)')
    parser.add_argument('--adapter', choices=['full_ft', 'lora'], default='lora',
                       help='Adaptation method for TTT')
    
    # Model configuration
    parser.add_argument('--model-name', default='Qwen/Qwen2.5-1.5B-Instruct',
                       help='HuggingFace model name')
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--dtype', choices=['float16', 'bfloat16', 'float32'], default='bfloat16',
                       help='Data type for model parameters')
    
    # Generation configuration
    parser.add_argument('--reasoning-budget', type=int, default=512,
                       help='Maximum tokens for reasoning generation')
    parser.add_argument('--answer-budget', type=int, default=512,
                       help='Maximum tokens for answer generation')
    parser.add_argument('--num-samples', type=int, default=1,
                       help='Number of samples to generate per problem')
    
    # Training configuration
    parser.add_argument('--learning-rate', type=float, default=5e-4,
                       help='Learning rate for TTT')
    parser.add_argument('--num-epochs', type=int, default=4,
                       help='Number of training epochs for TTT')
    parser.add_argument('--epoch-checkpoints', type=str, default=None,
                       help='Comma-separated list of epoch numbers to evaluate at (e.g., "1,2,4")')
    parser.add_argument('--batch-size', type=int, default=1,
                       help='Training batch size')
    parser.add_argument('--eval-batch-size', type=int, default=4,
                       help='Evaluation batch size')
    parser.add_argument('--gradient-accumulation-steps', type=int, default=4,
                       help='Number of gradient accumulation steps')
    parser.add_argument('--max-grad-norm', type=float, default=1.0,
                       help='Maximum gradient norm for clipping')
    
    # Learning rate scheduling
    parser.add_argument('--lr-schedule', choices=['cosine', 'linear', 'constant'], default='cosine', 
                       help='Learning rate schedule')
    parser.add_argument('--warmup-steps', type=int, default=10, 
                       help='Number of warmup steps')
    parser.add_argument('--weight-decay', type=float, default=0.01, 
                       help='Weight decay for AdamW optimizer')
    parser.add_argument('--beta1', type=float, default=0.9)
    parser.add_argument('--beta2', type=float, default=0.999)
    
    # LoRA configuration
    parser.add_argument('--lora-r', type=int, default=16,
                       help='LoRA rank')
    parser.add_argument('--lora-alpha', type=int, default=32,
                       help='LoRA alpha')
    parser.add_argument('--lora-dropout', type=float, default=0.1,
                       help='LoRA dropout')
    parser.add_argument('--lora-target-modules', default='q_proj,v_proj,k_proj,o_proj',
                       help='Comma-separated list of modules to apply LoRA to')
    
    # Dataset configuration
    olmo_bugs_context_sizes = [20, 70, 120, 170, 220, 270, 320, 370, 420, 470, 520, 570, 620, 670, 720, 770, 820, 870, 920, 970]
    olmo_bugs_dataset_types = [f'olmo-bugs-{size}' for size in olmo_bugs_context_sizes]
    
    all_dataset_types = [
        'zeroscrolls', 
        'longbench-v2',
        'bank-transactions-nop_5', 'bank-transactions-nop_25', 'bank-transactions-nop_55',
        'bank-transactions-nop_75', 'bank-transactions-nop_95',
        'bank-transactions-nop_250', 'bank-transactions-nop_500',
        'olmo-bugs'
    ] + olmo_bugs_dataset_types

    parser.add_argument('--dataset-type', choices=all_dataset_types, required=True,
                       help='Dataset to use')
    parser.add_argument('--max-train-examples', type=int, default=512,
                       help='Maximum number of training examples')
    parser.add_argument('--max-context-examples', type=int, default=0,
                       help='Maximum number of context examples')
    parser.add_argument('--max-context-length', type=int, default=16384,
                       help='Maximum context length in tokens')
    parser.add_argument('--max-question-length', type=int, default=1024,
                       help='Maximum question length in tokens')
    parser.add_argument('--max-solution-length', type=int, default=1024,
                       help='Maximum solution length in tokens')
    
    # ZeroSCROLLS specific configuration
    parser.add_argument('--zeroscrolls-datasets', default='gov_report',
                       help='Comma-separated list of ZeroSCROLLS datasets')
    parser.add_argument('--zeroscrolls-num-problems', type=int, default=-1,
                       help='Maximum number of problems per dataset (-1 for all)')
    
    # LongBench-v2 specific configuration
    parser.add_argument('--longbench-v2-domains', default=None,
                       help='Comma-separated list of LongBench-v2 domains (None for all)')
    parser.add_argument('--longbench-v2-num-problems', type=int, default=-1,
                       help='Maximum number of problems total (-1 for all)')
    
    # Bank Transactions specific configuration
    parser.add_argument('--bank-transactions-num-problems', type=int, default=-1,
                       help='Maximum number of Bank Transactions problems (-1 for all 500)')
    
    # OLMo Bugs specific configuration
    parser.add_argument('--olmo-bugs-num-problems', type=int, default=-1,
                       help='Maximum number of OLMo Bugs problems (-1 for all 10)')
    
    # Other configuration
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--output-dir', default='results',
                       help='Output directory for results and checkpoints')
    parser.add_argument('--wandb-project', default='ttt',
                       help='Weights & Biases project name')
    parser.add_argument('--wandb-mode', choices=['online', 'offline', 'disabled'], default='disabled',
                       help='Weights & Biases logging mode (default: disabled for offline mode)')  # [OFFLINE MODE] 默认禁用 wandb
    
    # Checkpoint evaluation
    parser.add_argument('--checkpoint-path', help='Path to checkpoint to evaluate', default=None)
    
    # Evaluation options
    parser.add_argument('--use-enhanced-eval', action='store_true', default=True,
                       help='Use enhanced evaluation (faster math comparison)')
    parser.add_argument('--use-vllm-for-eval', action='store_true', default=False,
                       help='Use vLLM for evaluation (faster generation)')
    parser.add_argument('--vllm-tensor-parallel-size', type=int, default=None,
                       help='Number of GPUs for tensor parallelism in vLLM')
    
    # Context batchification (for memory efficiency)
    parser.add_argument('--use-context-batchification', action='store_true', default=False,
                       help='Enable context batchification for long contexts')
    parser.add_argument('--context-batch-size', type=int, default=128,
                       help='Number of chunks for context batchification')
    parser.add_argument('--min-chunk-length', type=int, default=256,
                       help='Minimum tokens per chunk')
    
    # Frozen KV cache arguments (efficient long-context TTT)
    parser.add_argument('--use-frozen-kv', action='store_true', default=False,
                       help='Enable frozen KV cache TTT for long contexts')
    parser.add_argument('--frozen-kv-sample-m', type=int, default=64,
                       help='Number of token positions to sample per TTT step')
    parser.add_argument('--frozen-kv-lora-rank', type=int, default=16,
                       help='LoRA rank for frozen KV training')
    parser.add_argument('--frozen-kv-num-steps', type=int, default=8,
                       help='Number of SGD steps for frozen KV training')
    parser.add_argument('--frozen-kv-dtype', choices=['fp16', 'bf16'], default='bf16',
                       help='Data type for cached KV tensors')
    parser.add_argument('--frozen-kv-lr', type=float, default=3e-4,
                       help='Learning rate for frozen KV training')

    # Concise alias knobs (optional overrides)
    parser.add_argument('--sample-M', dest='sample_M', type=int, default=None,
                        help='Alias for frozen_kv_sample_m')
    parser.add_argument('--lora-rank', dest='lora_rank_kv', type=int, default=None,
                        help='Alias for frozen_kv_lora_rank')
    parser.add_argument('--kv-dtype', dest='kv_dtype_alias', choices=['fp16', 'bf16'], default=None,
                        help='Alias for frozen_kv_dtype')
    parser.add_argument('--learning-rate-frozen-kv', dest='learning_rate_frozen_kv', type=float, default=None,
                        help='Alias for frozen_kv_lr')

    # Context parallelism / HF sharding options
    parser.add_argument('--context-parallel', action='store_true', default=False,
                        help='Shard model across GPUs for long-context processing')
    parser.add_argument('--hf-device-map', choices=['auto', 'balanced', 'balanced_low_0'], default=None,
                        help='Device map strategy for sharding')
    parser.add_argument('--hf-max-memory-gib', type=float, default=None,
                        help='Per-GPU max memory in GiB')
    
    args = parser.parse_args()
    
    # Create configuration from arguments
    config = create_config_from_args(args)
    
    # Run experiment
    run_experiment(config)

if __name__ == '__main__':
    main()


