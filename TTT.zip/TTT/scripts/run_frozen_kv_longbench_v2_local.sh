#!/usr/bin/env bash
# LongBench-v2 Frozen-KV Query-Only TTT runner
# Usage: sbatch scripts/run_frozen_kv_longbench_v2.sh

# Models to evaluate
MODELS=(
  # "Qwen/Qwen3-1.7B"
  # "Qwen/Qwen3-4B"
  "Qwen/Qwen3-8B"
  # "meta-llama/Llama-3.2-3B-Instruct"
)

# LongBench-v2 domains (use the exact strings expected by run_experiment.py)
# All domains enabled for parallel GPU execution
LONGBENCH_V2_DOMAINS=(
  "Single-Document QA"
  # "Multi-Document QA"
  # "Long In-context Learning"
  # "Long-dialogue History Understanding"
  # "Code Repository Understanding"
  # "Long Structured Data Understanding"
)

# Frozen-KV knobs - optimized for 8x H100 GPUs with Accelerate
SAMPLE_M_LIST=(32)    # Increased for better GPU utilization across 8 GPUs
LORA_RANK_LIST=(32)    # Increased rank for better performance
NUM_STEPS_LIST=(32)    # Increased steps for better convergence
KV_DTYPES=(bf16)       # use bf16 to save VRAM
LR_FROZEN_KV_LIST=(1e-6)  # Higher LR for larger effective batch

# Dataset/problem sizing
NUM_PROBLEMS=50
CONTEXT_LENGTH=96768
QUESTION_LENGTH=512
REASONING_BUDGET=512
ANSWER_BUDGET=512

# General settings - optimized for 8x H100 with Accelerate
MODE="ttt"
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
EVAL_BATCH_SIZE=1   # Increased for better H100 utilization (8 per GPU = 64 total)
BATCH_SIZE=1        # Increased for better throughput (4 per GPU = 32 total)
GRAD_ACCUM=1        # Reduced since we have higher per-GPU batch
SEED=42

# Optimized CUDA memory settings for H100 multi-GPU setup
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:1024,expandable_segments:True,backend:cudaMallocAsync
export CUDA_LAUNCH_BLOCKING=0  # Enable async CUDA operations

# Optional: Set to true if you have vLLM enabled for faster eval
USE_VLLM=true
# When using vLLM, set tensor parallel size to use multiple GPUs per query
VLLM_TP_SIZE=8

# Create logs directory if it doesn't exist
mkdir -p logs

# Determine available GPU IDs. Use CUDA_VISIBLE_DEVICES if set; otherwise query nvidia-smi.
GPU_IDS=(0 1 2 3 4 5 6 7)
if [[ -n "${CUDA_VISIBLE_DEVICES:-}" ]]; then
  IFS=',' read -r -a GPU_IDS <<< "${CUDA_VISIBLE_DEVICES}"
else
  if command -v nvidia-smi >/dev/null 2>&1; then
    # shellcheck disable=SC2207
    GPU_IDS=($(nvidia-smi --query-gpu=index --format=csv,noheader | tr '\n' ' '))
  else
    GPU_IDS=(0)
  fi
fi

NUM_GPUS=${#GPU_IDS[@]}
NUM_DOMAINS=${#LONGBENCH_V2_DOMAINS[@]}

# if (( NUM_DOMAINS > NUM_GPUS )); then
#   echo "Error: domains (${NUM_DOMAINS}) exceed available GPUs (${NUM_GPUS})." >&2
#   echo "Set CUDA_VISIBLE_DEVICES or reduce domains to run one per GPU in parallel." >&2
#   exit 1
# fi

# # If using vLLM tensor-parallel, require a single domain per run to avoid GPU contention
# if [[ -n "${VLLM_TP_SIZE:-}" && "${USE_VLLM}" = true && ${NUM_DOMAINS} -gt 1 ]]; then
#   echo "Error: When VLLM_TP_SIZE is set (=${VLLM_TP_SIZE}) and USE_VLLM=true, run with a single domain per job to use all GPUs per query." >&2
#   echo "Hint: Set a single entry in LONGBENCH_V2_DOMAINS or invoke this script per-domain." >&2
#   exit 1
# fi

# Launch one background process per domain, each pinned to a unique GPU
pids=()
names=()
for domain in "${LONGBENCH_V2_DOMAINS[@]}"; do
    for model_name in "${MODELS[@]}"; do
      for sample_m in "${SAMPLE_M_LIST[@]}"; do
        for lora_rank in "${LORA_RANK_LIST[@]}"; do
          for steps in "${NUM_STEPS_LIST[@]}"; do
            for kv_dtype in "${KV_DTYPES[@]}"; do
              for lr_fk in "${LR_FROZEN_KV_LIST[@]}"; do
                domain_clean=$(echo "$domain" | tr ' ' '_' | tr '-' '_' | tr '[:upper:]' '[:lower:]')
                out_dir="results/longbench_v2/frozen_kv/${domain_clean}_$(basename "$model_name")_C${CONTEXT_LENGTH}_M${sample_m}_r${lora_rank}_s${steps}_${kv_dtype}_lr${lr_fk}"
                mkdir -p "$out_dir"

                echo "----------------------------------------"
                echo "Running configuration:"
                echo "  Model: $model_name"
                echo "  Domain: $domain"
                echo "  GPU: $GPU_ID"
                echo "  M: $sample_m  Rank: $lora_rank  Steps: $steps  DType: $kv_dtype  LR: $lr_fk"
                echo "  Output: $out_dir"
                echo "----------------------------------------"

                CMD=(
                  python scripts/run_experiment.py
                  --mode "$MODE"
                  --dataset-type longbench-v2
                  --longbench-v2-domains "$domain"
                  --longbench-v2-num-problems "$NUM_PROBLEMS"
                  --model-name "$model_name"
                  --adapter lora
                  --batch-size "$BATCH_SIZE"
                  --gradient-accumulation-steps "$GRAD_ACCUM"
                  --eval-batch-size "$EVAL_BATCH_SIZE"
                  --max-context-examples 0
                  --max-context-length "$CONTEXT_LENGTH"
                  --max-question-length "$QUESTION_LENGTH"
                  --max-solution-length "$ANSWER_BUDGET"
                  --reasoning-budget "$REASONING_BUDGET"
                  --answer-budget "$ANSWER_BUDGET"
                  --use-enhanced-eval
                  --seed "$SEED"
                  --wandb-mode "$WANDB_MODE"
                  --wandb-project "ttt-longbench-v2-fkv"
                  --output-dir "$out_dir"
                  --use-frozen-kv
                  --context-parallel
                  --hf-device-map auto
                  --sample-M "$sample_m"
                  --lora-rank "$lora_rank"
                  --num-epochs "$steps"
                  --kv-dtype "$kv_dtype"
                  --learning-rate-frozen-kv "$lr_fk"
                  --use-vllm-for-eval
                  --vllm-tensor-parallel-size "$VLLM_TP_SIZE"
                )

                # If using tensor-parallel vLLM, run on all listed GPUs; otherwise pin to a single GPU
                if [ -n "$VLLM_TP_SIZE" ] && [ "$USE_VLLM" = true ]; then
                  # Use all visible GPUs for this process (comma-separated)
                  ALL_GPU_CSV=$(IFS=,; echo "${GPU_IDS[*]}")
                  echo "Using all GPUs: $ALL_GPU_CSV"
                  CUDA_VISIBLE_DEVICES="$ALL_GPU_CSV" "${CMD[@]}" 2>&1 | tee "$out_dir/log.txt"
                else
                  CUDA_VISIBLE_DEVICES="$GPU_ID" "${CMD[@]}" 2>&1 | tee "$out_dir/log.txt"
                fi
              done
            done
          done
        done
      done
    done
  done
done

echo "All LongBench-v2 Frozen-KV TTT domain runs finished."
