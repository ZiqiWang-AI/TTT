#!/bin/bash

# OLMo Bugs Context-Only Evaluation Sweep
# Evaluates models on OLMo Bugs datasets with different context sizes without any test-time training
# This sweeps across multiple datasets with varying numbers of code lines

# Generation parameters
REASONING_BUDGETS=(0 512 1024 2048 4096 8192)  # Different reasoning budgets for code analysis
# REASONING_BUDGETS=(4096 8192)  # Different reasoning budgets for code analysis
# REASONING_BUDGETS=(0 512 1024 2048)  # Different reasoning budgets for code analysis
ANSWER_BUDGETS=(256)  # Compact JSON responses expected
EVAL_BATCH_SIZE=1  # Small batch size for careful evaluation

# Model configuration
MODELS=("Qwen/Qwen3-8B")
# MODELS=("Qwen/Qwen3-4B")
# MODELS=("Qwen/Qwen3-8B")
# MODELS=("meta-llama/Llama-3.2-3B-Instruct")
# MODELS=("meta-llama/Llama-3.1-8B-Instruct")

# Context sizes to evaluate (corresponding to different datasets)
# CONTEXT_SIZES=(20 70 120 170 220 270 320 370 420 470 520 570 620 670 720 770 820 870 920 970)
# For quick testing, use a subset:
# CONTEXT_SIZES=(20 120 420 520 620 720 820 920)
# CONTEXT_SIZES=(70 170 220 270 320 370 420)
# CONTEXT_SIZES=(470 570 670 770 870 970)
CONTEXT_SIZES=(10000)

# Fixed parameters
MODE="context_only"
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
NUM_PROBLEMS=30

echo "Starting OLMo Bugs Context-Only Evaluation Sweep"
echo "Models: ${MODELS[*]}"
echo "Context sizes: ${CONTEXT_SIZES[*]}"
echo "Problems per dataset: $NUM_PROBLEMS"

for model_name in "${MODELS[@]}"; do
    for context_size in "${CONTEXT_SIZES[@]}"; do
        for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
            for answer_budget in "${ANSWER_BUDGETS[@]}"; do
                echo ""
                echo "=========================================="
                echo "Submitting OLMo Bugs Context-Only Job:"
                echo "  Model: $model_name"
                echo "  Context Size: $context_size lines"
                echo "  Reasoning Budget: $reasoning_budget"
                echo "  Answer Budget: $answer_budget"
                echo "  Problems: $NUM_PROBLEMS"
                echo "=========================================="
                
                # Create output directory name
                output_dir="results/olmo_bugs_context_$(basename $model_name)_ctx${context_size}_r${reasoning_budget}_a${answer_budget}"
                mkdir -p $output_dir

                # Determine context length based on context size (rough estimate)
                # Each line is roughly 50-100 characters, so multiply by a factor
                CONTEXT_LENGTH=$((context_size * 80))
                # Ensure minimum and maximum context lengths
                if [ $CONTEXT_LENGTH -lt 512 ]; then
                    CONTEXT_LENGTH=512
                elif [ $CONTEXT_LENGTH -gt 32768 ]; then
                    CONTEXT_LENGTH=32768
                fi

                export CUDA_VISIBLE_DEVICES=0
                export VLLM_ALLOW_LONG_MAX_MODEL_LEN=1
                python scripts/run_experiment.py \
                    --mode "$MODE" \
                    --dataset-type "olmo-bugs-${context_size}" \
                    --olmo-bugs-num-problems "$NUM_PROBLEMS" \
                    --model-name "$model_name" \
                    --eval-batch-size "$EVAL_BATCH_SIZE" \
                    --max-context-examples 0 \
                    --max-context-length "$CONTEXT_LENGTH" \
                    --max-question-length 512 \
                    --max-solution-length 256 \
                    --reasoning-budget "$reasoning_budget" \
                    --answer-budget "$answer_budget" \
                    --num-samples "$NUM_SAMPLES" \
                    --wandb-mode "$WANDB_MODE" \
                    --wandb-project "ttt-olmo-bugs-context-sweep" \
                    --output-dir "$output_dir" \
                    --use-enhanced-eval \
                    --use-vllm-for-eval \
                    --vllm-tensor-parallel-size 1 \
                    --context-parallel \
                    --seed 42 \
                    2>&1 | tee "$output_dir/log.txt"
                sleep 2  # Short pause between jobs
            done
        done
    done
done

echo ""
echo "🎯 All OLMo Bugs context-only jobs submitted!"
echo "Results will be saved in results/olmo_bugs_context_* directories"
echo ""
echo "📊 Expected results structure:"
echo "  - Results: results/*/results.json"
echo ""
echo "💡 Key features of OLMo Bugs Context-Only Sweep:"
echo "  - Evaluates base model performance across ${#CONTEXT_SIZES[@]} different context sizes"
echo "  - Context sizes: ${CONTEXT_SIZES[*]} lines"
echo "  - No test-time training, pure in-context learning"
echo "  - JSON response format with bug_location and bug_fix fields"
echo "  - 10 problems per dataset with various bug types"
echo "  - Tests how context size affects model performance on code bug detection"
