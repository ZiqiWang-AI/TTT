#!/bin/bash

# OLMo Bugs Per-Problem Test-Time Training Sweep
# Uses the new per-problem TTT method for OLMo Bugs datasets with different context sizes
# Each of the 10 problems trains individually on its own code context

# Context sizes to evaluate (corresponding to different datasets)
# CONTEXT_SIZES=(20 70 120 170 220 270 320 370 420 470 520 570 620 670 720 770 820 870 920 970)
# For quick testing, use a subset:
CONTEXT_SIZES=(120)

# TTT-specific parameters
LEARNING_RATES=(1e-6)  # Learning rates for code adaptation
MAX_EPOCHS=32  # Maximum epochs to train - evaluations will be done at checkpoints
EPOCH_CHECKPOINTS="2,4,8,12,16,32"  # Epochs to evaluate at
ADAPTERS=("lora")  # LoRA for efficient adaptation on code
# ADAPTERS=("full_ft")  # Full fine-tuning alternative
LORA_RANKS=(32)  # Different LoRA ranks for code adaptation

# Training parameters
BATCH_SIZES=(1)  # Small batch size for per-problem training
GRADIENT_ACCUMULATION_STEPS=(1)  # Effective batch size of 2
MAX_TRAIN_EXAMPLES=(1)  # Number of problems to process with TTT (all 10)

# Generation parameters
REASONING_BUDGETS=(512)  # Reasoning for code analysis
ANSWER_BUDGETS=(256)  # JSON response format
EVAL_BATCH_SIZE=1  # Small eval batch for careful evaluation

# Model configuration
MODELS=("Qwen/Qwen3-1.7B")
# MODELS=("Qwen/Qwen3-4B")
# MODELS=("meta-llama/Llama-3.2-3B-Instruct")
# MODELS=("meta-llama/Llama-3.1-8B-Instruct")

# Frozen KV parameters for efficient code context processing
USE_FROZEN_KV=true
FROZEN_KV_SAMPLE_M=32  # Sample fewer positions for code
FROZEN_KV_LORA_RANK=32  # Smaller rank for frozen KV
FROZEN_KV_NUM_STEPS=32  # More steps for code understanding
FROZEN_KV_LR=1e-6  # Learning rate for frozen KV

# Fixed parameters
MODE="ttt"
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
LR_SCHEDULE="constant"  # Constant schedule for short training
WEIGHT_DECAY=0.01
MAX_GRAD_NORM=1.0
WARMUP_STEPS=0  # No warmup for short training
NUM_PROBLEMS=30  # All 10 OLMo Bugs problems

# Create logs directory if it doesn't exist
mkdir -p logs

echo "=========================================="
echo "Starting OLMo Bugs Per-Problem TTT Sweep"
echo "Context sizes: ${CONTEXT_SIZES[*]}"
echo "Problems per dataset: $NUM_PROBLEMS"
echo "Use Frozen KV: $USE_FROZEN_KV"
echo "Hostname: $(hostname)"
echo "GPU: $CUDA_VISIBLE_DEVICES"
echo "=========================================="

# Run experiment for all parameter combinations
for model_name in "${MODELS[@]}"; do
    for context_size in "${CONTEXT_SIZES[@]}"; do
    for adapter in "${ADAPTERS[@]}"; do
        for lr in "${LEARNING_RATES[@]}"; do
            for max_train_examples in "${MAX_TRAIN_EXAMPLES[@]}"; do
                for batch_size in "${BATCH_SIZES[@]}"; do
                    for grad_accum in "${GRADIENT_ACCUMULATION_STEPS[@]}"; do
                        for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
                            for answer_budget in "${ANSWER_BUDGETS[@]}"; do
                                    
                                    # Set LoRA rank (only used if adapter is lora)
                                    if [ "$adapter" == "lora" ]; then
                                        lora_ranks_to_test=("${LORA_RANKS[@]}")
                                    else
                                        lora_ranks_to_test=(16)  # Default value, not used
                                    fi
                                    
                                    for lora_r in "${lora_ranks_to_test[@]}"; do
                                        echo ""
                                        echo "----------------------------------------"
                                        echo "Running configuration:"
                                        echo "  Model: $model_name"
                                        echo "  Context Size: $context_size lines"
                                        echo "  Adapter: $adapter"
                                        echo "  Learning Rate: $lr"
                                        echo "  Max Epochs: $MAX_EPOCHS"
                                        echo "  Epoch Checkpoints: $EPOCH_CHECKPOINTS"
                                        echo "  Problems to Process: $max_train_examples"
                                        echo "  Batch Size: $batch_size"
                                        echo "  Grad Accumulation: $grad_accum"
                                        echo "  LoRA Rank: $lora_r"
                                        echo "  Reasoning Budget: $reasoning_budget"
                                        echo "  Answer Budget: $answer_budget"
                                        echo "  Use Frozen KV: $USE_FROZEN_KV"
                                        echo "----------------------------------------"
                                        
                                        # Create output directory name
                                        if [ "$USE_FROZEN_KV" == "true" ]; then
                                            frozen_kv_suffix="_fkv_m${FROZEN_KV_SAMPLE_M}_r${FROZEN_KV_LORA_RANK}_s${FROZEN_KV_NUM_STEPS}_lr${FROZEN_KV_LR}"
                                        else
                                            frozen_kv_suffix=""
                                        fi
                                        
                                        output_dir="results/olmo_bugs_ttt_$(basename $model_name)_ctx${context_size}_${adapter}_lr${lr}_${LR_SCHEDULE}_maxe${MAX_EPOCHS}_n${max_train_examples}_bs${batch_size}_ga${grad_accum}_r${lora_r}_rb${reasoning_budget}${frozen_kv_suffix}"
                                        mkdir -p $output_dir

                                        # Build frozen KV arguments
                                        frozen_kv_args=""
                                        if [ "$USE_FROZEN_KV" == "true" ]; then
                                            frozen_kv_args="--use-frozen-kv \
                                                --frozen-kv-sample-m $FROZEN_KV_SAMPLE_M \
                                                --frozen-kv-lora-rank $FROZEN_KV_LORA_RANK \
                                                --frozen-kv-num-steps $FROZEN_KV_NUM_STEPS \
                                                --frozen-kv-lr $FROZEN_KV_LR \
                                                --frozen-kv-dtype bf16"
                                        fi

                                        # Determine context length based on context size (rough estimate)
                                        # Each line is roughly 50-100 characters, so multiply by a factor
                                        CONTEXT_LENGTH=$((context_size * 80))
                                        # Ensure minimum and maximum context lengths
                                        if [ $CONTEXT_LENGTH -lt 512 ]; then
                                            CONTEXT_LENGTH=512
                                        elif [ $CONTEXT_LENGTH -gt 32768 ]; then
                                            CONTEXT_LENGTH=32768
                                        fi

                                        export CUDA_VISIBLE_DEVICES=3
                                        export VLLM_ALLOW_LONG_MAX_MODEL_LEN=1
                                        python scripts/run_experiment.py \
                                            --mode "$MODE" \
                                            --dataset-type "olmo-bugs-${context_size}" \
                                            --olmo-bugs-num-problems "$NUM_PROBLEMS" \
                                            --model-name "$model_name" \
                                            --adapter "$adapter" \
                                            --learning-rate "$lr" \
                                            --num-epochs "$MAX_EPOCHS" \
                                            --epoch-checkpoints "$EPOCH_CHECKPOINTS" \
                                            --batch-size "$batch_size" \
                                            --gradient-accumulation-steps "$grad_accum" \
                                            --eval-batch-size "$EVAL_BATCH_SIZE" \
                                            --lora-r "$lora_r" \
                                            --lora-alpha $((lora_r * 2)) \
                                            --lora-dropout 0.1 \
                                            --lora-target-modules "q_proj,o_proj,k_proj,v_proj" \
                                            --max-context-examples 0 \
                                            --max-context-length "$CONTEXT_LENGTH" \
                                            --max-question-length 512 \
                                            --max-solution-length 256 \
                                            --reasoning-budget "$reasoning_budget" \
                                            --answer-budget "$answer_budget" \
                                            --lr-schedule "$LR_SCHEDULE" \
                                            --warmup-steps "$WARMUP_STEPS" \
                                            --weight-decay "$WEIGHT_DECAY" \
                                            --max-grad-norm "$MAX_GRAD_NORM" \
                                            --max-train-examples "$max_train_examples" \
                                            --num-samples "$NUM_SAMPLES" \
                                            --wandb-mode "$WANDB_MODE" \
                                            --wandb-project "ttt-olmo-bugs-ttt" \
                                            --output-dir "$output_dir" \
                                            --use-enhanced-eval \
                                            --use-vllm-for-eval \
                                            --vllm-tensor-parallel-size 1 \
                                            --context-parallel \
                                            $frozen_kv_args \
                                            --seed 42 \
                                            2>&1 | tee "$output_dir/log.txt"
                                    done
                                done
                            done
                        done
                    done
                done
            done
        done
    done
    done
done

# Clean up intermediate checkpoints to save space
echo "Cleaning up intermediate checkpoints..."
find results/olmo_bugs_ttt_* -name "step_*" -type d -exec rm -rf {} + 2>/dev/null || true

echo ""
echo "🎯 All OLMo Bugs per-problem TTT jobs completed!"
echo "Results will be saved in results/olmo_bugs_ttt_* directories"
echo ""
echo "📊 Expected results structure:"
echo "  - Individual problem results: results/*/results.json"
echo "  - Per-epoch results: results/*/results_epoch_*.json"
echo "  - Aggregated results across all problems"
echo ""
echo "💡 Key features of OLMo Bugs TTT Context Sweep:"
echo "  - Evaluates TTT across ${#CONTEXT_SIZES[@]} different context sizes"
echo "  - Context sizes: ${CONTEXT_SIZES[*]} lines"
echo "  - Each problem trains individually on its own code context"
echo "  - Model resets between problems for isolation"
echo "  - Supports both regular LoRA and frozen KV cache TTT"
echo "  - JSON response format evaluation for bug detection"
echo "  - Comprehensive per-problem and aggregate metrics"
echo "  - Tests how context size affects TTT effectiveness"

