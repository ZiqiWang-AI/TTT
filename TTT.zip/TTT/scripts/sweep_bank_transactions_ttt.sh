#!/bin/bash

# Bank Transactions Per-Problem TTT Sweep
# Performs per-problem test-time training over the transaction context, then evaluates.

# Generation budgets
REASONING_BUDGETS=(128)
ANSWER_BUDGETS=(128)

# Dataset variants (choose one or more)
# DATASET_TYPES=("bank-transactions-nop_95" "bank-transactions-nop_75" "bank-transactions-nop_55" "bank-transactions-nop_25" "bank-transactions-nop_5")
# DATASET_TYPES=("bank-transactions-nop_95")
# DATASET_TYPES=("bank-transactions-nop_250")
DATASET_TYPES=("bank-transactions-nop_25" "bank-transactions-nop_95" "bank-transactions-nop_500")

# Models to evaluate
# MODELS=("Qwen/Qwen3-1.7B" "Qwen/Qwen3-4B" "Qwen/Qwen3-8B" "Qwen/Qwen3-14B")
MODELS=("Qwen/Qwen3-8B")
# MODELS=("Qwen/Qwen3-4B")

# Context sizing
CONTEXT_LENGTH=24576   # Transaction log length
QUESTION_LENGTH=512    # Instruction length

# Fixed parameters
MODE="ttt"
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
NUM_PROBLEMS=50      # per dataset variant
EVAL_BATCH_SIZE=1

# TTT configuration (use LoRA to reduce memory)
adapter="lora"
LEARNING_RATE=1e-6
GRADIENT_ACCUMULATION_STEPS=1

# LoRA configuration for normal TTT
LORA_R=32
LORA_ALPHA=32
LORA_DROPOUT=0.1
LORA_TARGET_MODULES="q_proj,v_proj,k_proj,o_proj"

echo "Starting Bank Transactions TTT Sweep"
echo "Models: ${MODELS[*]}"
echo "Datasets: ${DATASET_TYPES[*]}"
echo "Reasoning Budgets: ${REASONING_BUDGETS[*]}"
echo "Answer Budgets: ${ANSWER_BUDGETS[*]}"

for dataset_type in "${DATASET_TYPES[@]}"; do
  for model_name in "${MODELS[@]}"; do
    for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
      for answer_budget in "${ANSWER_BUDGETS[@]}"; do
        echo ""
        echo "=========================================="
        echo "Submitting Bank Transactions TTT Job:"
        echo "  Dataset: $dataset_type"
        echo "  Model: $model_name"
        echo "  Reasoning Budget: $reasoning_budget"
        echo "  Answer Budget: $answer_budget"
        echo "=========================================="

        # Create output directory name
        model_clean=$(basename $model_name | tr '[:upper:]' '[:lower:]' | tr '.' '_')
        output_dir="results/${dataset_type}_ttt_${model_clean}_r${reasoning_budget}_a${answer_budget}"
        mkdir -p $output_dir

        export CUDA_VISIBLE_DEVICES=0,1,2,3
        export VLLM_ALLOW_LONG_MAX_MODEL_LEN=1
        export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:1024,expandable_segments:True,backend:cudaMallocAsync

        python scripts/run_experiment.py \
          --mode "$MODE" \
          --dataset-type "$dataset_type" \
          --bank-transactions-num-problems "$NUM_PROBLEMS" \
          --model-name "$model_name" \
          --eval-batch-size "$EVAL_BATCH_SIZE" \
          --max-context-examples 0 \
          --max-context-length "$CONTEXT_LENGTH" \
          --max-question-length "$QUESTION_LENGTH" \
          --max-solution-length "$answer_budget" \
          --reasoning-budget "$reasoning_budget" \
          --answer-budget "$answer_budget" \
          --num-samples "$NUM_SAMPLES" \
          --wandb-mode "$WANDB_MODE" \
          --wandb-project "ttt-bank-transactions-ttt" \
          --output-dir "$output_dir" \
          --use-enhanced-eval \
          --use-frozen-kv \
          --num-epochs 32 \
          --context-parallel \
          --hf-device-map auto \
          --hf-max-memory-gib 70 \
          --seed 42 \
          --epoch-checkpoints 4,8,16,32 \
          --adapter "$adapter" \
          --lora-r "$LORA_R" \
          --lora-alpha "$LORA_ALPHA" \
          --lora-dropout "$LORA_DROPOUT" \
          --lora-target-modules "$LORA_TARGET_MODULES" \
          --learning-rate "$LEARNING_RATE" \
          --gradient-accumulation-steps "$GRADIENT_ACCUMULATION_STEPS" \
          --sample-M 64 \
          --lora-rank "$LORA_R" \
          --vllm-tensor-parallel-size 4 \
          2>&1 | tee "$output_dir/log.txt"

        sleep 2
      done
    done
  done
done

echo ""
echo "🎯 All Bank Transactions TTT jobs submitted!"
echo "Results in results/*/results.json"
