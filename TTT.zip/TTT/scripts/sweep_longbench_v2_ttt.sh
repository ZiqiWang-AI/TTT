#!/bin/bash

# LongBench-v2 Per-Problem Test-Time Training Sweep
# Uses the new per-problem TTT method for LongBench-v2 datasets
# Usage: sbatch scripts/sweep_longbench_v2_ttt.sh

# LongBench-v2 domains to test - optimized for 6-GPU parallel processing
# Each domain will run on a separate GPU for maximum parallelization
# LONGBENCH_V2_DOMAINS=("Single-Document QA" "Multi-Document QA" "Long In-context Learning" "Long-dialogue History Understanding" "Code Repository Understanding" "Long Structured Data Understanding")
LONGBENCH_V2_DOMAINS=("Single-Document QA")
# # LONGBENCH_V2_DOMAINS=("Multi-Document QA")
# LONGBENCH_V2_DOMAINS=("Long In-context Learning")
# LONGBENCH_V2_DOMAINS=("Long-dialogue History Understanding")
# LONGBENCH_V2_DOMAINS=("Code Repository Understanding")
# LONGBENCH_V2_DOMAINS=("Long Structured Data Understanding")

# TTT-specific parameters
LEARNING_RATES=(1e-5) # 3e-5 1e-6)  # Higher LRs for short per-problem training
MAX_EPOCHS=32  # Maximum epochs to train - evaluations will be done at checkpoints
EPOCH_CHECKPOINTS="4,8,16,24,32"  # Epochs to evaluate at (replaces multiple runs)
# ADAPTERS=("lora")  # Test both adaptation methods
ADAPTERS=("full_ft")  # Test both adaptation methods
LORA_RANKS=(16)  # Different LoRA ranks

# Training parameters - Optimized for 8x H100 GPUs
BATCH_SIZES=(1)  # Increased batch size for better GPU utilization
GRADIENT_ACCUMULATION_STEPS=(1)  # Effective batch size of 4 per GPU = 32 total
MAX_TRAIN_EXAMPLES=(1)  # Number of problems to process with TTT

# Generation parameters
REASONING_BUDGETS=(0)  # Limited reasoning for faster training
ANSWER_BUDGETS=(512)  # Reasonable answer lengths
EVAL_BATCH_SIZE=1  # Increased eval batch for better throughput

# Model configuration
# MODELS=("Qwen/Qwen3-4B")
MODELS=("Qwen/Qwen3-1.7B")
# MODELS=("meta-llama/Llama-3.1-8B-Instruct")
# MODELS=("meta-llama/Llama-3.2-3B-Instruct")
CONTEXT_LENGTH=96768  # Long context for LongBench-v2
QUESTION_LENGTH=512  # Longer questions due to instructions

# Fixed parameters
MODE="ttt"
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
LR_SCHEDULE="constant"  # Cosine schedule for short training
WEIGHT_DECAY=0.01
MAX_GRAD_NORM=1.0
WARMUP_STEPS=0  # Few warmup steps for short training
# Available GPUs (indices 2-7)
# AVAILABLE_GPUS=(2 3 4 5 6 7)
NUM_PROBLEMS=50  # Total problems to process across all GPUs

# Create logs directory if it doesn't exist
mkdir -p logs

# Map SLURM_ARRAY_TASK_ID to configuration
# Each array task runs one domain
DOMAIN_INDEX=0
DOMAIN="${LONGBENCH_V2_DOMAINS[$DOMAIN_INDEX]}"

echo "=========================================="
echo "Task ID: $DOMAIN_INDEX"
echo "Domain: $DOMAIN"
echo "Hostname: $(hostname)"
echo "GPU: $CUDA_VISIBLE_DEVICES"
echo "=========================================="

# Run experiment for the assigned domain with all parameter combinations
for model_name in "${MODELS[@]}"; do
    for adapter in "${ADAPTERS[@]}"; do
        for lr in "${LEARNING_RATES[@]}"; do
            for max_train_examples in "${MAX_TRAIN_EXAMPLES[@]}"; do
                for batch_size in "${BATCH_SIZES[@]}"; do
                    for grad_accum in "${GRADIENT_ACCUMULATION_STEPS[@]}"; do
                        for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
                            for answer_budget in "${ANSWER_BUDGETS[@]}"; do
                                    
                                    # Set LoRA rank (only used if adapter is lora)
                                    if [ "$adapter" == "lora" ]; then
                                        lora_ranks_to_test=(8 16)
                                    else
                                        lora_ranks_to_test=(16)  # Default value, not used
                                    fi
                                    
                                    for lora_r in "${lora_ranks_to_test[@]}"; do
                                        echo ""
                                        echo "----------------------------------------"
                                        echo "Running configuration:"
                                        echo "  Domain: $DOMAIN"
                                        echo "  Model: $model_name"
                                        echo "  Adapter: $adapter"
                                        echo "  Learning Rate: $lr"
                                        echo "  Max Epochs: $MAX_EPOCHS"
                                        echo "  Epoch Checkpoints: $EPOCH_CHECKPOINTS"
                                        echo "  Problems to Process: $max_train_examples"
                                        echo "  Batch Size: $batch_size"
                                        echo "  Grad Accumulation: $grad_accum"
                                        echo "  LoRA Rank: $lora_r"
                                        echo "  Reasoning Budget: $reasoning_budget"
                                        echo "  Answer Budget: $answer_budget"
                                        echo "----------------------------------------"
                                        
                                        # Create output directory name (replace spaces and special chars)
                                        domain_clean=$(echo "$DOMAIN" | tr ' ' '_' | tr '-' '_' | tr '[:upper:]' '[:lower:]')
                                        output_dir="results/longbench_v2_ttt_${domain_clean}_$(basename $model_name)_${adapter}_lr${lr}_${LR_SCHEDULE}_maxe${MAX_EPOCHS}_n${max_train_examples}_bs${batch_size}_ga${grad_accum}_r${lora_r}"
                                        mkdir -p $output_dir


                                        export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
                                        export VLLM_ALLOW_LONG_MAX_MODEL_LEN=1
                                        python scripts/run_experiment.py \
                                            --mode "$MODE" \
                                            --dataset-type longbench-v2 \
                                            --longbench-v2-domains "$DOMAIN" \
                                            --longbench-v2-num-problems "$NUM_PROBLEMS" \
                                            --model-name "$model_name" \
                                            --adapter "$adapter" \
                                            --learning-rate "$lr" \
                                            --num-epochs "$MAX_EPOCHS" \
                                            --epoch-checkpoints "$EPOCH_CHECKPOINTS" \
                                            --batch-size "$batch_size" \
                                            --gradient-accumulation-steps "$grad_accum" \
                                            --eval-batch-size "$EVAL_BATCH_SIZE" \
                                            --lora-r "$lora_r" \
                                            --lora-alpha $((lora_r * 2)) \
                                            --lora-dropout 0.1 \
                                            --lora-target-modules "q_proj,o_proj" \
                                            --max-context-examples 0 \
                                            --max-context-length "$CONTEXT_LENGTH" \
                                            --max-question-length "$QUESTION_LENGTH" \
                                            --max-solution-length "$answer_budget" \
                                            --reasoning-budget "$reasoning_budget" \
                                            --answer-budget "$answer_budget" \
                                            --lr-schedule "$LR_SCHEDULE" \
                                            --warmup-steps "$WARMUP_STEPS" \
                                            --weight-decay "$WEIGHT_DECAY" \
                                            --max-grad-norm "$MAX_GRAD_NORM" \
                                            --max-train-examples "$max_train_examples" \
                                            --num-samples "$NUM_SAMPLES" \
                                            --wandb-mode "$WANDB_MODE" \
                                            --wandb-project "ttt-longbench-v2" \
                                            --output-dir "$output_dir" \
                                            --use-enhanced-eval \
                                            --use-vllm-for-eval \
                                            --vllm-tensor-parallel-size 8 \
                                            --context-parallel \
                                            --seed 42 \
                                            2>&1 | tee "$output_dir/log.txt"
                                    done
                                done
                            done
                        done
                    done
                done
            done
        done
    done
done

rm -r $output_dir/step_*

echo ""
echo "🎯 All LongBench-v2 per-problem TTT jobs submitted!"
echo "Results will be saved in results/longbench_v2_ttt_* directories"
echo ""
echo "📊 Expected results structure:"
echo "  - Individual problem results: results/*/longbench_v2_per_problem/problem_*_results.json"
echo "  - Aggregated results: results/*/longbench_v2_per_problem/aggregated_results.json"
echo ""
echo "💡 Key features of LongBench-v2 TTT:"
echo "  - Each problem trains individually on its own context"
echo "  - Model resets between problems for isolation"
echo "  - Comprehensive per-problem and aggregate metrics" 