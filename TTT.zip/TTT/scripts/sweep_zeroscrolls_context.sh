#!/bin/bash

# ZeroSCROLLS Context-Only Evaluation Sweep
# For evaluating models on ZeroSCROLLS datasets without any training

# ZeroSCROLLS datasets to test
# ZEROSCROLLS_DATASETS=("gov_report" "qmsum" "qasper" "narrative_qa" "quality" "musique")
# ZEROSCROLLS_DATASETS=("summ_screen_fd" "squality" "space_digest" "book_sum_sort")
ZEROSCROLLS_DATASETS=("summ_screen_fd" "squality")

# Context parameters - for ZeroSCROLLS, each problem has its own context
# so max_context_examples controls in-context learning examples
MAX_CONTEXT_EXAMPLES=(0)  # 0 = no context, 1-3 = few-shot examples

# Generation parameters suitable for long-form tasks
REASONING_BUDGETS=(0 512 1024 2048 4096 8192 16384)  # Some tasks benefit from reasoning
ANSWER_BUDGETS=(512)  # ZeroSCROLLS often requires longer outpu
# Model configuration
# MODELS=("meta-llama/Llama-3.2-3B-Instruct" "Qwen/Qwen3-1.7B")
# MODELS=("meta-llama/Llama-3.2-3B-Instruct" "Qwen/Qwen3-4B")
MODELS=("Qwen/Qwen3-1.7B")
# MODELS=("meta-llama/Llama-3.1-8B-Instruct" "Qwen/Qwen3-8B")
EVAL_BATCH_SIZE=4  # Smaller batch size due to long contexts
CONTEXT_LENGTH=8192  # Long context length for ZeroSCROLLS
QUESTION_LENGTH=1024  # Longer questions due to instructions + context

# Fixed parameters for context-only mode
MODE="context_only"
ADAPTER="full_ft"  # Not used in context-only but required
NUM_SAMPLES=1
WANDB_MODE="disabled"  # [OFFLINE MODE] 禁用 wandb 联网
LEARNING_RATE=1e-5  # Not used in context-only
BATCH_SIZE=1  # Not used in context-only
LORA_RANK=16  # Not used in context-only
LR_SCHEDULE="constant"
WEIGHT_DECAY=0.01
MAX_TRAIN_EXAMPLES=0  # No training in context-only
NUM_PROBLEMS=50  # Limit number of problems for faster evaluation

echo "Starting ZeroSCROLLS Context-Only Evaluation Sweep"
echo "Datasets: ${ZEROSCROLLS_DATASETS[*]}"
echo "Models: ${MODELS[*]}"

for model_name in "${MODELS[@]}"; do
    for dataset in "${ZEROSCROLLS_DATASETS[@]}"; do
        for max_context_examples in "${MAX_CONTEXT_EXAMPLES[@]}"; do
            for reasoning_budget in "${REASONING_BUDGETS[@]}"; do
                for answer_budget in "${ANSWER_BUDGETS[@]}"; do
                    echo ""
                    echo "=========================================="
                    echo "Submitting ZeroSCROLLS Context-Only Job:"
                    echo "  Dataset: $dataset"
                    echo "  Model: $model_name"
                    echo "  Context Examples: $max_context_examples"
                    echo "  Reasoning Budget: $reasoning_budget"
                    echo "  Answer Budget: $answer_budget"
                    echo "=========================================="
                    
                    # Create output directory name
                    output_dir="results/zeroscrolls_context_${dataset}_$(basename $model_name)_ctx${max_context_examples}_r${reasoning_budget}_a${answer_budget}"
                    LOG_FILE="${output_dir}/log.txt"
                    mkdir -p $output_dir

                    python scripts/run_experiment.py \
                        --mode "$MODE" \
                        --dataset-type zeroscrolls \
                        --zeroscrolls-datasets "$dataset" \
                        --zeroscrolls-num-problems "$NUM_PROBLEMS" \
                        --model-name "$model_name" \
                        --adapter "$ADAPTER" \
                        --max-context-examples "$max_context_examples" \
                        --max-context-length "$CONTEXT_LENGTH" \
                        --max-question-length "$QUESTION_LENGTH" \
                        --reasoning-budget "$reasoning_budget" \
                        --answer-budget "$answer_budget" \
                        --learning-rate "$LEARNING_RATE" \
                        --batch-size "$BATCH_SIZE" \
                        --eval-batch-size "$EVAL_BATCH_SIZE" \
                        --lora-r "$LORA_RANK" \
                        --lr-schedule "$LR_SCHEDULE" \
                        --weight-decay "$WEIGHT_DECAY" \
                        --max-train-examples "$MAX_TRAIN_EXAMPLES" \
                        --num-samples "$NUM_SAMPLES" \
                        --wandb-mode "$WANDB_MODE" \
                        --wandb-project "ttt-zeroscrolls" \
                        --output-dir "$output_dir" \
                        --use-enhanced-eval \
                        --use-vllm-for-eval \
                        --seed 42 \
                        2>&1 | tee "$LOG_FILE"
                    sleep 5  # Brief pause between jobs
                done
            done
        done
    done
done

echo ""
echo "🎯 All ZeroSCROLLS context-only evaluation jobs submitted!"
echo "Results will be saved in results/zeroscrolls_context_* directories" 