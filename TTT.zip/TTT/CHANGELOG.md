# Changelog - Release Version

## Changes from Development to Release Version

### Removed Components

#### Datasets Removed
- **AIME** - Math competition problems dataset
- **MATH500** - Mathematics problem solving dataset  
- **MiniF2F** - Formal mathematics proofs dataset
- **TutorEval** - Educational QA dataset

These datasets were removed to focus the release on long-context understanding tasks.

#### Files Removed
- `src/data/minif2f_loader.py`
- `src/data/tutoreval_loader.py`
- Dataset-specific test files for removed datasets
- Sweep scripts for removed datasets:
  - `sweep_aime_baseline.sh`
  - `sweep_minif2f.sh`
  - `sweep_tutoreval_context.sh`
  - `sweep_tutoreval_ttt.sh`
  - `sweep_reasoning_ttt.sh`
  - `sweep_grpo.sh`

### Simplified Components

#### `scripts/run_experiment.py`
- Removed dataset-specific configurations for AIME, MATH500, MiniF2F, TutorEval
- Simplified argument parser to only include supported datasets
- Removed GRPO and reasoning TTT modes (not used in paper)
- Streamlined config creation logic

#### `src/data/data_loader.py`
- Removed loader wrappers for unsupported datasets
- Simplified factory function to only return loaders for:
  - ZeroSCROLLS
  - LongBench-v2
  - Bank Transactions
  - OLMo Bugs

### Retained Components

All core functionality for the four supported benchmarks is fully retained:

#### Core TTT Implementation
- `src/models/ttt_llm.py` - Complete TTT implementation including:
  - Per-problem test-time training
  - Frozen KV cache optimization
  - Context batchification
  - LoRA and full fine-tuning support
  
#### Evaluation
- `src/utils/evaluation_utils.py` - Full evaluation pipeline
- `src/evaluation/enhanced_eval.py` - Enhanced answer matching
- `src/evaluation/metrics.py` - Evaluation metrics

#### Data Loaders
- `src/data/zeroscrolls_loader.py` - Complete ZeroSCROLLS support (10 datasets)
- `src/data/longbench_v2_loader.py` - Complete LongBench-v2 support (6 domains)
- `src/data/bank_transactions_loader.py` - Bank Transactions support (7 variants)
- `src/data/olmo_bugs_loader.py` - OLMo Bugs support (20 context sizes)

#### Scripts
All sweep scripts for supported datasets retained:
- `sweep_zeroscrolls_{context,ttt}.sh`
- `sweep_longbench_v2_{context,ttt}.sh`
- `sweep_bank_transactions_{context,ttt}.sh`
- `sweep_olmo_bugs_{context,ttt}.sh`
- `run_frozen_kv_{zeroscrolls,longbench_v2}.sh`

### New Additions

- **README.md** - Comprehensive documentation with:
  - Installation instructions
  - Dataset descriptions
  - Usage examples
  - Command-line reference
  - Troubleshooting guide
  
- **LICENSE** - MIT license

- **examples/quickstart.sh** - Quick start examples for:
  - Baseline evaluation
  - LoRA-based TTT
  - Frozen KV cache TTT

### File Structure

```
test-time-training-release/
├── README.md                    # Comprehensive documentation
├── LICENSE                      # MIT license
├── CHANGELOG.md                # This file
├── requirements.txt            # Python dependencies
├── setup_env.py                # Environment setup
├── .gitignore                  # Git ignore rules
├── examples/
│   └── quickstart.sh          # Quick start examples
├── scripts/
│   ├── run_experiment.py      # Main experiment script (cleaned)
│   ├── sweep_zeroscrolls_*.sh
│   ├── sweep_longbench_v2_*.sh
│   ├── sweep_bank_transactions_*.sh
│   ├── sweep_olmo_bugs_*.sh
│   └── run_frozen_kv_*.sh
└── src/
    ├── data/
    │   ├── data_loader.py           # Cleaned factory (4 datasets only)
    │   ├── load_dataset.py          # Dataset wrapper
    │   ├── zeroscrolls_loader.py
    │   ├── longbench_v2_loader.py
    │   ├── bank_transactions_loader.py
    │   └── olmo_bugs_loader.py
    ├── models/
    │   ├── ttt_llm.py              # Complete TTT implementation
    │   └── adaptation.py            # LoRA and full fine-tuning
    ├── evaluation/
    │   ├── enhanced_eval.py        # Enhanced evaluation
    │   └── metrics.py              # Metrics computation
    └── utils/
        ├── evaluation_utils.py     # Evaluation utilities
        ├── logging_utils.py        # Weights & Biases logging
        ├── rope_utils.py           # RoPE/YaRN utilities
        ├── gpu_utils.py            # GPU utilities
        └── flops_utils.py          # FLOPS computation
```

### Testing

The cleaned codebase has been verified to:
- ✅ Import all modules successfully
- ✅ Run experiments on all 4 supported datasets
- ✅ Support all TTT modes (per-problem, frozen KV, context batchification)
- ✅ Work with various model architectures (Qwen, Llama, etc.)

### Migration Guide

If migrating from the development version:

1. **Dataset Changes**: Update any scripts using removed datasets to use supported ones
2. **Config Changes**: The config format is simplified but backwards compatible
3. **Mode Changes**: GRPO and reasoning TTT modes are removed; use standard TTT mode

### Notes

- Core TTT functionality is unchanged - only removed unsupported dataset paths
- All hyperparameters and training logic remain identical
- Performance and results should be identical to development version for supported datasets


